package com.giga1228.giga;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.text.DecimalFormat;
import java.util.Random;

public class GigaActivity extends AppCompatActivity {
    String[] colors;
    //String[] values;
    double Stack[];
    String tempnum[] = new String[50];
    String postfix[] = new String[50];
    int count = 0;
    int confirm = 1;
    int confirm2 = 0;
    int confirm3 = 0;
    int dotconfirm = 0;
    String nownum = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giga);
        for (int p = 0; p < 50; p++) {
            tempnum[p] = null;
        }
        tempnum[count++] = "0";
        final RelativeLayout MyLayout=(RelativeLayout) findViewById(R.id.MyLayout);
        assert MyLayout!=null;
       // values = getResources().getStringArray(R.array.things_array);
        colors = getResources().getStringArray(R.array.backColor);
        final MediaPlayer pikachu=MediaPlayer.create(this,R.raw.pikachu);
        final MediaPlayer pikapika=MediaPlayer.create(this, R.raw.pikapika);
        final MediaPlayer pipikachu=MediaPlayer.create(this, R.raw.pipikachu);
        pikachu.setVolume(1,1);
        pikapika.setVolume(1,1);
        pipikachu.setVolume(1,1);
        final ImageView iconlabel = (ImageView) findViewById(R.id.iconlabel);
        final ImageView iconlabel1 = (ImageView) findViewById(R.id.iconlabel1);
        final ImageView iconlabel3 = (ImageView) findViewById(R.id.iconlabel3);
        assert iconlabel!=null;
        assert iconlabel1!=null;
        assert iconlabel3!=null;
        iconlabel.setVisibility(View.VISIBLE);
        iconlabel1.setVisibility(View.INVISIBLE);
        iconlabel3.setVisibility(View.INVISIBLE);
        final ImageButton mute=(ImageButton)findViewById(R.id.mute);
        final ImageButton unmute=(ImageButton)findViewById(R.id.unmute);
        assert mute!=null;
        assert unmute!=null;
        mute.setVisibility(View.VISIBLE);
        unmute.setVisibility(View.INVISIBLE);

        if (mute.getVisibility()==View.VISIBLE){mute.setClickable(true); unmute.setClickable(false);}
        if (unmute.getVisibility()==View.VISIBLE){unmute.setClickable(true); mute.setClickable(false);}




        final TextView textView = (TextView) findViewById(R.id.textView);
        assert textView!=null;


        textView.setVisibility(View.INVISIBLE);

        final TextView lblNewLabel = (TextView) findViewById(R.id.lblNewLabel);
        assert lblNewLabel != null;

            mute.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.setVolume(0,0);
                    pikapika.setVolume(0,0);
                    pipikachu.setVolume(0,0);
                    mute.setVisibility(View.INVISIBLE);
                    unmute.setVisibility(View.VISIBLE);
                }
            });
        unmute.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pikachu.setVolume(1,1);
                pikapika.setVolume(1,1);
                pipikachu.setVolume(1,1);
                mute.setVisibility(View.VISIBLE);
                unmute.setVisibility(View.INVISIBLE);
            }
        });


        Button btn_1 = (Button) findViewById(R.id.btn_1);
        if (btn_1 != null) {
            btn_1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                            if (confirm3 == 0) {
                                if (nownum.equals("0")) {
                                    nownum = "1";
                                    count--;
                                } else nownum += "1";
                                if (confirm == 1)
                                    tempnum[count++] = "1";
                                else
                                    tempnum[count - 1] += "1";
                                confirm = 0;

                                lblNewLabel.setText(nownum);
                                iconlabel.setVisibility(View.VISIBLE);//change the icon
                                iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                                iconlabel3.setVisibility(View.INVISIBLE);

                            }



                }
            });
        }
        Button btn_2 = (Button) findViewById(R.id.btn_2);
        if (btn_2 != null) {
            btn_2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum.equals("0")) {
                            nownum = "2";
                            count--;
                        } else nownum += "2";
                        if (confirm == 1)
                            tempnum[count++] = "2";
                        else
                            tempnum[count - 1] += "2";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }

                }
            });
        }
        Button btn_3 = (Button) findViewById(R.id.btn_3);
        if (btn_3 != null) {
            btn_3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();

                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "3";
                            count--;
                        } else nownum += "3";
                        if (confirm == 1)
                            tempnum[count++] = "3";
                        else
                            tempnum[count - 1] += "3";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_4 = (Button) findViewById(R.id.btn_4);
        if (btn_4 != null) {
            btn_4.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();

                    if (confirm3 == 0) {
                        if (nownum.equals("0")) {
                            nownum = "4";
                            count--;
                        } else nownum += "4";
                        if (confirm == 1)
                            tempnum[count++] = "4";
                        else
                            tempnum[count - 1] += "4";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_5 = (Button) findViewById(R.id.btn_5);
        if (btn_5 != null) {
            btn_5.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();

                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "5";
                            count--;
                        } else nownum += "5";
                        if (confirm == 1)
                            tempnum[count++] = "5";
                        else
                            tempnum[count - 1] += "5";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_6 = (Button) findViewById(R.id.btn_6);
        if (btn_6 != null) {
            btn_6.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "6";
                            count--;
                        } else nownum += "6";
                        if (confirm == 1)
                            tempnum[count++] = "6";
                        else
                            tempnum[count - 1] += "6";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_7 = (Button) findViewById(R.id.btn_7);
        if (btn_7 != null) {
            btn_7.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "7";
                            count--;
                        } else nownum += "7";
                        if (confirm == 1)
                            tempnum[count++] = "7";
                        else
                            tempnum[count - 1] += "7";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_8 = (Button) findViewById(R.id.btn_8);
        if (btn_8 != null) {
            btn_8.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "8";
                            count--;
                        } else nownum += "8";
                        if (confirm == 1)
                            tempnum[count++] = "8";
                        else
                            tempnum[count - 1] += "8";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_9 = (Button) findViewById(R.id.btn_9);
        if (btn_9 != null) {
            btn_9.setOnClickListener(new View.OnClickListener() {
                public void onClick(View e) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum .equals("0")) {
                            nownum = "9";
                            count--;
                        } else nownum += "9";
                        if (confirm == 1)
                            tempnum[count++] = "9";
                        else {

                            tempnum[count - 1] += "9";
                        }

                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }
        Button btn_point = (Button) findViewById(R.id.btn_point);
        if (btn_point != null) {
            btn_point.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0 && dotconfirm == 0) {
                        if (!nownum.substring(count) .equals(".")) {
                            nownum += ".";
                            tempnum[count] = ".";
                        }
                        if (confirm == 1)
                            tempnum[count++] = ".";
                        else
                        {
                            tempnum[count - 1] += ".";
                        }
                        confirm = 0;
                        dotconfirm = 1;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }
        Button btn_0 = (Button) findViewById(R.id.btn_0);
        if (btn_0 != null) {
            btn_0.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum.equals("0")) {
                            nownum = "0";
                            count--;
                        } else
                            nownum += "0";
                        if (confirm == 1)
                            tempnum[count++] = "0";
                        else
                            tempnum[count - 1] += "0";
                        confirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_plus = (Button) findViewById(R.id.btn_plus);
        if (btn_plus != null) {
            btn_plus.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (nownum.charAt(nownum.length() - 1) != '+' && nownum.charAt(nownum.length() - 1) != '-' && nownum.charAt(nownum.length() - 1) != '*' && nownum.charAt(nownum.length() - 1) != '/' && nownum.charAt(nownum.length() - 1) != '(') {
                        nownum += "+";
                        tempnum[count++] = "+";
                        confirm = 1;
                        confirm3 = 0;
                        dotconfirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_minus = (Button) findViewById(R.id.btn_minus);
        if (btn_minus != null) {
            btn_minus.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (nownum.charAt(nownum.length() - 1) != '+' && nownum.charAt(nownum.length() - 1) != '-' && nownum.charAt(nownum.length() - 1) != '*' && nownum.charAt(nownum.length() - 1) != '/' && nownum.charAt(nownum.length() - 1) != '(') {
                        nownum += "-";
                        tempnum[count++] = "-";
                        confirm = 1;
                        confirm3 = 0;
                        dotconfirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_multiple = (Button) findViewById(R.id.btn_multiple);
        if (btn_multiple != null) {
            btn_multiple.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (nownum.charAt(nownum.length() - 1) != '+' && nownum.charAt(nownum.length() - 1) != '-' && nownum.charAt(nownum.length() - 1) != '*' && nownum.charAt(nownum.length() - 1) != '/' && nownum.charAt(nownum.length() - 1) != '(') {
                        nownum += "*";
                        tempnum[count++] = "*";
                        confirm = 1;
                        confirm3 = 0;
                        dotconfirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);

                    }
                }
            });
        }


        Button btn_divide = (Button) findViewById(R.id.btn_divide);
        if (btn_divide != null) {
            btn_divide.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (nownum.charAt(nownum.length() - 1) != '+' && nownum.charAt(nownum.length() - 1) != '-' && nownum.charAt(nownum.length() - 1) != '*' && nownum.charAt(nownum.length() - 1) != '/' && nownum.charAt(nownum.length() - 1) != '(') {
                        nownum += "/";
                        tempnum[count++] = "/";
                        confirm = 1;
                        confirm3 = 0;
                        dotconfirm = 0;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);


                    }
                }
            });
        }
        Button btn_equal = (Button) findViewById(R.id.btn_equal);
        if (btn_equal != null) {
            btn_equal.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    if (confirm2 > 0 || nownum.charAt(nownum.length() - 1) == '.')//avoid ( ) matching problem
                    {
                        lblNewLabel.setVisibility(View.INVISIBLE);
                        textView.setVisibility(View.VISIBLE);
                        iconlabel.setVisibility(View.INVISIBLE);
                        iconlabel1.setVisibility(View.INVISIBLE);
                        iconlabel3.setVisibility(View.VISIBLE);
                        pikapika.start();
                    } else {
                        intopost(tempnum, postfix, count);
                        for (int p = 0; p < count; p++)
                            System.out.print(postfix[p]);

                        DecimalFormat f = new DecimalFormat("#################.#################");
                        nownum = f.format(calculate(Stack, postfix, count));


                        for (int p = 0; p < 50; p++) {
                            tempnum[p] = null;
                            postfix[p] = null;
                        }

                        tempnum[0] = nownum;
                        count = 1;
                        System.out.println(nownum + "!!!!!!!!!");

                        if (nownum.contains("-1345445.2378989")) {
                            lblNewLabel.setVisibility(View.INVISIBLE);
                            textView.setVisibility(View.VISIBLE);
                            iconlabel.setVisibility(View.INVISIBLE);
                            iconlabel1.setVisibility(View.INVISIBLE);
                            iconlabel3.setVisibility(View.VISIBLE);
                            pikapika.start();
                        } else {
                            lblNewLabel.setText(nownum);
                            iconlabel.setVisibility(View.INVISIBLE);
                            iconlabel1.setVisibility(View.VISIBLE);
                            iconlabel3.setVisibility(View.INVISIBLE);
                            pipikachu.start();
                        }
                    }

                    dotconfirm = 0;
                    confirm3 = 0;
                    confirm2 = 0;


                }
            });
        }
        Button btn_root = (Button) findViewById(R.id.btn_root);
        if (btn_root != null) {
            btn_root.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum.equals("0")) {
                            nownum = "√";
                            count--;
                            tempnum[count] = "√";
                        } else if (nownum.charAt(nownum.length() - 1) == '+' && nownum.charAt(nownum.length() - 1) == '-' && nownum.charAt(nownum.length() - 1) == '*' && nownum.charAt(nownum.length() - 1) != '/')
                            nownum += "√";
                        if (confirm == 1) {
                            if (nownum.charAt(nownum.length() - 1) != '√')
                                nownum += "√";
                            tempnum[count++] = "√";
                        }
                        lblNewLabel.setText(nownum);
                        confirm = 0;
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);
                    }
                }
            });
        }

        Button btn_Clear = (Button) findViewById(R.id.btn_Clear);
        if (btn_Clear != null) {
            btn_Clear.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    lblNewLabel.setVisibility(View.VISIBLE);
                    textView.setVisibility(View.INVISIBLE);
                    nownum = "0";
                    count = 0;
                    for (int p = 0; p < 50; p++) {
                        tempnum[p] = null;
                        postfix[p] = null;
                    }
                    tempnum[count++] = "0";
                    lblNewLabel.setText(nownum);
                    dotconfirm = 0;
                    confirm = 1;
                    confirm2 = 0;
                    confirm3 = 0;
                    iconlabel.setVisibility(View.VISIBLE);//change the icon
                    iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                    iconlabel3.setVisibility(View.INVISIBLE);
                }
            });
        }
        Button rightparentheses = (Button) findViewById(R.id.rightparentheses);
        if (rightparentheses != null) {
            rightparentheses.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm3 == 0) {
                        if (nownum.equals("0")) {
                            count--;
                            nownum = "(";
                            tempnum[count++] = "(";
                            confirm2++;
                            confirm = 1;
                            lblNewLabel.setText(nownum);
                        } else if (confirm == 1)
                        {
                            tempnum[count++] = "(";
                            nownum += "(";
                            confirm2++;
                            confirm = 1;
                            lblNewLabel.setText(nownum);
                        }
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);
                    }
                }
            });
        }


        Button leftparentheses = (Button) findViewById(R.id.leftparentheses);
        if (leftparentheses != null) {
            leftparentheses.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (confirm2 > 0 && confirm == 0)
                    {
                        nownum += ")";
                        tempnum[count++] = ")";
                        confirm2--;
                        confirm = 1;
                        confirm3 = 1;
                        lblNewLabel.setText(nownum);
                        iconlabel.setVisibility(View.VISIBLE);//change the icon
                        iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                        iconlabel3.setVisibility(View.INVISIBLE);
                    }
                }
            });
        }


        ImageButton btn_start = (ImageButton) findViewById(R.id.imageButton);
        if (btn_start != null) {
            btn_start.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    Random RAND = new Random();
                    int position = RAND.nextInt(colors.length);
                    String nextColor = colors[position];
                   // String textValue = values[position2];

                    MyLayout.setBackgroundColor(Color.parseColor(nextColor));

                }

            });
        }




        /*btn_over.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btn_over.setVisible(false);
                btn_start.setVisible(true);
            }
        });*/

        Button btn_backspace = (Button) findViewById(R.id.btn_backspace);
        if (btn_backspace != null) {
            btn_backspace.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pikachu.start();
                    if (nownum.charAt(nownum.length() - 1) == '+' || nownum.charAt(nownum.length() - 1) == '*' ||
                            nownum.charAt(nownum.length() - 1) == '/') {
                        nownum = nownum.substring(0, nownum.length() - 1);
                        tempnum[count--] = null;
                        confirm = 0;
                        System.out.print(tempnum[count - 1]);
                    }
                    else if (nownum.charAt(nownum.length() - 1) == '-') {
                        if (nownum.length() == 1) {
                            nownum = "0";
                            count = 0;
                            tempnum[count++] = "0";

                            confirm2 = 0;
                            confirm = 1;

                        } else {
                            nownum = nownum.substring(0, nownum.length() - 1);
                            tempnum[count--] = null;
                            confirm = 0;

                        }
                    } else if (nownum.charAt(nownum.length() - 1) == '(') {
                        if (nownum.length() == 1) {
                            nownum = "0";
                            count = 0;
                            tempnum[count++] = "0";

                            confirm2 = 0;
                            confirm = 1;
                            System.out.print(tempnum[count]);
                        }
                        else {
                            nownum = nownum.substring(0, nownum.length() - 1);
                            tempnum[count--] = null;
                            confirm2--;
                            confirm = 0;
                        }

                    }
                    else if (nownum.charAt(nownum.length() - 1) == ')') {
                        nownum = nownum.substring(0, nownum.length() - 1);
                        tempnum[count--] = null;
                        confirm2++;
                        confirm3 = 0;
                        confirm = 0;

                    }
                    else if (nownum.charAt(nownum.length() - 1) == '√') {
                        if (nownum.length() == 1) {
                            nownum = "0";
                            count = 0;
                            tempnum[count++] = "0";
                            confirm3 = 0;
                            confirm = 1;
                            System.out.print(tempnum[count]);
                        }
                        else {
                            nownum = nownum.substring(0, nownum.length() - 1);
                            tempnum[count--] = null;
                            if (nownum.charAt(nownum.length() - 1) == '+' || nownum.charAt(nownum.length() - 1) == '-' || nownum.charAt(nownum.length() - 1) == '*' ||
                                    nownum.charAt(nownum.length() - 1) == '/' || nownum.charAt(nownum.length() - 1) == '(' || nownum.charAt(nownum.length() - 1) == ')')
                                confirm = 1;
                            else
                                confirm = 0;
                        }
                    }


                    else {
                        if (nownum.length() == 1) {
                            nownum = "0";
                            count = 0;
                            tempnum[count++] = "0";
                            confirm = 1;
                            confirm3 = 0;
                            dotconfirm = 0;
                        }

                        else if (tempnum[count - 1].length() == 1) {
                            if (nownum.charAt(nownum.length() - 1) == '.')
                                dotconfirm = 0;

                            nownum = nownum.substring(0, nownum.length() - 1);
                            tempnum[count--] = null;
                            confirm = 1;


                        }
                        else {
                            if (nownum.charAt(nownum.length() - 1) == '.')
                                dotconfirm = 0;

                            nownum = nownum.substring(0, nownum.length() - 1);
                            tempnum[count - 1] = tempnum[count - 1].substring(0, tempnum[count - 1].length() - 1);
                            System.out.print(tempnum[count - 1]);
                        }
                    }
                    lblNewLabel.setText(nownum);
                    iconlabel.setVisibility(View.VISIBLE);//change the icon
                    iconlabel1.setVisibility(View.INVISIBLE);//change the icon
                    iconlabel3.setVisibility(View.INVISIBLE);
                }
            });
        }


    }
    public double calculate(double stack[], String postfix[], int count) {
        int i;
        int item = 0;
        double ans = 0;
        int numamount = 0;
        int opamount = 0;

        for (i = 0; i < count; i++) {
            if (postfix[i] == null) {
                break;
            }
            if (postfix[i].charAt(0) != '*' && postfix[i].charAt(0) != '+' && postfix[i].charAt(0) != '-' && postfix[i].charAt(0) != '/') {
                System.out.println(postfix[i] + "num!!!");
                if (postfix[i].charAt(0) == '√')
                    stack[item] = Math.sqrt(Double.parseDouble(postfix[i].substring(1)));
                else
                    stack[item] = Double.parseDouble(postfix[i]);
                System.out.println(stack[item] + "stack");
                ans = stack[item];
                item++;
                numamount++;

            } else if (postfix[i].charAt(0) == '-' && postfix[i].length() > 1)//use to calculate negative
            {
                stack[item] = Double.parseDouble(postfix[i]);//use it to store tmp num
                System.out.println("-in");
                ans = stack[item];
                item++;
                numamount++;
            } else {
                System.out.println(postfix[i] + "op!!!!!");
                opamount++;
                switch (postfix[i].charAt(0)) {
                    case '+':
                        if ((item - 2) < 0 || (item - 1) < 0) {
                            return -1345445.2378989;
                        }
                        ans = stack[item - 2] + stack[item - 1];
                        stack[item - 2] = ans;
                        item--;
                        break;
                    case '-':
                        if ((item - 2) < 0 || (item - 1) < 0) {
                            return -1345445.2378989;
                        }
                        ans = stack[item - 2] - stack[item - 1];
                        stack[item - 2] = ans;
                        item--;
                        break;
                    case '*':
                        if ((item - 2) < 0 || (item - 1) < 0) {
                            return -1345445.2378989;
                        }
                        ans = stack[item - 2] * stack[item - 1];
                        stack[item - 2] = ans;
                        item--;
                        break;
                    case '/':
                        if ((item - 2) < 0 || (item - 1) < 0) {
                            return -1345445.2378989;
                        }
                        ans = stack[item - 2] / stack[item - 1];
                        if (stack[item - 1] == 0)
                            return -1345445.2378989;
                        stack[item - 2] = ans;
                        item--;
                        break;

                }


            }
            if (numamount - 1 != opamount) {
                ans = -1345445.2378989;
            }
        }

        System.out.println("ans:" + ans);
        return ans;
    }

    void intopost(String input[], String postfix[], int count) {
        Stack = new double[50];
        int i;
        int top = 0;
        int order = 0;
        char buffer[] = new char[50];
        int confirm;
        for (int p = 0; p < count; p++) {
            System.out.println(input[p]);
        }
        System.out.print("iiiiii");
        System.out.println("");
        for (i = 0; i < count; i++) {
            confirm = 0;
            if (input[i].length() == 1) {
                switch (input[i].charAt(0)) {
                    case '(':
                        confirm = 1;
                        buffer[++top] = input[i].charAt(0);
                        break;
                    case '+':
                    case '-':
                    case '*':
                    case '/':

                        confirm = 1;
                        while (prior(buffer[top]) >= prior(input[i].charAt(0))) {


                            postfix[order] = String.valueOf(buffer[top]);
                            order++;
                            top--;

                        }
                        buffer[++top] = input[i].charAt(0);

                        break;
                    case ')':
                        confirm = 1;
                        while (buffer[top] != '(') {

                            postfix[order] = String.valueOf(buffer[top]);

                            order++;
                            top--;
                        }
                        top--;
                        break;
                }
            }
            if (confirm == 0)
            {

                postfix[order] = input[i];
                System.out.println(input[i] + "~numin2");
                order++;
            }
        }

        while (top > 0) {



            postfix[order] = String.valueOf(buffer[top]);
            order++;

            top--;
        }
    }

    int prior(char buffer) {
        int pvalue = 0;
        switch (buffer) {
            case '*':
                pvalue = 2;
                break;
            case '/':
                pvalue = 2;
                break;
            case '+':
                pvalue = 1;
                break;
            case '-':
                pvalue = 1;
                break;
        }
        return pvalue;
    }


}
