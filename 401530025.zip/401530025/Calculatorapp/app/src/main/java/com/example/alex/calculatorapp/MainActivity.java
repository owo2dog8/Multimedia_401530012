package com.example.alex.calculatorapp;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.text.DecimalFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.media.AudioManager;
import android.media.SoundPool;

public class MainActivity extends AppCompatActivity {

    Button one;
    Button two;
    Button three;
    Button four;
    Button five;
    Button six;
    Button seven;
    Button eight;
    Button nine;
    Button zero;
    Button equal;
    Button plus;
    Button minus;
    Button mutiple;
    Button divide;
    Button root;
    Button cancel;
    Button dot;
    Button left;
    Button back;
    Button right;
    Button voice;
    TextView outputview;
    TextView wrongview;
    ImageView bird;
    ImageView dog;
    RelativeLayout background;
    double Stack[] ;
    String tempnum[]=new String[50];
    String postfix[]=new String[50];
    int count=0;
    int confirm=1;// operator and number confirm
    int confirm2=0;// ( ) matching confirm
    int confirm3=0;// ) fool proofing
    int dotconfirm=0;
    String nownum="0";
    String tem;
    private static final int RQS_VOICE_RECOGNITION = 1;
    String setting = "設定";
    String colornum ;
    private int alertId;
    private SoundPool soundPool;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        menu.add(Menu.NONE, Menu.FIRST , Menu.NONE, "Gray");
        menu.add(Menu.NONE, Menu.FIRST+1 , Menu.NONE, "Blue");
        menu.add(Menu.NONE, Menu.FIRST+2 , Menu.NONE, "Yellow");
        menu.add(Menu.NONE, Menu.FIRST+3 , Menu.NONE, "Pink");

        return super.onCreateOptionsMenu(menu);
    }

    private static final String color = "COLOR";
    private SharedPreferences set;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getGroupId() == Menu.NONE) {
            Toast.makeText(getApplicationContext(),
                    item.getTitle(),
                    Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId()== Menu.FIRST){
            one.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            two.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            three.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            four.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            five.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            six.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            seven.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            eight.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            nine.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            zero.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            equal.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            plus.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            minus.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            mutiple.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            divide.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            root.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            cancel.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            dot.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            left.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            back.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            right.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            voice.getBackground().setColorFilter(Color.parseColor("#D6D7D7"), android.graphics.PorterDuff.Mode.MULTIPLY );
            tem="#D6D7D7";
            set = getSharedPreferences(color,0);
            set.edit()
                    .putString("colornum",tem)
                    .commit();


        }
       if(item.getItemId()== Menu.FIRST+1){
            one.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            two.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            three.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            four.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            five.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            six.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            seven.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            eight.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            nine.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            zero.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            equal.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            plus.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            minus.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            mutiple.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            divide.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            root.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            cancel.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            dot.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            left.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            back.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            right.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            voice.getBackground().setColorFilter(Color.parseColor("#87CEFA"), android.graphics.PorterDuff.Mode.MULTIPLY );
            tem="#87CEFA";
            set = getSharedPreferences(color,0);
            set.edit()
                   .putString("colornum",tem)
                   .commit();

       }
        if(item.getItemId()== Menu.FIRST+2){
            one.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            two.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            three.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            four.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            five.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            six.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            seven.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            eight.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            nine.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            zero.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            equal.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            plus.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            minus.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            mutiple.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            divide.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            root.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            cancel.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            dot.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            left.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            back.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            right.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            voice.getBackground().setColorFilter(Color.parseColor("#FFE4B5"), android.graphics.PorterDuff.Mode.MULTIPLY );
            tem="#FFE4B5";
            set = getSharedPreferences(color,0);
            set.edit()
                    .putString("colornum",tem)
                    .commit();

        }
        if(item.getItemId()== Menu.FIRST+3){
            one.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            two.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            three.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            four.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            five.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            six.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            seven.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            eight.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            nine.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            zero.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            equal.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            plus.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            minus.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            mutiple.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            divide.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            root.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            cancel.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            dot.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            left.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            back.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            right.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            voice.getBackground().setColorFilter(Color.parseColor("#FFB6C1"), android.graphics.PorterDuff.Mode.MULTIPLY );
            tem="#FFB6C1";
            set = getSharedPreferences(color,0);
            set.edit()
                    .putString("colornum",tem)
                    .commit();//save into xml

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 5);
        alertId = soundPool.load(this, R.raw.decision1, 1);//get file of music


        one = (Button) findViewById(R.id.one);
        two = (Button) findViewById(R.id.two);
        three = (Button) findViewById(R.id.three);
        four = (Button) findViewById(R.id.four);
        five = (Button) findViewById(R.id.five);
        six = (Button) findViewById(R.id.six);
        seven = (Button) findViewById(R.id.seven);
        eight = (Button) findViewById(R.id.eight);
        nine = (Button) findViewById(R.id.nine);
        zero = (Button) findViewById(R.id.zero);
        equal = (Button) findViewById(R.id.equal);
        plus = (Button) findViewById(R.id.plus);
        minus = (Button) findViewById(R.id.minus);
        mutiple = (Button) findViewById(R.id.mutiple);
        divide = (Button) findViewById(R.id.divide);
        cancel = (Button) findViewById(R.id.cancel);
        left = (Button) findViewById(R.id.left);
        right = (Button) findViewById(R.id.right);
        root = (Button) findViewById(R.id.root);
        dot = (Button) findViewById(R.id.dot);
        back = (Button) findViewById(R.id.back);
        voice= (Button) findViewById(R.id.voice);

        outputview = (TextView) findViewById(R.id.outputview);
        wrongview = (TextView) findViewById(R.id.wrongview);
        background= (RelativeLayout)findViewById(R.id.background);
        bird = (ImageView) findViewById(R.id.bird);
        dog = (ImageView) findViewById(R.id.dog);

        set = getSharedPreferences(color, 0);
        colornum=set.getString("colornum","");
        if(colornum!="") {
            one.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            two.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            three.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            four.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            five.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            six.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            seven.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            eight.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            nine.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            zero.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            equal.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            plus.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            minus.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            mutiple.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            divide.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            root.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            cancel.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            dot.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            left.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            back.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            right.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
            voice.getBackground().setColorFilter(Color.parseColor(colornum), android.graphics.PorterDuff.Mode.MULTIPLY);
        }

        for(int p=0;p<50;p++)
        {
            tempnum[p]=null;//initialize input array
        }
        tempnum[count++]="0";//avoid first number calculation
        wrongview.setVisibility(View.INVISIBLE);
        background.setBackgroundResource(0);
//start


        voice.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(//透過 Intent 的方式開啟內建的語音辨識
                        RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Start Speech");
                startActivityForResult(intent, RQS_VOICE_RECOGNITION);//語音辨識開始
            }
        });
//end

        one.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
               // System.out.println("@@@"+colornum);

                //System.out.print("!!!!"+colornum);
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume

                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="1";
                        count--;
                    }
                    else nownum+="1";
                    if(confirm==1)//indicate that the last input is operator
                        tempnum[count++]="1";
                    else//indicate that the last input is number
                        tempnum[count-1]+="1";
                    confirm=0;// use to divide the operator or number
                     outputview.setText(nownum);
                    //System.out.print(tempnum[count-1]);
                }

            }
        });
        two.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="2";
                        count--;
                    }
                    else nownum+="2";
                    if(confirm==1)
                        tempnum[count++]="2";
                    else
                        tempnum[count-1]+="2";
                    confirm=0;
                    outputview.setText(nownum);
                    //System.out.print(tempnum[count-1]);

                }
            }
        });
        three.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="3";
                        count--;
                    }
                    else  nownum+="3";
                    if(confirm==1)
                        tempnum[count++]="3";
                    else
                        tempnum[count-1]+="3";
                    confirm=0;
                    outputview.setText(nownum);
                }

            }
        });
        four.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="4";
                        count--;
                    }
                    else  nownum+="4";
                    if(confirm==1)
                        tempnum[count++]="4";
                    else
                        tempnum[count-1]+="4";
                    confirm=0;
                    outputview.setText(nownum);
                }

            }
        });
        five.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="5";
                        count--;
                    }
                    else  nownum+="5";
                    if(confirm==1)
                        tempnum[count++]="5";
                    else
                        tempnum[count-1]+="5";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });
        six.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="6";
                        count--;
                    }
                    else  nownum+="6";
                    if(confirm==1)
                        tempnum[count++]="6";
                    else
                        tempnum[count-1]+="6";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });
        seven.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="7";
                        count--;
                    }
                    else  nownum+="7";
                    if(confirm==1)
                        tempnum[count++]="7";
                    else
                        tempnum[count-1]+="7";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });
        eight.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="8";
                        count--;
                    }
                    else  nownum+="8";
                    if(confirm==1)
                        tempnum[count++]="8";
                    else
                        tempnum[count-1]+="8";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });
        nine.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="9";
                        count--;
                    }
                    else  nownum+="9";
                    if(confirm==1)
                        tempnum[count++]="9";
                    else
                        tempnum[count-1]+="9";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });

        zero.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="0";
                        count--;
                    }
                    else
                        nownum+="0";
                    if(confirm==1)
                        tempnum[count++]="0";
                    else
                        tempnum[count-1]+="0";
                    confirm=0;
                    outputview.setText(nownum);
                }
            }
        });


        equal.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(confirm2>0||nownum.charAt(nownum.length()-1)=='.')//avoid ( ) matching problem
                {
                    outputview.setVisibility(View.INVISIBLE);
                    wrongview.setVisibility(View.VISIBLE);
                }
                else{

                    intopost(tempnum,postfix,count);//turn infix to postfix
                    for(int p=0;p<count;p++)
                        System.out.print(postfix[p]);
                    	System.out.println("KKKKKKK");
                    //  nownum=Double.toString(calculate(Stack,postfix,count));
                    DecimalFormat f = new DecimalFormat("################.#################");//format double to avoid residual 0
                    nownum =f.format(calculate(Stack,postfix,count));//make calculation
                    //    nownum = String.format("%g", calculate(Stack,postfix,count));

                    for(int p=0;p<50;p++)
                    {
                        tempnum[p]=null;
                        postfix[p]=null;
                    }

                    tempnum[0]=nownum;
                    count=1;
                    System.out.println(nownum+"!!!!!!!!!");

                    if(nownum.contains("-1345445.2378989"))
                    {
                        outputview.setVisibility(View.INVISIBLE);
                        wrongview.setVisibility(View.VISIBLE);
                    }
                    else
                        outputview.setText(nownum);
                }

                dotconfirm=0;
                confirm3=0;
                confirm2=0;
                dog.setVisibility(View.INVISIBLE);//change the icon
                bird.setVisibility(View.INVISIBLE);//change the icon
                background.setBackgroundResource(R.drawable.background);

            }
        });

        plus.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                    if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                        nownum+="+";
                        tempnum[count++]="+";
                        confirm=1;
                        confirm3=0;
                        dotconfirm=0;
                        outputview.setText(nownum);
                    }// avoid double keyin operator
                }

        });

        minus.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                    nownum+="-";
                    tempnum[count++]="-";
                    confirm=1;
                    confirm3=0;
                    dotconfirm=0;
                    outputview.setText(nownum);
                }
            }
        });
        divide.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                    nownum+="/";
                    tempnum[count++]="/";
                    confirm=1;
                    confirm3=0;
                    dotconfirm=0;
                    outputview.setText(nownum);
                    //System.out.print(tempnum[count-1]);
                }
            }
        });
        mutiple.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                    if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                        nownum+="*";
                        tempnum[count++]="*";
                        confirm=1;
                        confirm3=0;
                        dotconfirm=0;
                        outputview.setText(nownum);
                    }
            }
        });
        root.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-gehod stub
                if(confirm3==0){
                    if(nownum=="0")
                    {
                        nownum="√";
                        count--;
                        tempnum[count]="√";
                    }
                    else if(nownum.charAt(nownum.length()-1)=='+'&&nownum.charAt(nownum.length()-1)=='-'&&nownum.charAt(nownum.length()-1)=='*'&&nownum.charAt(nownum.length()-1)!='/')
                        nownum+="√";
                    if(confirm==1)
                    {
                        if(nownum.charAt(nownum.length()-1)!='√')
                            nownum+="√";
                        tempnum[count++]="√";
                    }
                    outputview.setText(nownum);
                    confirm=0;
                }
            }
        });

        cancel.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                    outputview.setVisibility(View.VISIBLE);
                    wrongview.setVisibility(View.INVISIBLE);
                    nownum="0";
                    count=0;
                    for(int p=0;p<50;p++)
                    {
                        tempnum[p]=null;
                        postfix[p]=null;
                    }
                    tempnum[count++]="0";
                    outputview.setText(nownum);
                    dotconfirm=0;
                    confirm=1;
                    confirm2=0;
                    confirm3=0;
                    dog.setVisibility(View.VISIBLE);// change the icon
                    bird.setVisibility(View.VISIBLE);// change the icon
                    background.setBackgroundResource(0);

            }
        });

        left.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(confirm3==0){//cant add after (
                    if(nownum=="0")
                    {
                        count--;
                        nownum="(";
                        tempnum[count++]="(";
                        confirm2++;
                        confirm=1;
                        outputview.setText(nownum);
                    }
                    else if(confirm==1)//last one is operator or (
                    {
                        tempnum[count++]="(";
                        nownum+="(";
                        confirm2++;
                        confirm=1;
                        outputview.setText(nownum);
                    }
                }
            }
        });
        right.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(confirm2>0&&confirm==0)//avoid many ( input
                {
                    nownum+=")";
                    tempnum[count++]=")";
                    confirm2--;
                    confirm=1;
                    confirm3=1;
                    outputview.setText(nownum);
                }
            }
        });
        back.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='*' ||
                        nownum.charAt(nownum.length()-1)=='/' )
                {
                    nownum=nownum.substring(0,nownum.length()-1);
                    tempnum[count--]=null;
                    confirm=0;
                    System.out.print(tempnum[count-1]);
                }// if last char is operation
                else if( nownum.charAt(nownum.length()-1)=='-' )
                {
                    if(nownum.length()==1)
                    {
                        nownum="0";
                        count=0;
                        tempnum[count++]="0";
                        //confirm3=0;
                        confirm2=0;
                        confirm=1;
                        //System.out.print(tempnum[count]);
                    }
                    else{
                        nownum=nownum.substring(0,nownum.length()-1);
                        tempnum[count--]=null;
                        confirm=0;
                        //System.out.print(tempnum[count-1]);
                    }// if last char is '-'
                }
                else if(nownum.charAt(nownum.length()-1)=='('){
                    if(nownum.length()==1){
                        nownum="0";
                        count=0;
                        tempnum[count++]="0";
                        //confirm3=0;
                        confirm2=0;
                        confirm=1;
                        System.out.print(tempnum[count]);
                    }// if last char is '('
                    else{
                        nownum=nownum.substring(0,nownum.length()-1);
                        tempnum[count--]=null;
                        confirm2--;
                        confirm=0;
                    }

                }//delete the last char and set the value of confirm
                else if(nownum.charAt(nownum.length()-1)==')'){
                    nownum=nownum.substring(0,nownum.length()-1);
                    tempnum[count--]=null;
                    confirm2++;
                    confirm3=0;
                    confirm=0;

                }// if last char is ')'  //delete the last char and set the value of confirm
                else if(nownum.charAt(nownum.length()-1)=='√'){
                    if(nownum.length()==1){
                        nownum="0";
                        count=0;
                        tempnum[count++]="0";
                        confirm3=0;
                        confirm=1;
                        System.out.print(tempnum[count]);
                    }//if last char is '√'
                    else{
                        nownum=nownum.substring(0,nownum.length()-1);
                        tempnum[count--]=null;
                        if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='-' || nownum.charAt(nownum.length()-1)=='*' ||
                                nownum.charAt(nownum.length()-1)=='/'||nownum.charAt(nownum.length()-1)=='('||nownum.charAt(nownum.length()-1)==')' )
                            confirm=1;
                        else
                            confirm=0;
                    }
                }//delete the last char and set the value of confirm


                else{
                    if(nownum.length()==1){
                        nownum="0";
                        count=0;
                        tempnum[count++]="0";
                        confirm=1;
                        confirm3=0;
                        dotconfirm=0;
                    }//delete the single number without connect with any operation

                    else if(tempnum[count-1].length()==1){
                        if(nownum.charAt(nownum.length()-1)=='.')
                            dotconfirm=0;
                        //if the last char is .
                        nownum=nownum.substring(0,nownum.length()-1);
                        tempnum[count--]=null;
                        confirm=1;
                        //System.out.print(tempnum[count-1]);

                    }//delete the single-digit number behind the operation
                    else {
                        if(nownum.charAt(nownum.length()-1)=='.')
                            dotconfirm=0;

                        nownum=nownum.substring(0,nownum.length()-1);
                        tempnum[count-1]=tempnum[count-1].substring(0,tempnum[count-1].length()-1);
                        System.out.print(tempnum[count-1]);
                    }//delete the Multi-digit number behind the operation
                }
                outputview.setText(nownum);

            }
        });

        dot.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                soundPool.play(alertId, 0.5F, 0.5F, 0, 0, 0.5F);//play music and set their volume
                // TODO Auto-generated method stub
                if(confirm3==0&&dotconfirm==0){//make sure every number just can have one dot and cant put behind )
                    if(nownum.substring(count)!="."){ // if first number is 0 > 0.
                        nownum+=".";
                        tempnum[count]=".";
                    }
                    if(confirm==1)// if last input is operator
                        tempnum[count++]=".";
                    else // if last input is number
                    {
                        tempnum[count-1]+=".";
                    }
                    confirm=0;
                    dotconfirm=1;
                    outputview.setText(nownum);
                    dog.setVisibility(View.INVISIBLE);// change icon
                    bird.setVisibility(View.INVISIBLE);// change icon
                    background.setBackgroundResource(R.drawable.background);
                }
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        speechRecognitionAction(requestCode, resultCode, data);
    }

    public void speechRecognitionAction(int requestCode, int resultCode,
                                        Intent data) {

        if (requestCode == RQS_VOICE_RECOGNITION) {
            if (resultCode == RESULT_OK) {
                ArrayList<String> result = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);//列出所有的符合資訊，第一筆最為符合
                String tempStr = "";
                for (String str : result) {
                    tempStr += str + "\n";
                }


                for (int i = 0; i < result.size(); i++) {
                    if (setting.equals(result.get(i))) {
                        Intent intent = new Intent(
                                "com.android.settings.TTS_SETTINGS");
                        startActivity(intent);
                    }
                }
                if (tempStr.contains("1")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="1";
                                count--;
                            }
                            else nownum+="1";
                            if(confirm==1)//indicate that the last input is operator
                                tempnum[count++]="1";
                            else//indicate that the last input is number
                                tempnum[count-1]+="1";
                            confirm=0;// use to divide the operator or number
                            outputview.setText(nownum);
                            //System.out.print(tempnum[count-1]);
                        }

                    }

                else if (tempStr.contains("2")) {
                        // TODO Auto-generated method stub
                        outputview.setText("2");
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="2";
                                count--;
                            }
                            else nownum+="2";
                            if(confirm==1)
                                tempnum[count++]="2";
                            else
                                tempnum[count-1]+="2";
                            confirm=0;
                            outputview.setText(nownum);
                            //System.out.print(tempnum[count-1]);

                        }
                    }
               else if (tempStr.contains("3")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="3";
                                count--;
                            }
                            else  nownum+="3";
                            if(confirm==1)
                                tempnum[count++]="3";
                            else
                                tempnum[count-1]+="3";
                            confirm=0;
                            outputview.setText(nownum);
                        }

                    }

               else if (tempStr.contains("4")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="4";
                                count--;
                            }
                            else  nownum+="4";
                            if(confirm==1)
                                tempnum[count++]="4";
                            else
                                tempnum[count-1]+="4";
                            confirm=0;
                            outputview.setText(nownum);
                        }

                    }
               else if (tempStr.contains("5")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="5";
                                count--;
                            }
                            else  nownum+="5";
                            if(confirm==1)
                                tempnum[count++]="5";
                            else
                                tempnum[count-1]+="5";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }
                else if (tempStr.contains("6")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="6";
                                count--;
                            }
                            else  nownum+="6";
                            if(confirm==1)
                                tempnum[count++]="6";
                            else
                                tempnum[count-1]+="6";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }
               else  if (tempStr.contains("7")){
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="7";
                                count--;
                            }
                            else  nownum+="7";
                            if(confirm==1)
                                tempnum[count++]="7";
                            else
                                tempnum[count-1]+="7";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }
                else if (tempStr.contains("8")){
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="8";
                                count--;
                            }
                            else  nownum+="8";
                            if(confirm==1)
                                tempnum[count++]="8";
                            else
                                tempnum[count-1]+="8";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }
               else if (tempStr.contains("9")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="9";
                                count--;
                            }
                            else  nownum+="9";
                            if(confirm==1)
                                tempnum[count++]="9";
                            else
                                tempnum[count-1]+="9";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }


                else if (tempStr.contains("0")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="0";
                                count--;
                            }
                            else
                                nownum+="0";
                            if(confirm==1)
                                tempnum[count++]="0";
                            else
                                tempnum[count-1]+="0";
                            confirm=0;
                            outputview.setText(nownum);
                        }
                    }


                else if (tempStr.contains("等於")) {
                        // TODO Auto-generated method stub
                        if(confirm2>0||nownum.charAt(nownum.length()-1)=='.')//avoid ( ) matching problem
                        {
                            outputview.setVisibility(View.INVISIBLE);
                            wrongview.setVisibility(View.VISIBLE);
                        }
                        else{

                            intopost(tempnum,postfix,count);//turn infix to postfix
                            for(int p=0;p<count;p++)
                                System.out.print(postfix[p]);
                            System.out.println("KKKKKKK");
                            //  nownum=Double.toString(calculate(Stack,postfix,count));
                            DecimalFormat f = new DecimalFormat("################.#################");//format double to avoid residual 0
                            nownum =f.format(calculate(Stack,postfix,count));//make calculation
                            //    nownum = String.format("%g", calculate(Stack,postfix,count));

                            for(int p=0;p<50;p++)
                            {
                                tempnum[p]=null;
                                postfix[p]=null;
                            }

                            tempnum[0]=nownum;
                            count=1;
                            System.out.println(nownum+"!!!!!!!!!");

                            if(nownum.contains("-1345445.2378989"))
                            {
                                outputview.setVisibility(View.INVISIBLE);
                                wrongview.setVisibility(View.VISIBLE);
                            }
                            else
                                outputview.setText(nownum);
                        }

                        dotconfirm=0;
                        confirm3=0;
                        confirm2=0;
                        dog.setVisibility(View.INVISIBLE);//change the icon
                        bird.setVisibility(View.INVISIBLE);//change the icon

                    }
               else if (tempStr.contains("加")) {
                        // TODO Auto-generated method stub
                        if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                            nownum+="+";
                            tempnum[count++]="+";
                            confirm=1;
                            confirm3=0;
                            dotconfirm=0;
                            outputview.setText(nownum);
                        }// avoid double keyin operator
                    }

               else if (tempStr.contains("減")||tempStr.contains("劍")) {
                        // TODO Auto-generated method stub
                        if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                            nownum+="-";
                            tempnum[count++]="-";
                            confirm=1;
                            confirm3=0;
                            dotconfirm=0;
                            outputview.setText(nownum);
                        }
                    }
               else if (tempStr.contains("乘")||tempStr.contains("成")) {
                        // TODO Auto-generated method stub
                        if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                            nownum+="/";
                            tempnum[count++]="/";
                            confirm=1;
                            confirm3=0;
                            dotconfirm=0;
                            outputview.setText(nownum);
                            //System.out.print(tempnum[count-1]);
                        }
                    }
                else if (tempStr.contains("除")||tempStr.contains("廚")) {
                        // TODO Auto-generated method stub
                        if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
                            nownum+="*";
                            tempnum[count++]="*";
                            confirm=1;
                            confirm3=0;
                            dotconfirm=0;
                            outputview.setText(nownum);
                        }
                    }
                else if (tempStr.contains("根號")) {
                        // TODO Auto-gehod stub
                        if(confirm3==0){
                            if(nownum=="0")
                            {
                                nownum="√";
                                count--;
                                tempnum[count]="√";
                            }
                            else if(nownum.charAt(nownum.length()-1)=='+'&&nownum.charAt(nownum.length()-1)=='-'&&nownum.charAt(nownum.length()-1)=='*'&&nownum.charAt(nownum.length()-1)!='/')
                                nownum+="√";
                            if(confirm==1)
                            {
                                if(nownum.charAt(nownum.length()-1)!='√')
                                    nownum+="√";
                                tempnum[count++]="√";
                            }
                            outputview.setText(nownum);
                            confirm=0;
                        }
                    }
                else if (tempStr.contains("歸零")) {
                        // TODO Auto-generated method stub
                        outputview.setVisibility(View.VISIBLE);
                        wrongview.setVisibility(View.INVISIBLE);
                        nownum="0";
                        count=0;
                        for(int p=0;p<50;p++)
                        {
                            tempnum[p]=null;
                            postfix[p]=null;
                        }
                        tempnum[count++]="0";
                        outputview.setText(nownum);
                        dotconfirm=0;
                        confirm=1;
                        confirm2=0;
                        confirm3=0;
                        dog.setVisibility(View.VISIBLE);// change the icon
                        bird.setVisibility(View.VISIBLE);// change the icon

                    }
                else if (tempStr.contains("左括號")||tempStr.contains("左")){
                        // TODO Auto-generated method stub
                        if(confirm3==0){//cant add after (
                            if(nownum=="0")
                            {
                                count--;
                                nownum="(";
                                tempnum[count++]="(";
                                confirm2++;
                                confirm=1;
                                outputview.setText(nownum);
                            }
                            else if(confirm==1)//last one is operator or (
                            {
                                tempnum[count++]="(";
                                nownum+="(";
                                confirm2++;
                                confirm=1;
                                outputview.setText(nownum);
                            }
                        }
                    }
                else if (tempStr.contains("右括號")||tempStr.contains("右")) {
                        // TODO Auto-generated method stub
                        if(confirm2>0&&confirm==0)//avoid many ( input
                        {
                            nownum+=")";
                            tempnum[count++]=")";
                            confirm2--;
                            confirm=1;
                            confirm3=1;
                            outputview.setText(nownum);
                        }
                    }
                else if (tempStr.contains("回")||tempStr.contains("退")) {
                        // TODO Auto-generated method stub
                        if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='*' ||
                                nownum.charAt(nownum.length()-1)=='/' )
                        {
                            nownum=nownum.substring(0,nownum.length()-1);
                            tempnum[count--]=null;
                            confirm=0;
                            System.out.print(tempnum[count-1]);
                        }// if last char is operation
                        else if( nownum.charAt(nownum.length()-1)=='-' )
                        {
                            if(nownum.length()==1)
                            {
                                nownum="0";
                                count=0;
                                tempnum[count++]="0";
                                //confirm3=0;
                                confirm2=0;
                                confirm=1;
                                //System.out.print(tempnum[count]);
                            }
                            else{
                                nownum=nownum.substring(0,nownum.length()-1);
                                tempnum[count--]=null;
                                confirm=0;
                                //System.out.print(tempnum[count-1]);
                            }// if last char is '-'
                        }
                        else if(nownum.charAt(nownum.length()-1)=='('){
                            if(nownum.length()==1){
                                nownum="0";
                                count=0;
                                tempnum[count++]="0";
                                //confirm3=0;
                                confirm2=0;
                                confirm=1;
                                System.out.print(tempnum[count]);
                            }// if last char is '('
                            else{
                                nownum=nownum.substring(0,nownum.length()-1);
                                tempnum[count--]=null;
                                confirm2--;
                                confirm=0;
                            }

                        }//delete the last char and set the value of confirm
                        else if(nownum.charAt(nownum.length()-1)==')'){
                            nownum=nownum.substring(0,nownum.length()-1);
                            tempnum[count--]=null;
                            confirm2++;
                            confirm3=0;
                            confirm=0;

                        }// if last char is ')'  //delete the last char and set the value of confirm
                        else if(nownum.charAt(nownum.length()-1)=='√'){
                            if(nownum.length()==1){
                                nownum="0";
                                count=0;
                                tempnum[count++]="0";
                                confirm3=0;
                                confirm=1;
                                System.out.print(tempnum[count]);
                            }//if last char is '√'
                            else{
                                nownum=nownum.substring(0,nownum.length()-1);
                                tempnum[count--]=null;
                                if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='-' || nownum.charAt(nownum.length()-1)=='*' ||
                                        nownum.charAt(nownum.length()-1)=='/'||nownum.charAt(nownum.length()-1)=='('||nownum.charAt(nownum.length()-1)==')' )
                                    confirm=1;
                                else
                                    confirm=0;
                            }
                        }//delete the last char and set the value of confirm


                        else{
                            if(nownum.length()==1){
                                nownum="0";
                                count=0;
                                tempnum[count++]="0";
                                confirm=1;
                                confirm3=0;
                                dotconfirm=0;
                            }//delete the single number without connect with any operation

                            else if(tempnum[count-1].length()==1){
                                if(nownum.charAt(nownum.length()-1)=='.')
                                    dotconfirm=0;
                                //if the last char is .
                                nownum=nownum.substring(0,nownum.length()-1);
                                tempnum[count--]=null;
                                confirm=1;
                                //System.out.print(tempnum[count-1]);

                            }//delete the single-digit number behind the operation
                            else {
                                if(nownum.charAt(nownum.length()-1)=='.')
                                    dotconfirm=0;

                                nownum=nownum.substring(0,nownum.length()-1);
                                tempnum[count-1]=tempnum[count-1].substring(0,tempnum[count-1].length()-1);
                                System.out.print(tempnum[count-1]);
                            }//delete the Multi-digit number behind the operation
                        }
                        outputview.setText(nownum);

                    }
                else if (tempStr.contains("點")||tempStr.contains("電")) {
                        // TODO Auto-generated method stub
                        if(confirm3==0&&dotconfirm==0){//make sure every number just can have one dot and cant put behind )
                            if(nownum.substring(count)!="."){ // if first number is 0 > 0.
                                nownum+=".";
                                tempnum[count]=".";
                            }
                            if(confirm==1)// if last input is operator
                                tempnum[count++]=".";
                            else // if last input is number
                            {
                                tempnum[count-1]+=".";
                            }
                            confirm=0;
                            dotconfirm=1;
                            outputview.setText(nownum);
                            dog.setVisibility(View.INVISIBLE);// change icon
                            bird.setVisibility(View.INVISIBLE);// change icon
                        }
                    }
                else{
                    outputview.setVisibility(View.INVISIBLE);
                     wrongview.setVisibility(View.VISIBLE);
                }

            }
        }

    }

    void intopost(String input[],String postfix[],int count)
    {
        Stack=new double[50];
        int i=0;
        int top=0;
        int order=0;
        char buffer[] = new char[50];
        int confirm =0;
        for(int p=0;p<count;p++)
        {
            System.out.println(input[p]);
        }
        //System.out.print("iiiiii");
        //System.out.println("");
        for(i=0; i<count; i++)
        {
            confirm=0;
            if(input[i].length()==1)
            {
                switch(input[i].charAt(0))
                {
                    case'(':
                        confirm=1;
                        buffer[++top]=input[i].charAt(0);
                        break;
                    case'+':
                    case'-':
                    case'*':
                    case'/':
                        //System.out.print("in");
                        confirm=1;
                        while(prior(buffer[top])>=prior(input[i].charAt(0)))
                        {

                            // postfix[order].charAt(0)=buffer[top];
                            postfix[order] = String.valueOf(buffer[top]);
                            order++;
                            top--;
                            //  System.out.print(buffer[top]+"~~opinprior");
                        }
                        buffer[++top]=input[i].charAt(0);
                        // System.out.println(buffer[top]+"~~outop");
                        break;
                    case')':
                        confirm=1;
                        while(buffer[top]!='(')
                        {
                            //postfix[order].charAt(0)=buffer[top];
                            postfix[order] = String.valueOf(buffer[top]);
                            // System.out.println(buffer[top]+"~~(");
                            order++;
                            top--;
                        }
                        top--;
                        break;
                }
            }
            if(confirm==0)//put residual number into the postfix!
            {
                // System.out.println(input[i]+"~numin");
                postfix[order] = input[i];
                System.out.println(input[i]+"~numin2");
                order++;
            }
        }
        //  System.out.println(top+"num");
        while(top>0)
        {
            //System.out.print("top>0in");

            //	System.out.println(String.valueOf(buffer[top])+"@@@");
            postfix[order] = String.valueOf(buffer[top]);
            order++;
		              /*for(int p=0;p<order;p++)
				        {
				            	System.out.print(postfix[p]);

				        }
			          	System.out.print("!!!");
				        System.out.println("");*/
            top--;
        }
    }
    int prior( char buffer )
    {
        int pvalue=0;
        switch(buffer)
        {
            case'*':
                pvalue=2;
                break;
            case'/':
                pvalue=2;
                break;
            case'+':
                pvalue=1;
                break;
            case'-':
                pvalue=1;
                break;
        }
        return pvalue;
    }
    public double calculate(double stack[],String postfix[],int count)
    {
        int i=0;
        int item=0;
        double ans=0;
        int numamount=0;
        int opamount=0;

        for(i=0; i<count; i++)
        {
            if(postfix[i]==null)
            {
                break;//avoid null information in postfix
            }
            if(postfix[i].charAt(0)!='*'&&postfix[i].charAt(0)!='+'&&postfix[i].charAt(0)!='-'&&postfix[i].charAt(0)!='/')
            {
                //System.out.println(postfix[i]+"num!!!");
                //System.out.println(postfix[1]);
                if(postfix[i].charAt(0)=='√') {
                   // System.out.println("debug:"+postfix[i].substring(1));
                    if(postfix[i].substring(1).equals("")) {
                        return -1345445.2378989;
                    }
                    else
                    {
                        stack[item] = Math.sqrt(Double.parseDouble(postfix[i].substring(1)));
                        System.out.println("***"+postfix[i].substring(1));

                    }
                }
                else
                    stack[item]=Double.parseDouble(postfix[i]);//use it to store tmp num
                System.out.println( stack[item]+"stack");
                ans=stack[item];
                item++;
                numamount++;

            }
            else if(postfix[i].charAt(0)=='-'&&postfix[i].length()>1)//use to calculate negative
            {
                stack[item]=Double.parseDouble(postfix[i]);//use it to store tmp num
               // System.out.println("-in");
                ans=stack[item];
                item++;
                numamount++;
            }
            else
            {
                System.out.println(postfix[i]+"op!!!!!");
                opamount++;
                switch(postfix[i].charAt(0))
                {
                    case'+'://+ function
                        if((item-2)<0||(item-1)<0)
                        {
                            return -1345445.2378989 ;
                        }
                        ans=stack[item-2]+stack[item-1];
                        stack[item-2]=ans;
                        item--;
                        break;
                    case'-'://- function
                        if((item-2)<0||(item-1)<0)
                        {
                            return -1345445.2378989;
                        }
                        ans=stack[item-2]-stack[item-1];
                        stack[item-2]=ans;
                        item--;
                        break;
                    case'*'://* function
                        if((item-2)<0||(item-1)<0)
                        {
                            return -1345445.2378989;
                        }
                        ans=stack[item-2]*stack[item-1];
                        stack[item-2]=ans;
                        item--;
                        break;
                    case'/':/// function
                        if((item-2)<0||(item-1)<0)
                        {
                            return -1345445.2378989;
                        }
                        ans=stack[item-2]/stack[item-1];
                        if(stack[item-1]==0)
                            return -1345445.2378989;
                        stack[item-2]=ans;
                        item--;
                        break;

                }


            }
            if(numamount-1!=opamount )
            {
                ans=-1345445.2378989;
            }
        }

        System.out.println("ans:"+ans);
        return ans;
    }//use it to caculate the postfix
}
