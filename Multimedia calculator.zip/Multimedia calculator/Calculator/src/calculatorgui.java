import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;
import java.math.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.text.DecimalFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import com.apple.eawt.Application;

import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.frontend.util.Microphone;
import edu.cmu.sphinx.recognizer.Recognizer;
import edu.cmu.sphinx.result.Result;
import edu.cmu.sphinx.util.props.ConfigurationManager;


 public class calculatorgui extends JFrame{

	 double Stack[] ;
     String tempnum[]=new String[50];
     String postfix[]=new String[50];
     char tempost;
	 int count=0;
	 int confirm=1;// operator and number confirm
	 int confirm2=0;// ( ) matching confirm
	 int confirm3=0;// ) fool proofing
	 int dotconfirm=0;
	 String nownum="0";
	 JPanel showPanel = new JPanel(null);
	 JTextArea showLabel= new JTextArea(100,100);

		        public calculatorgui(){
		        	//Application application = Application.getApplication();
		        	Image image = Toolkit.getDefaultToolkit().getImage("logo.png");
		        	//application.setDockIconImage(image);
				 

		        	Icon dogicon = new ImageIcon( "images.png" );
			        final JLabel iconlabel =new JLabel(dogicon);
				    iconlabel.setBounds(153, 332, 200, 148);
				    getContentPane().add(iconlabel);//image1
				    
				    Icon birdicon = new ImageIcon( "bird.png" );
			        final JLabel iconlabel1 =new JLabel(birdicon);
				    iconlabel1.setBounds(2, 333, 100, 92);
				    getContentPane().add(iconlabel1);//image2
				    
				    Icon twoicon = new ImageIcon( "two.png" );
			        JLabel iconlabel2 =new JLabel(twoicon);
				    iconlabel2.setBounds(190, 327, 150, 110);
				    getContentPane().add(iconlabel2);//image3
				
		        	for(int p=0;p<50;p++)
		        	{
		        		tempnum[p]=null;//initialize input array
		        	}
		        	tempnum[count++]="0";//avoid first number calculation
		                Container content = getContentPane();
			        content.setBackground(Color.white);
			        getContentPane().setLayout(null);
			        showPanel.setBounds(0, 368, 390, -368);
			        content.add(showPanel);

			        final JLabel lbl2NewLabel = new JLabel("Error! Please click C!",JLabel.RIGHT);
			        final JLabel lblNewLabel = new JLabel(""+nownum,JLabel.RIGHT);
			        lbl2NewLabel.setBounds(10, 10, 338, 78);
			        lblNewLabel.setBounds(10, 10, 338, 78);
			        getContentPane().add(lbl2NewLabel);
			        lbl2NewLabel.setVisible(false);
			        getContentPane().add(lblNewLabel);

			        JButton btn_1 = new JButton("1");
			        btn_1.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="1";
			        			count--;
			        		}
			        		else nownum+="1";
			        		if(confirm==1)//indicate that the last input is operator
			        			tempnum[count++]="1";
			        		else//indicate that the last input is number
			        			tempnum[count-1]+="1";
			        		confirm=0;// use to divide the operator or number
			        		lblNewLabel.setText(nownum);
			        		//System.out.print(tempnum[count-1]);
			        	}}
			        });
			        btn_1.setBounds(10, 244, 60, 40);
			        getContentPane().add(btn_1);

			        JButton btn_2 = new JButton("2");
			        btn_2.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="2";
			        			count--;
			        		}
			        		else nownum+="2";
			        		if(confirm==1)
			        			tempnum[count++]="2";
			        		else
			        			tempnum[count-1]+="2";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        		//System.out.print(tempnum[count-1]);

			        	}}
			        });
			        btn_2.setBounds(80, 244, 60, 40);
			        getContentPane().add(btn_2);

			        JButton btn_3 = new JButton("3");
			        btn_3.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="3";
			        			count--;
			        		}
			        		else  nownum+="3";
			        		if(confirm==1)
			        			tempnum[count++]="3";
			        		else
			        			tempnum[count-1]+="3";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_3.setBounds(150, 244, 60, 40);
			        getContentPane().add(btn_3);

			        JButton btn_4 = new JButton("4");
			        btn_4.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="4";
			        			count--;
			        		}
			        		else  nownum+="4";
			        		if(confirm==1)
			        			tempnum[count++]="4";
			        		else
			        			tempnum[count-1]+="4";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_4.setBounds(10, 194, 60, 40);
			        getContentPane().add(btn_4);

			        JButton btn_5 = new JButton("5");
			        btn_5.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="5";
			        			count--;
			        		}
			        		else  nownum+="5";
			        		if(confirm==1)
			        			tempnum[count++]="5";
			        		else
			        			tempnum[count-1]+="5";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_5.setBounds(80, 194, 60, 40);
			        getContentPane().add(btn_5);

			        JButton btn_6 = new JButton("6");
			        btn_6.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="6";
			        			count--;
			        		}
			        		else  nownum+="6";
			        		if(confirm==1)
			        			tempnum[count++]="6";
			        		else
			        			tempnum[count-1]+="6";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_6.setBounds(150, 194, 60, 40);
			        getContentPane().add(btn_6);

			        JButton btn_7 = new JButton("7");
			        btn_7.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="7";
			        			count--;
			        		}
			        		else  nownum+="7";
			        		if(confirm==1)
			        			tempnum[count++]="7";
			        		else
			        			tempnum[count-1]+="7";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_7.setBounds(10, 144, 60, 40);
			        getContentPane().add(btn_7);

			        JButton btn_8 = new JButton("8");
			        btn_8.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="8";
			        			count--;
			        		}
			        		else  nownum+="8";
			        		if(confirm==1)
			        			tempnum[count++]="8";
			        		else
			        			tempnum[count-1]+="8";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_8.setBounds(80, 144, 60, 40);
			        getContentPane().add(btn_8);

			        JButton btn_9 = new JButton("9");
			        btn_9.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="9";
			        			count--;
			        		}
			        		else  nownum+="9";
			        		if(confirm==1)
			        			tempnum[count++]="9";
			        		else
			        		{
			        	      //System.out.println("##");
			        			tempnum[count-1]+="9";
			        		}
			        	//  System.out.println(tempnum[count-1]);
			        	//	System.out.print("!!!!tem");
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_9.setBounds(150, 144, 60, 40);
			        getContentPane().add(btn_9);

			        JButton btn_point = new JButton(".");
			        btn_point.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0&&dotconfirm==0){//make sure every number just can have one dot and cant put behind ) 
			        		if(nownum.substring(count)!="."){ // if first number is 0 > 0.
			        			nownum+=".";
			        		    tempnum[count]=".";
			        		}
			        		if(confirm==1)// if last input is operator
			        			tempnum[count++]=".";
			        		else // if last input is number 
			        		{
			        			tempnum[count-1]+=".";
			        		}
			        		confirm=0;
			        		dotconfirm=1;
			        		lblNewLabel.setText(nownum);	        		 
						    iconlabel.setVisible(false);// change icon
						    iconlabel1.setVisible(false);
			        	}}
			        });
			        btn_point.setBounds(150, 292, 60, 40);
			        getContentPane().add(btn_point);

			        JButton btn_0 = new JButton("0");
			        btn_0.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="0";
			        			count--;
			        		}
			        		else
			        			nownum+="0";
			        		if(confirm==1)
			        			tempnum[count++]="0";
			        		else
			        			tempnum[count-1]+="0";
			        		confirm=0;
			        		lblNewLabel.setText(nownum);
			        	}}
			        });
			        btn_0.setBounds(10, 294, 130, 37);
			        getContentPane().add(btn_0);

			        JButton btn_plus = new JButton("+");
			        btn_plus.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
			        			nownum+="+";
			        		    tempnum[count++]="+";
			        		    confirm=1;
			        		    confirm3=0;
			        		    dotconfirm=0;
			        		    lblNewLabel.setText(nownum);
			        		}// avoid double keyin operator
			        	}
			        });
			        btn_plus.setBounds(220, 292, 60, 40);
			        getContentPane().add(btn_plus);

			        JButton btn_minus = new JButton("-");
			        btn_minus.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
			        			nownum+="-";
			        		    tempnum[count++]="-";
			        		    confirm=1;
			        		    confirm3=0;
			        		    dotconfirm=0;
			        		    lblNewLabel.setText(nownum);
			        		}
			        	}
			        });
			        btn_minus.setBounds(220, 244, 60, 40);
			        getContentPane().add(btn_minus);

			        JButton btn_multiple = new JButton("*");
			        btn_multiple.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
			        			nownum+="*";
			        		    tempnum[count++]="*";
			        		    confirm=1;
			        		    confirm3=0;
			        		    dotconfirm=0;
			        		    lblNewLabel.setText(nownum);
			        		}
			        	}
			        });
			        btn_multiple.setBounds(220, 194, 60, 40);
			        getContentPane().add(btn_multiple);

			        JButton btn_divide = new JButton("/");
			        btn_divide.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {

			        		if(nownum.charAt(nownum.length()-1)!='+'&&nownum.charAt(nownum.length()-1)!='-'&&nownum.charAt(nownum.length()-1)!='*'&&nownum.charAt(nownum.length()-1)!='/'&&nownum.charAt(nownum.length()-1)!='('){
			        			nownum+="/";
			        		    tempnum[count++]="/";
			        		    confirm=1;
			        		    confirm3=0;
			        		    dotconfirm=0;
			        		    lblNewLabel.setText(nownum);
			        		  //System.out.print(tempnum[count-1]);
			        		}
			        	}
			        });
			        btn_divide.setBounds(220, 144, 60, 40);
			        getContentPane().add(btn_divide);

			        JButton btn_equal = new JButton("=");
			        btn_equal.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {

			        		if(confirm2>0||nownum.charAt(nownum.length()-1)=='.')//avoid ( ) matching problem
			        		{
			        			lblNewLabel.setVisible(false);
			        	    	lbl2NewLabel.setVisible(true);
			        		}
			        		else{
			        		intopost(tempnum,postfix,count);//turn infix to postfix
			        		for(int p=0;p<count;p++)
			        			System.out.print(postfix[p]);
			        	//	System.out.println("KKKKKKK");
			        	//  nownum=Double.toString(calculate(Stack,postfix,count));
			        		DecimalFormat f = new DecimalFormat("#################.#################");//format double to avoid residual 0 
			        		nownum =f.format(calculate(Stack,postfix,count));//make calculation
			          //    nownum = String.format("%g", calculate(Stack,postfix,count));

			        		for(int p=0;p<50;p++)
			        		{
			        			tempnum[p]=null;
			        			postfix[p]=null;
			        		}
			        		
			        		tempnum[0]=nownum;
			        		count=1;
			        		System.out.println(nownum+"!!!!!!!!!");			        		

			        		if(nownum.contains("-1345445.2378989"))
			        	    {
			        	    	lblNewLabel.setVisible(false);
			        	    	lbl2NewLabel.setVisible(true);
			        	    }
			        	    else
			        	    	lblNewLabel.setText(nownum);
			        		}		        		
			        		
			        		dotconfirm=0;
			        		confirm3=0;
			        		confirm2=0;
						    iconlabel.setVisible(false);//change the icon
						    iconlabel1.setVisible(false);//change the icon
			        	}
			        });
			        btn_equal.setBounds(290, 242, 58, 90);
			        getContentPane().add(btn_equal);

			        JButton btn_root = new JButton("��");
			        btn_root.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm3==0){
			        		if(nownum=="0")
			        		{
			        			nownum="��";
			        			count--;
			        			tempnum[count]="��";
			        		}
			        		else if(nownum.charAt(nownum.length()-1)=='+'&&nownum.charAt(nownum.length()-1)=='-'&&nownum.charAt(nownum.length()-1)=='*'&&nownum.charAt(nownum.length()-1)!='/')
			        			nownum+="��";
			        		if(confirm==1)
			        		{
			        			if(nownum.charAt(nownum.length()-1)!='��')
			        			nownum+="��";
			        			tempnum[count++]="��";
			        		}
			        		lblNewLabel.setText(nownum);
			        		  confirm=0;
			        	}}
			        });
			        btn_root.setBounds(288, 192, 60, 40);
			        getContentPane().add(btn_root);

			        JButton btn_Clear = new JButton("C");
			        btn_Clear.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		lblNewLabel.setVisible(true);
			        		lbl2NewLabel.setVisible(false);
			        		nownum="0";
			        		count=0;
			        		for(int p=0;p<50;p++)
			        		{
			        			tempnum[p]=null;
			        			postfix[p]=null;
			        		}
			        		tempnum[count++]="0";
			        		lblNewLabel.setText(nownum);
			        		dotconfirm=0;
			        		confirm=1;
			        		confirm2=0;
			        		confirm3=0;			        		 
						    iconlabel.setVisible(true);// change the icon
						    iconlabel1.setVisible(true);// change the icon
			        	}
			        });
			        btn_Clear.setBounds(288, 144, 60, 40);
			        getContentPane().add(btn_Clear);

			        JButton rightparentheses = new JButton("(");
			        rightparentheses.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent arg0) {
			        		if(confirm3==0){//cant add after (
			        		if(nownum=="0")
			        		{
			        			count--;
			        			nownum="(";
			        			tempnum[count++]="(";
			        			confirm2++;
			        			confirm=1;
			        			lblNewLabel.setText(nownum);	
			        		}	
			        		else if(confirm==1)//last one is operator or (
			        		{
			        			tempnum[count++]="(";
			        			nownum+="(";
			        			confirm2++;
			        			confirm=1;
			        			lblNewLabel.setText(nownum);	
			        		}	   
			        	}}
			        });
			        rightparentheses.setBounds(10, 98, 60, 40);
			        getContentPane().add(rightparentheses);

			        JButton leftparentheses = new JButton(")");
			        leftparentheses.addActionListener(new ActionListener() {
			        	public void actionPerformed(ActionEvent e) {
			        		if(confirm2>0&&confirm==0)//avoid many ( input
			        		{
			        			nownum+=")";
			        			tempnum[count++]=")";
			        			confirm2--;
			        			confirm=1;
			        			confirm3=1;
			        			lblNewLabel.setText(nownum);	
			        		}		        		        					        		
			        	}
			        });
			        leftparentheses.setBounds(80, 98, 60, 40);
			        getContentPane().add(leftparentheses);

			        final JButton btn_start = new JButton("��");
                    final JButton btn_over = new JButton("��");
                    btn_start.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                    btn_over.setVisible(true);
                                    btn_start.setVisible(false);
                                   
                        			
                            }
                    });
                    btn_start.setBounds(150, 98, 60, 40);
                    getContentPane().add(btn_start);
                  //voice start button when you click it the over button will be hidden
                    
                    btn_over.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                    btn_over.setVisible(false);
                                    btn_start.setVisible(true);
                            }
                    });  
                    btn_over.setBounds(150, 98, 60, 40);
                    getContentPane().add(btn_over);
                    btn_over.setVisible(false);
        //voice stop button when you click it the start button will be hidden 
                    
                    JButton btn_backspace = new JButton("��");//click the backspae button to delete the last character
                    btn_backspace.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                             if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='*' || 
                                       nownum.charAt(nownum.length()-1)=='/' )
                                    {
                                    nownum=nownum.substring(0,nownum.length()-1);
                                    tempnum[count--]=null;
                                    confirm=0;
                                    System.out.print(tempnum[count-1]);
                                    }// if last char is operation
                             else if( nownum.charAt(nownum.length()-1)=='-' )
                             {
                                     if(nownum.length()==1)
                                     {
                                                    nownum="0";
                                                    count=0;
                                                    tempnum[count++]="0";
                                                    //confirm3=0;
                                                    confirm2=0;
                                                    confirm=1;
                                                    //System.out.print(tempnum[count]);
                                                    }
                             else{
                                     nownum=nownum.substring(0,nownum.length()-1);
                                            tempnum[count--]=null;
                                            confirm=0;
                                            //System.out.print(tempnum[count-1]);
                                 }// if last char is '-'
                             }
                            else if(nownum.charAt(nownum.length()-1)=='('){
                                            if(nownum.length()==1){
                                                    nownum="0";
                                                    count=0;
                                                    tempnum[count++]="0";
                                                    //confirm3=0;
                                                    confirm2=0;
                                                    confirm=1;
                                                    System.out.print(tempnum[count]);
                                                    }// if last char is '('
                                            else{
                                            nownum=nownum.substring(0,nownum.length()-1);
                                            tempnum[count--]=null;
                                            confirm2--;
                                            confirm=0;
                                            }
                                            
                                    }//delete the last char and set the value of confirm
                                    else if(nownum.charAt(nownum.length()-1)==')'){
                                            nownum=nownum.substring(0,nownum.length()-1);
                                            tempnum[count--]=null;
                                            confirm2++;
                                            confirm3=0;
                                            confirm=0;
                                            
                                    }// if last char is ')'  //delete the last char and set the value of confirm
                                    else if(nownum.charAt(nownum.length()-1)=='��'){
                                            if(nownum.length()==1){
                                                    nownum="0";
                                                    count=0;
                                                    tempnum[count++]="0";
                                                    confirm3=0;
                                                    confirm=1;
                                                    System.out.print(tempnum[count]);
                                                    }//if last char is '��' 
                                            else{
                                                    nownum=nownum.substring(0,nownum.length()-1);
                                                    tempnum[count--]=null;
                                                    if(nownum.charAt(nownum.length()-1)=='+' || nownum.charAt(nownum.length()-1)=='-' || nownum.charAt(nownum.length()-1)=='*' || 
                                                                       nownum.charAt(nownum.length()-1)=='/'||nownum.charAt(nownum.length()-1)=='('||nownum.charAt(nownum.length()-1)==')' )
                                                    confirm=1;
                                                    else
                                                    confirm=0;
                                            }
                                    }//delete the last char and set the value of confirm
                                    
            
                            else{
                                            if(nownum.length()==1){
                                                    nownum="0";
                                                    count=0;
                                                    tempnum[count++]="0";
                                                    confirm=1;
                                                    confirm3=0;
                                                    dotconfirm=0;
                                                    }//delete the single number without connect with any operation
                                    
                                            else if(tempnum[count-1].length()==1){
                                                    if(nownum.charAt(nownum.length()-1)=='.')
                                                            dotconfirm=0;
                                                    //if the last char is .  
                                            nownum=nownum.substring(0,nownum.length()-1);
                                            tempnum[count--]=null;
                                            confirm=1;
                                            //System.out.print(tempnum[count-1]);
                                            
                                        }//delete the single-digit number behind the operation
                                        else {
                                                if(nownum.charAt(nownum.length()-1)=='.')
                                                            dotconfirm=0;
                                                            
                                            nownum=nownum.substring(0,nownum.length()-1);
                                            tempnum[count-1]=tempnum[count-1].substring(0,tempnum[count-1].length()-1);
                                            System.out.print(tempnum[count-1]);
                                            }//delete the Multi-digit number behind the operation
                                    }
                                    lblNewLabel.setText(nownum);
                                    
                            }
                    });
                    btn_backspace.setBounds(220, 98, 128, 40);
                    getContentPane().add(btn_backspace);

		        	setSize(364,460 );
		        	setVisible( true );
			        setResizable(false);
			        setTitle("�p���");

		        }

		 public double calculate(double stack[],String postfix[],int count)
		        {
		            int i=0;
		            int item=0;
		            double ans=0;
		            int numamount=0;
		            int opamount=0;

		            for(i=0; i<count; i++)
		            {
		                if(postfix[i]==null)
		                {
		                    break;//avoid null information in postfix
		                }
		                if(postfix[i].charAt(0)!='*'&&postfix[i].charAt(0)!='+'&&postfix[i].charAt(0)!='-'&&postfix[i].charAt(0)!='/')
		                {
		                	System.out.println(postfix[i]+"num!!!");
		                	if(postfix[i].charAt(0)=='��')
		                		stack[item]=Math.sqrt(Double.parseDouble(postfix[i].substring(1)));
		                	else
		                		stack[item]=Double.parseDouble(postfix[i]);//use it to store tmp num
		                    System.out.println( stack[item]+"stack");
		                    ans=stack[item];
		                    item++;
		                    numamount++;

		                }
		                else if(postfix[i].charAt(0)=='-'&&postfix[i].length()>1)//use to calculate negative
		                {
		                	stack[item]=Double.parseDouble(postfix[i]);//use it to store tmp num
		                    System.out.println("-in");
		                    ans=stack[item];
		                    item++;
		                    numamount++;       	
		                }
		                else
		                {
		                	System.out.println(postfix[i]+"op!!!!!");
		                    opamount++;
		                    switch(postfix[i].charAt(0))
		                    {
		                    case'+'://+ function
		                        if((item-2)<0||(item-1)<0)
		                        {
		                            return -1345445.2378989 ;
		                        }
		                        ans=stack[item-2]+stack[item-1];
		                        stack[item-2]=ans;
		                        item--;
		                        break;
		                    case'-'://- function
		                        if((item-2)<0||(item-1)<0)
		                        {
		                            return -1345445.2378989;
		                        }
		                        ans=stack[item-2]-stack[item-1];
		                        stack[item-2]=ans;
		                        item--;
		                        break;
		                    case'*'://* function
		                        if((item-2)<0||(item-1)<0)
		                        {
		                            return -1345445.2378989;
		                        }
		                        ans=stack[item-2]*stack[item-1];
		                        stack[item-2]=ans;
		                        item--;
		                        break;
		                    case'/':/// function
		                        if((item-2)<0||(item-1)<0)
		                        {
		                            return -1345445.2378989;
		                        }
		                        ans=stack[item-2]/stack[item-1];
		                        if(stack[item-1]==0)
		                        	return -1345445.2378989;
		                        stack[item-2]=ans;
		                        item--;
		                        break;

		                    }


		                }
		                if(numamount-1!=opamount )
		                {
		                    ans=-1345445.2378989;
		                }
		            }
		            
		            System.out.println("ans:"+ans);
		            return ans;
		        }//use it to caculate the postfix
		        void intopost(String input[],String postfix[],int count)
		        {
		        	Stack=new double[50];
		            int i=0;
		            int top=0;
		            int order=0;
		            char buffer[] = new char[50];
		            int confirm =0;
		            for(int p=0;p<count;p++)
		            {
		            	System.out.println(input[p]);
		            }
		            	System.out.print("iiiiii");
		            System.out.println("");
		            for(i=0; i<count; i++)
		            {
		                confirm=0;
		                if(input[i].length()==1)
		                {
		                switch(input[i].charAt(0))
		                {
		                case'(':
		                    confirm=1;
		                    buffer[++top]=input[i].charAt(0);
		                    break;
		                case'+':
		                case'-':
		                case'*':
		                case'/':
		                  //System.out.print("in");
		                    confirm=1;
		                    while(prior(buffer[top])>=prior(input[i].charAt(0)))
		                    {

		                       // postfix[order].charAt(0)=buffer[top];
		                    	postfix[order] = String.valueOf(buffer[top]);
		                        order++;
		                        top--;
		                    //  System.out.print(buffer[top]+"~~opinprior");
		                    }
		                    buffer[++top]=input[i].charAt(0);
		                 // System.out.println(buffer[top]+"~~outop");
		                    break;
		                case')':
		                    confirm=1;
		                    while(buffer[top]!='(')
		                    {
		                      //postfix[order].charAt(0)=buffer[top];
		                    	postfix[order] = String.valueOf(buffer[top]);
		                      // System.out.println(buffer[top]+"~~(");
		                        order++;
		                        top--;
		                    }
		                    top--;
		                    break;
		                }
		                }
		                if(confirm==0)//put residual number into the postfix!
		                {
		              	  // System.out.println(input[i]+"~numin");
		              	     postfix[order] = input[i];
		              	     System.out.println(input[i]+"~numin2");
		                     order++;
		                }
		            }
		        //  System.out.println(top+"num");
		            while(top>0)
		            {
		            	//System.out.print("top>0in");

		            //	System.out.println(String.valueOf(buffer[top])+"@@@");
		            	postfix[order] = String.valueOf(buffer[top]);
		                order++;
		              /*for(int p=0;p<order;p++)
				        {
				            	System.out.print(postfix[p]);

				        }
			          	System.out.print("!!!");
				        System.out.println("");*/
		                top--;
		            }
		        }
		        int prior( char buffer )
		        {
		            int pvalue=0;
		            switch(buffer)
		            {
		            case'*':
		                pvalue=2;
		                break;
		            case'/':
		                pvalue=2;
		                break;
		            case'+':
		                pvalue=1;
		                break;
		            case'-':
		                pvalue=1;
		                break;
		            }
		            return pvalue;
		        }

 public static void main (String args[] ) throws Exception{
	 calculatorgui  application = new  calculatorgui ();
}
}
