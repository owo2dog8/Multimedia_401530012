-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- 主機: 127.0.0.1
-- 產生時間： 2016-06-19: 15:03:47
-- 伺服器版本: 5.6.24
-- PHP 版本： 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫： `multifinal`
--

-- --------------------------------------------------------

--
-- 資料表結構 `css`
--

CREATE TABLE IF NOT EXISTS `css` (
  `account` varchar(50) NOT NULL,
  `css_1` int(11) NOT NULL DEFAULT '0',
  `css_2` int(11) NOT NULL DEFAULT '0',
  `css_3` int(11) NOT NULL DEFAULT '0',
  `css_4` int(11) NOT NULL DEFAULT '0',
  `css_5` int(11) NOT NULL DEFAULT '0',
  `css_6` int(11) NOT NULL DEFAULT '0',
  `progress` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `css`
--

INSERT INTO `css` (`account`, `css_1`, `css_2`, `css_3`, `css_4`, `css_5`, `css_6`, `progress`) VALUES
('owo2dog8@yahoo.com.tw', 0, 1, 0, 0, 0, 0, 17),
('wetwet', 1, 1, 0, 0, 0, 0, 33);

-- --------------------------------------------------------

--
-- 資料表結構 `html`
--

CREATE TABLE IF NOT EXISTS `html` (
  `account` varchar(50) NOT NULL,
  `html_1` int(5) NOT NULL DEFAULT '0',
  `html_2` int(5) NOT NULL DEFAULT '0',
  `html_3` int(5) NOT NULL DEFAULT '0',
  `html_4` int(5) NOT NULL DEFAULT '0',
  `html_5` int(5) NOT NULL DEFAULT '0',
  `progress` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `html`
--

INSERT INTO `html` (`account`, `html_1`, `html_2`, `html_3`, `html_4`, `html_5`, `progress`) VALUES
('owo2dog8@yahoo.com.tw', 1, 1, 0, 0, 0, 40),
('wetwet', 1, 1, 0, 0, 0, 40);

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `name` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `account` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `member`
--

INSERT INTO `member` (`name`, `account`, `password`, `gender`) VALUES
('簡智佳', 'owo2dog8@yahoo.com.tw', '123', 'female'),
('qwerq', 'wetwet', 'wetwet', 'male');

-- --------------------------------------------------------

--
-- 資料表結構 `php`
--

CREATE TABLE IF NOT EXISTS `php` (
  `account` varchar(50) NOT NULL,
  `php_1` int(11) NOT NULL DEFAULT '0',
  `php_2` int(11) NOT NULL DEFAULT '0',
  `php_3` int(11) NOT NULL DEFAULT '0',
  `php_4` int(11) NOT NULL DEFAULT '0',
  `php_5` int(11) NOT NULL DEFAULT '0',
  `php_6` int(11) NOT NULL DEFAULT '0',
  `progress` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `php`
--

INSERT INTO `php` (`account`, `php_1`, `php_2`, `php_3`, `php_4`, `php_5`, `php_6`, `progress`) VALUES
('owo2dog8@yahoo.com.tw', 1, 0, 0, 0, 0, 0, 17),
('wetwet', 1, 1, 1, 1, 1, 1, 100);

-- --------------------------------------------------------

--
-- 資料表結構 `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `account` varchar(50) NOT NULL,
  `phptest_1` int(11) NOT NULL DEFAULT '0',
  `htmltest_2` int(11) NOT NULL DEFAULT '0',
  `csstest_3` int(11) NOT NULL DEFAULT '0',
  `htmltest_4` int(11) NOT NULL DEFAULT '0',
  `csstest_5` int(11) NOT NULL DEFAULT '0',
  `phptest_6` int(11) NOT NULL DEFAULT '0',
  `csstest_7` int(11) NOT NULL DEFAULT '0',
  `htmltest_8` int(11) NOT NULL DEFAULT '0',
  `phptest_9` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 資料表的匯出資料 `test`
--

INSERT INTO `test` (`account`, `phptest_1`, `htmltest_2`, `csstest_3`, `htmltest_4`, `csstest_5`, `phptest_6`, `csstest_7`, `htmltest_8`, `phptest_9`) VALUES
('owo2dog8@yahoo.com.tw', 1, 1, 0, 0, 0, 0, 0, 0, 0),
('wetwet', 1, 1, 0, 0, 0, 0, 0, 1, 0);

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `css`
--
ALTER TABLE `css`
  ADD PRIMARY KEY (`account`), ADD UNIQUE KEY `account` (`account`);

--
-- 資料表索引 `html`
--
ALTER TABLE `html`
  ADD PRIMARY KEY (`account`), ADD UNIQUE KEY `account` (`account`);

--
-- 資料表索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`account`), ADD UNIQUE KEY `account` (`account`), ADD UNIQUE KEY `account_2` (`account`);

--
-- 資料表索引 `php`
--
ALTER TABLE `php`
  ADD PRIMARY KEY (`account`), ADD UNIQUE KEY `account` (`account`);

--
-- 資料表索引 `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`account`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
