<?php
	require_once("connMysql.php");//連接資料庫
	$destination = "login.php";
	if(isset($_POST['account']) && isset($_POST['password'])){
		$query_RecProduct = 'SELECT * FROM member WHERE account = "'.$_POST['account'].'";';
		$RecProduct = mysql_query($query_RecProduct);
		if($RecProduct){
			$row = mysql_fetch_assoc($RecProduct);
			if($row['password'] === $_POST['password']){
				echo '<script language="javascript"> alert("登入成功!!! ");</script>';
				session_start();
				$_SESSION['account'] = $row['account'];
				$_SESSION['password'] = $row['password'];
				$_SESSION['name'] = $row['name'];
				$_SESSION['user'] = "user";
				$destination = "homepage.php";
				}
		
		else{
			echo '<script language="javascript"> alert("資料輸入錯誤唷>.0");</script>';
		}
	}
	}
	else{
		echo '<script language="javascript"> alert("資料沒輸入完整唷OvO");</script>';
	}
	if($destination == 'login.php')
		header("refresh:0; url = $destination");
	else
	//echo '<script language="javascript"> window.parent.location.href="first.php";</script>';
?>

<html>
<head>
	<style type = "text/CSS">

	</style>
</head>
<body>
	<div id = "msg" align = "center">
	<?php 
	header("refresh:0; url = $destination");
	?></div>
</body>
</html>