<?php
	$hint = '';
	$go = 'register.php';
	if(isset($_POST['account']) && isset($_POST['password']) && isset($_POST['re_password'])&& isset($_POST['name']) && isset($_POST['gender'])){
			
		if($_POST['password'] != $_POST['re_password']){
			$go = 'register.php';
			echo '<script language="javascript"> alert("密碼確認錯誤");</script>';
		}
		else{
			require_once("connMysql.php");
			$query_RecProduct = 'SELECT account FROM member WHERE account = "'.$_POST['account'].'";';
			$RecProduct = mysql_query($query_RecProduct);
			$row = mysql_fetch_assoc($RecProduct);
			if(!$row['account']){
				$query = 'insert into member (name,account,password,gender)
				values ("'.$_POST['name'].'","'.$_POST['account'].'","'.$_POST['password'].'","'.$_POST['gender'].'");';
				$RecProduct2 = mysql_query($query);
				$query3 = 'insert into html (account)
				values ("'.$_POST['account'].'");';
				$RecProduct3 = mysql_query($query3);
				$query4 = 'insert into css (account)
				values ("'.$_POST['account'].'");';
				$RecProduct4 = mysql_query($query4);
				$query5 = 'insert into php (account)
				values ("'.$_POST['account'].'");';
				$RecProduct5 = mysql_query($query5);
				$query6 = 'insert into test (account)
				values ("'.$_POST['account'].'");';
				$RecProduct6 = mysql_query($query6);
				echo '<script language="javascript"> alert("註冊成功");</script>';
			}
			else{
				echo '<script language="javascript"> alert("帳號已存在");</script>';
			}
		}
	}
	else{
		echo '<script language="javascript"> alert("尚有資料未填入~");</script>';
	}

		header("refresh:0; url = homepage.php");


?>
