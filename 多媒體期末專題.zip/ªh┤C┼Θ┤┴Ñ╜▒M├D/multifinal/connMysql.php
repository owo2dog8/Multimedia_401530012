<?php
	//資料庫主機設定
	$db_host = "127.0.0.1";
	$db_username = "root";
	$db_password = "";
	//連線伺服器
	$db_link = @mysql_connect($db_host, $db_username, $db_password);
	if (!$db_link) die("資料連結失敗！");
	//設定字元集與連線校對
	mysql_query("SET NAMES 'utf8'");
	if(!@mysql_select_db("multifinal")) die("資料庫選擇失敗!");
?>