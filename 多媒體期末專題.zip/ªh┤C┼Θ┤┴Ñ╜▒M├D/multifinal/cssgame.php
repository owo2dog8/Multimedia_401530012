<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="cssgame.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
 	
function messageGo(){

  var proper= $('#proper').val();                                   
  var val = $('#val').val();                                           

    $.ajax({

    url:"cssgame.php",                                                              
    data: { "propers" : proper , "vals" :val },  
    // 要傳遞的資料要包成 json 格式喔，你原本做法比較像是 GET
    // php 網頁用 $_POST['propers'] , $_POST['vals'] 就可以得到內容
    // 例如你 js 寫 var proper = 1 ， 在這樣傳，php 裡面用 $_POST['propers'] 就會等於 1
    type : "POST",                                                                    
    //dataType:'json', 
    // 為甚麼是 json呢? 你要調用 json格式的檔案嗎？
  
    success:function(response){  
    	if (response.success) {
		$('#proper').html(response.msg);
		$('#val').html(val.msg);
	}
        // data 為回傳的 php網頁內容 (轉成html e.g. <?php echo "123"; ?> 你收到的只是 123 而已)
        alert("成功");
    },   
    error:function(err){                                                                 
        // err 裡面有一些錯誤訊息
        alert("失敗");
    }       

}); 

};


	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="hompage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="hompage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li ><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li class="current_page_item"><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>CSS遊戲-佔地為王</h1>
	    </div>

	    <div id="onecolumnfirst">
			<div class="title ">
				<h2>封地佔領中</h2>
			</div>
			<p >
			這是一個<strong>利用CSS概念設計的小遊戲</strong>，運用你在網站所學與提示，來完成你的任務吧！！
			<strong>以下是一個420px*420px的地圖，每個方格為70px，現在你在3樓！接著你會到2樓，再到4樓</strong><br><br>	
    			
    			<img id="m1F" src="images/1F.png" width="430px";>
    			<img id="m2F" src="images/2F.png" width="430px";>
    			<img id="m3F" src="images/3F.png" width="430px"; ><br>
    			
    			<div id="me"></div>
    			<div id="enemy1"></div>
    			<div id="enemy2"></div>
    			<div id="enemy3"></div>
    			<div id="enemy4"></div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    		</p>
    		<p>
				遊戲規則與提示:<br><br>
				1.只有米色的路可以走<strong>請用margin的概念走到終點</strong><br>
				<strong>提示：margin-top、margin-right、margin-bootom、margin-left</strong><br>
				
				2.當路途中遇到其他的敵人必須要用<strong>相剋的屬性才能將他打敗，火剋草、草剋水、水剋火！</strong><br>
				3.假設對方有不同邊界的顏色，你也必須依造邊框對邊框，內部對內部都必須相剋，才能打敗敵人！<br>
				<strong>提示：請利用我們所教過可以變換內部顏色及邊框顏色的語法</strong><br>
				4.<strong>攻擊指令：請將邊框變成虛線</strong>，就可以把敵人趕走～<br>
				5.佔領領地過程中，你會通往不同的樓層，請利用<strong>z-index</strong>的概念來通往不同樓層<br>
				6.假設通道為圓形，你可能會因為太胖過不去！請想辦法讓自己變圓形<br>
				<strong>提示：怎麼只打入一個指令就變成圓形呢？</strong><br>
				7.當你到達空曠沒有障礙物領地的時候，<strong>請將自己變大來佔有所有領地</strong>！<br>


			</p>
		</div>
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="expost1">
			<form id="form1"  method="POST" novalidate="novalidate">
				<h3>策略規劃～</h3>
					<p  id="p1">					
						請輸入你的戰鬥策略	<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img id="blue" src="images/blue.png" width="70px";> :水屬性
						<img id="red" src="images/red.png" width="70px";> :火屬性
						<img id="green" src="images/green.png" width="70px";> :草屬性<br>
						<strong>第一層樓你可以隨便以70px為單位移動，但是每次只能走直線喔！第二層樓考驗你的效率，請以最有效率的方式到達目的地！</strong><br><br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		
						<input class="form-control" type="text" autocomplete="off" placeholder="請填入屬性" name="proper" id="proper" > :		
						<input class="form-control" type="text" autocomplete="off" placeholder="請輸入值" name="val" id="val"  > 
    				</p>
    				<input type="button"  class="button1" value="命令指派" onclick="myFunction()">
    				
    		</form>	<br><br>
			<strong>策略歷程:</strong><br>
			<p id="demo"></p>
    	
    		<script>

    		var data = new Array();
    		var data2 = new Array();
			var data3 = new Array();
			var number = 0;
			var count =0;
			// Store to history 按鈕被點下時

  			 
  			  function myFunction(){ 
  			  
  			  var pToStore = document.getElementById("proper").value;
  			  var vToStore = document.getElementById("val").value;
      			 
      			if( (pToStore =="margin-bottom" && vToStore =="70px" && number==0)||(pToStore =="margin-bottom" && vToStore =="140px" && number==0)||(pToStore =="margin-bottom" && vToStore =="210px" && number==0)||(pToStore =="margin-bottom" && vToStore =="280px" && number==0) )
      			 {	
      			 	data.push(pToStore);
      				data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML =  data[count]+':'+data2[count]+'<br>';
      				count++;
      				if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 758px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 688px";
      				}
      				else if(vToStore =="210px")
      				{
      				 number = number + 3;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="280px")
      				{
      				 number = number + 4;
      				 document.getElementById("me").style.top =" 548px";
      				}
      			 }
				 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==1)||(pToStore =="margin-bottom" && vToStore =="140px" && number==1)||(pToStore =="margin-bottom" && vToStore =="210px" && number==1))
      			 {	
      			 	 data.push(pToStore);
      				 data2.push(vToStore);
      				 data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 688px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="210px")
      				{
      				 number = number + 3;
      				 document.getElementById("me").style.top =" 548px";
      				}
      			 }
      			 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==2)||(pToStore =="margin-bottom" && vToStore =="140px" && number==2))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 548px";
      				}
      			 }
      			 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==3))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.top =" 548px";
      			 }
      			 else if((pToStore =="margin-left" && vToStore =="140px" && number==4)||(pToStore =="margin-left" && vToStore =="70px" && number==4))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.left =" 186px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.left =" 256px";
      				}
      			 }
      			  else if((pToStore =="margin-left" && vToStore =="140px" && number==5)||(pToStore =="margin-left" && vToStore =="70px" && number==5))
      			 {	
      			 	data.push(pToStore);
      				data2.push(vToStore);
      				data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.left =" 256px";
      				}
      				
      			 }

      			  else if((pToStore =="border-color" && vToStore =="#6BB93D" && number==6)||(pToStore =="background-color" && vToStore =="#6BB93D" && number==6))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(pToStore == "background-color")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.backgroundColor = "#6BB93D";
      				}	
      				 else if(pToStore == "border-color")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.borderColor = "#6BB93D";
      				}		
      			 }
      			  else if((pToStore =="background-color" && vToStore =="#6BB93D" && number==7))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 2;
      				document.getElementById("me").style.backgroundColor ="#6BB93D";	
      			 }
      			 else if((pToStore =="border-color" && vToStore =="#6BB93D" && number==8))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.borderColor = "#6BB93D";				
      			 }
      			   else if((pToStore =="margin-top" && vToStore =="70px" && number==9)||(pToStore =="margin-top" && vToStore =="140px" && number==9)||(pToStore =="margin-top" && vToStore =="210px" && number==9))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 688px";
      				}
      				else if(vToStore =="210px")
      				{
      				 number = number + 3;
      				 document.getElementById("me").style.top =" 758px";
      				}
      			 }
      			 else if((pToStore =="margin-top" && vToStore =="70px" && number==10)||(pToStore =="margin-top" && vToStore =="140px" && number==10))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 688px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 758px";
      				}
      
      			 }
      			 else if((pToStore =="margin-top" && vToStore =="70px" && number==11))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 758px";
      				}
      				
      			 }
      			  else if((pToStore =="background-color" && vToStore =="#B34747" && number==12))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.backgroundColor ="#B34747";	
      			 }
      			 else if((pToStore =="margin-left" && vToStore =="140px" && number==13)||(pToStore =="margin-left" && vToStore =="70px" && number==13))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.left =" 326px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.left =" 396px";
      				}
      			 }
      			  else if((pToStore =="margin-left" && vToStore =="140px" && number==14)||(pToStore =="margin-left" && vToStore =="70px" && number==14))
      			 {	
      			 	data.push(pToStore);
      				data2.push(vToStore);
      				data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.left =" 396px";
      				}
      				
      			 }else if( (pToStore =="margin-bottom" && vToStore =="70px" && number==15)||(pToStore =="margin-bottom" && vToStore =="140px" && number==15)||(pToStore =="margin-bottom" && vToStore =="210px" && number==15)||(pToStore =="margin-bottom" && vToStore =="280px" && number==15) )
      			 {	
      			 	data.push(pToStore);
      				data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				 count++;
      				if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 688px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="210px")
      				{
      				 number = number + 3;
      				 document.getElementById("me").style.top =" 548px";
      				}
      				else if(vToStore =="280px")
      				{
      				 number = number + 4;
      				 document.getElementById("me").style.top =" 478px";
      				}
      			 }
				 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==16)||(pToStore =="margin-bottom" && vToStore =="140px" && number==16)||(pToStore =="margin-bottom" && vToStore =="210px" && number==16))
      			 {	
      			 	 data.push(pToStore);
      				 data2.push(vToStore);
      				 data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 618px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 548px";
      				}
      				else if(vToStore =="210px")
      				{
      				 number = number + 3;
      				 document.getElementById("me").style.top =" 478px";
      				}
      			 }
      			 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==17)||(pToStore =="margin-bottom" && vToStore =="140px" && number==17))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(vToStore =="70px")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.top =" 548px";
      				}
      				else if(vToStore =="140px")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.top =" 478px";
      				}
      			 }
      			 else if((pToStore =="margin-bottom" && vToStore =="70px" && number==18))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 number = number + 1;
 					 document.getElementById("me").style.top ="478px";
      			 }
      			 else if((pToStore =="border-radius" && vToStore =="50%" && number==19))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 number = number + 1;
 					 document.getElementById("me").style.borderRadius ="50%";
      			 }
      			  else if((pToStore =="z-index" && vToStore =="2" && number==20))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 number = number + 1;
 					 document.getElementById("m2F").style.zIndex ="0";
 					 document.getElementById("enemy1").style.zIndex ="0";
 					  document.getElementById("enemy2").style.zIndex ="0";
      			 }
      			 	else if((pToStore =="border-radius" && vToStore =="0%" && number==21))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.borderRadius ="0%";
 				
      			 }     			  
     		   	else if((pToStore =="margin-top" && vToStore =="70px" && number==22))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.top ="548px";
 				
      			 }
      			 else if((pToStore =="margin-right" && vToStore =="280px" && number==23))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.left ="116px";
 				 } else if((pToStore =="border-color" && vToStore =="#275A88" && number==24)||(pToStore =="background-color" && vToStore =="#6BB93D" && number==24))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				 document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				  count++;
      				 if(pToStore == "background-color")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.backgroundColor = "#6BB93D";
      				}	
      				 else if(pToStore == "border-color")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.borderColor = "#275A88";
      				}		
      			 }
      			  else if((pToStore =="background-color" && vToStore =="#6BB93D" && number==25))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.backgroundColor ="#6BB93D";	
      			 }
      			   else if((pToStore =="border-color" && vToStore =="#275A88" && number==26))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.borderColor ="#275A88";	
      			 } 
      			 	else if((pToStore =="margin-top" && vToStore =="140px" && number==27))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.top ="688px";
 				 }
 				 else if((pToStore =="margin-left" && vToStore =="140px" && number==28))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.left ="256px";
 				 }
 				 else if((pToStore =="border-color" && vToStore =="#B34747" && number==29))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML +=  data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.borderColor ="#B34747";	
      			 }
      			 else if((pToStore =="margin-left" && vToStore =="70px" && number==30))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.left ="326px";
 				 }
      			 else if((pToStore =="margin-top" && vToStore =="70px" && number==31))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.top ="758px";
 				 }
 				 else if((pToStore =="margin-left" && vToStore =="140px" && number==32))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.left ="466px";
 				 }
 				  else if((pToStore =="margin-top" && vToStore =="70px" && number==33))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("me").style.top ="828px";
 				 }

 			 	else if((pToStore =="z-index" && vToStore =="4" && number==34))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
 					document.getElementById("m1F").style.zIndex ="0";
 					document.getElementById("enemy3").style.zIndex ="0";
 					document.getElementById("enemy4").style.zIndex ="0";
      			 }
      			 else if((pToStore =="width" && vToStore =="420px" && number==35)||(pToStore =="height" && vToStore =="420px" && number==35))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				if(pToStore == "width")
      				{
      				 number = number + 2;
      				 document.getElementById("me").style.width="400px";
      				  document.getElementById("me").style.left="116px";
      				}	
      				 else if(pToStore == "height")
      				{
      				 number = number + 1;
      				 document.getElementById("me").style.height="400px";
      				 document.getElementById("me").style.top="478px";
      				}		
 					
      			 }
      			 else if((pToStore =="width" && vToStore =="420px" && number==36))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.width = "400px";
      				document.getElementById("me").style.left="116px";
      						
      			 }else if((pToStore =="height" && vToStore =="420px" && number==37))
      			 {	
      			 	data.push(pToStore);
      			 	data2.push(vToStore);
      			 	data3.push(number);
      				document.getElementById("demo").innerHTML += data[count]+':'+data2[count]+'<br>';
      				count++;
      				number = number + 1;
      				document.getElementById("me").style.height="400px";
      				document.getElementById("me").style.top="478px";
      					
      				
      			 }




      			  
				





				}
			

    		</script>


    		<!--<?php	
    		

    			if(!isset($_POST['proper']))$_POST['proper'] = ' ';
    			if(!isset($_POST['val']))$_POST['val'] = ' ';			  			
    			if(empty($_POST['proper']))$_POST['proper'] = ' ';
    			if(empty($_POST['val']))$_POST['val'] = ' ';	

    			echo $_POST['proper'];
    			echo $_POST['val'];
    		?>



			
			<?php 
			echo $i.'<br>';
			if(  ($_POST['proper']=="margin-bottom" )&&($_POST['val']=="280px" ))
			{
				$Record[$i]= $_POST['proper'] . '：' . $_POST['val']; 
				$i=$i+1;
				echo $i." ";

			}

			for($k=0;$k<$i;$k++)
			{
				echo $Record[$k].'<br>';
			}
			?>
				<style>
						
				</style>-->

    			
			</li>
			
			
			
		</ul>	
	</div>
</div>

<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<a id="login" href="" >登入</a>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>

