<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(isset($_SESSION['user'])){
		require_once("connMysql.php");
		$tick = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
		$ticktick = mysql_query($tick);
		$row = mysql_fetch_array($ticktick);
}
else{}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>HoPe for Coding</title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="csspage.css" rel="stylesheet" type="text/css" media="all" />
<link href="ProgressBarWars.css" rel="stylesheet" />

<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="js/ProgressBarWars.js"></script>
<style type="text/css">
	.progress{
		margin-top: 30px;
		margin-bottom: 0px;
	}
</style>

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="htmlpage.php" accesskey="4" title="">HTML教學 </a></li>
			<li><a href="phppage.php" accesskey="2" title="">PHP教學</a></li>
			<li class="current_page_item"><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>CSS教學區</h1>
			<div class="progress" id="vaderTime"></div>
			<?php
			if(isset($_SESSION['user'])){
			?>
			<style>
				#onecolumnfirst 
				{
					padding-top: 0px
				}
				ul.style1 
				{
   					
  					padding: 8em 0em 0em 0em;
				}
			</style>
			 <script>
			 var num = <?php echo $row[7] ?>;
			$("#vaderTime").ProgressBarWars({porcentaje:num,estilo:"vader",tiempo:1000});
					
		  </script>
		  <input type="button" class="button2" value="更新個人進度" onClick="window.location.reload()">
			<?php }?>
	    </div>

	    <div id="onecolumnfirst">
			<div class="title ">
				<h2>方塊模組</h2>
			</div>
			<p >
			#id{<br>	
    			<strong>content:</strong>圖中藍色區域，表示內容物的大小<br>
    			用width語法來更改寬度; 用height語法用來更改高度<br>
    			<strong>padding:</strong>圖中綠色區域，外邊距，表示邊框內的距離<br>
    			由左至右分別是<strong>top、right、bottom、left</strong><br>
    			可以用<strong>padding-top、padding-right、padding-bottom、padding-left來改變一邊，
    			一樣的話可以用一個值代替！</strong><br>
    			<strong>border:</strong>圖中黃色區域，表示內容物的邊界<br>
    			用border-width語法來更改邊線寬度<br>
    			<strong>margin:</strong>圖中橘色區域，外邊距，表示邊框外的距離<br>
    			由左至右分別是<strong>top、right、bottom、left</strong><br>
    			<strong>PS:一樣的話可以用一個值代替</strong><br>
				}<br>
    			<strong>藉由瞭解不同的邊界設定，可以在之後CSS的排版及樣式上更得加應手。</strong><br><br>
    			<img id="boximage" src="images/box.png" width="230px";>
    	
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>按鈕樣式</h2>
			</div>
			<p >
				當你要在你的網頁新增一個button，可以在php的頁面打上<br>	
				<strong>&lt;button type="button id="button1"&gt;按鈕範例&lt;/button&gt;</strong><br><br>
				<button type="button" >按鈕範例</button><br><br>
				此處的button1，是你給這個按鈕的id，方便之後再CSS中進行編輯<br><br>
				#button1<br>
				{<br>
    			<strong>background-color:</strong> 來改變按鈕顏色<br>
    			<strong>color:</strong> 來改變按鈕顏色<br>
    			<strong>font-size:</strong> 來改變按鈕中字的大小<br>
    			<strong>width:</strong> 來改變按鈕寬度<br>
    			<strong>height:</strong> 來改變按鈕高度<br>
    	
			}</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>Hover</h2>
			</div>
			<p >
				利用hover的技巧你能為你的網站新增很多變化，讓網站的使用者有動態互動的感覺，藉由使用者不同的動作，讓網頁產生變化！<br>	
				這裡有四種語法<strong>link、visited、hover、active</strong><br>
				這種技巧的語法比較不同，並不是加在標籤中，而是利用：放置在標籤後<br>
				#id：<strong>link</strong><br> 表示未連結的元素所呈現的css變化<br>
				#id：<strong>visited</strong><br> 表示已連結的元素所呈現的css變化<br>
				#id：<strong>hover</strong><br>當滑鼠碰觸到元素時所呈現的css變化 <br>
				#id：<strong>active</strong><br> 利用滑鼠點擊元素時所產生的css變化<br>
				
				
    	
			</p>
		</div>

		<div id="onecolumn">
			<div class="title">
				<h2>Z-Index</h2>
			</div>
			<p >
				當你的網頁有很多不同的元素，如果你想讓這些元素有重疊的效果，或你想要讓他根據使用者的輸入產生不同元素，就可以使用這個方法！<br>	
				你可以使用<strong>正數</strong>或<strong>負數</strong><br>
				正數表示離你越近，複數則是離你越遠<br>
				#id{<br>
				<strong>zindex:數值</strong><br>
				}<br>
				以下為示意圖<br>
				<img id="zindeximg" src="images/zindex.png" width="350px";>
				
    	
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>Border樣式</h2>
			</div>
			<p >
				#p<br>
				{<br>
				<strong>border-color:</strong> 來改變按鈕顏色<br>
    			<strong>border-style:</strong> 來改變按鈕顏色<br>
    			}<br>
				<strong>solid</strong>表示實線：<strong>dashed</strong>表示虛線<br>
				<strong>double</strong>表示雙線：<strong>dotted</strong>表示虛線<br>
				<strong>groove</strong>表示凹線：<strong>ridge</strong>表示凸線<br>
				<strong>inset</strong>表示嵌入線：<strong>outset</strong>表示浮出線<br>
    	
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>Border-radius<h2>
			</div>
			<p >
				#button1<br>{<br>
				當你的元素的邊框想做出弧度的感覺，就可以利用這個語法來製作！<br>	
				<strong>border-radius:</strong>左上角的弧度;<br>
				由左至右分別是<strong>左上、右上、右下、左下</strong><br>
				<strong>PS:一樣的話可以用一個值代替</strong><br><br>

				以下的語法後面個需要填兩個數值，代表A方位到B方位的弧度大小！<br>
				<strong>border-top-left-radius:</strong>左上角的弧度;<br>
				<strong>border-top-right-radius:</strong>右上角的弧度;<br>
				<strong>border-bottom-right-radius:</strong>右下角的弧度;<br>
				<strong>border-bottom-left-radius:</strong>左下角的弧度;<br>
				}<br>
				<strong>PS:如果想繪製一個圓形，可以將值設為50%，大家可以在試試看！！</strong><br><br><br><br>
				
    	
			</p>
		</div>
	</div>
	<div id="sidebar">
		
		<ul class="style1">
			<li class="first" id="expost1">
			<form id="form1" action="csspage.php#p1" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p >						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;width:			
						<input class="form-control" type="text" autocomplete="off" placeholder="200" name="boxwidth" required="required" > px; &nbsp;&nbsp;&nbsp;&nbsp;<=200px<br>		
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;height:			
						<input class="form-control" type="text" autocomplete="off" placeholder="200" name="boxheight" required="required" > px; &nbsp;&nbsp;&nbsp;&nbsp;<=200px<br>			
    	  		 		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;padding:
    	  			 	<input class="form-control style1 " type="text" autocomplete="off" placeholder="0" name="padding1"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="padding2"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="padding3"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="padding4"> px; <br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PS:每邊的padding &nbsp;&nbsp;&nbsp;&nbsp;<=50<br>
    	  			 	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-width:
   						<input class="form-control" type="text" autocomplete="off" placeholder="10" name="borderwidth" > px; &nbsp;&nbsp;&nbsp;&nbsp;<=30<br>
   						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;margin:
   						<input class="form-control style1 " type="text" autocomplete="off" placeholder="0" name="margin1"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="margin2"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="margin3"> px <input class="form-control style1" type="text" autocomplete="off" placeholder="0" name="margin4"> px; <br>
   						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PS:每邊的margin &nbsp;&nbsp;&nbsp;&nbsp;<=50<br>
    				</p>
    				<input type="submit" class="button1" value="結果呈現" id="p1" name="button1">
					<?php

 if(isset($_SESSION['user']) && isset($_POST['button1']))
{
$update1 = 'UPDATE css SET css_1="1" WHERE account = "'.$_SESSION['account'].'";';
$up1 = mysql_query($update1);

$query_RecProduct1 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product1 = mysql_query($query_RecProduct1);
$row1 = mysql_fetch_array($Product1);

$sum1=$row1[1]+$row1[2]+$row1[3]+$row1[4]+$row1[5]+$row1[6];

$result1=round($sum1/6*100);
$query1 = 'UPDATE css SET progress="'.$result1.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);
}
?>
    		</form>	<br>

    		<div id="boxex-margin">
    				<button id="boxex-content"><div id="pad">內容</div></button>
    		</div>

    		<!--<div id="boxiframecontainer"> <iframe frameborder="0" id="boxiframe">
    			<html>
    			<head>
    				<style>
    					#boxex-margin
						{
							display:block; 
							margin-top: 30px;
							margin-left: 150px;
							width:200px;
							height: 200px;
							background-color: #F9CC9D;  
						}

						#boxex-content
						{ 
						position: absolute;
						width:200px;
						height: 200px;
						background-color: #8BB5C0;  
						text-align: center;
						}
    				</style>
    				</head>
    				<body>
    					<div id="boxex-content"></div>
			
    				</body>
    			</html>
    		</iframe></div>-->
    		<?php		
    			if(!isset($_POST['boxwidth']))$_POST['boxwidth'] = '200';
    			if(!isset($_POST['boxheight']))$_POST['boxheight'] = '200';			
    			if(!isset($_POST['padding1']))$_POST['padding1'] = '0';
    			if(!isset($_POST['padding2']))$_POST['padding2'] = '0';
    			if(!isset($_POST['padding3']))$_POST['padding3'] = '0';
    			if(!isset($_POST['padding4']))$_POST['padding4'] = '0';		
    			if(!isset($_POST['borderwidth']))$_POST['borderwidth'] = '10';    			
    			if(!isset($_POST['margin1']))$_POST['margin1'] = '0';
    			if(!isset($_POST['margin2']))$_POST['margin2'] = '0';
    			if(!isset($_POST['margin3']))$_POST['margin3'] = '0';
    			if(!isset($_POST['margin4']))$_POST['margin4'] = '0';
    			
    			if(empty($_POST['boxwidth']))$_POST['boxwidth'] = '200';
    			if(empty($_POST['boxheight']))$_POST['boxheight'] = '200';	
    			if(empty($_POST['padding1']))$_POST['padding1'] = '0';
    			if(empty($_POST['padding2']))$_POST['padding2'] = '0';
    			if(empty($_POST['padding3']))$_POST['padding3'] = '0';
    			if(empty($_POST['padding4']))$_POST['padding4'] = '0';	
    			if(empty($_POST['borderwidth']))$_POST['borderwidth'] = '10';  	 			
    			if(empty($_POST['margin1']))$_POST['margin1'] = '0';
    			if(empty($_POST['margin2']))$_POST['margin2'] = '0';
    			if(empty($_POST['margin3']))$_POST['margin3'] = '0';
    			if(empty($_POST['margin4']))$_POST['margin4'] = '0';		

    			if(($_POST['boxheight'])>=200)$_POST['boxheight'] = '200';
    			if(($_POST['boxwidth'])>=200)$_POST['boxwidth'] = '200';
    			if(($_POST['padding1'])>=160)$_POST['padding1'] = '50';
    			if(($_POST['padding2'])>=160)$_POST['padding2'] = '50';
    			if(($_POST['padding3'])>=160)$_POST['padding3'] = '50';
    			if(($_POST['padding4'])>=160)$_POST['padding4'] = '50';
    			if(($_POST['borderwidth'])>=30)$_POST['borderwidtg'] = '30';
    			if(($_POST['margin1'])>=100)$_POST['margin1'] = '50';
    			if(($_POST['margin2'])>=100)$_POST['margin2'] = '50';
    			if(($_POST['margin3'])>=100)$_POST['margin3'] = '50';
    			if(($_POST['margin4'])>=100)$_POST['margin4'] = '50';

    			
    		?>

				<style>
						#boxex-margin
						{
							display:block; 
							margin:0 auto; 
							width:<?= $_POST['boxwidth']+$_POST['borderwidth']*2+$_POST['padding2']+$_POST['padding4']+$_POST['margin2']+$_POST['margin4'] ?>px;
							height:<?= $_POST['boxheight']+$_POST['borderwidth']*2+$_POST['padding1']+$_POST['padding3']+$_POST['margin1']+$_POST['margin3'] ?>px;
							background-color: #F9CC9D;  
						}

						#boxex-content
						{ 
							position: absolute;
							font-size:16px;
							margin-top:<?= $_POST['margin1'] ?>px;
							margin-left:<?= $_POST['margin4'] ?>px;
							width:<?= $_POST['boxwidth']+$_POST['borderwidth']*2+$_POST['padding2']+$_POST['padding4'] ?>px;
							height:<?= $_POST['boxheight']+$_POST['borderwidth']*2+$_POST['padding1']+$_POST['padding3'] ?>px;
							background-color: #C2CF8A;  	
							border-width:<?= $_POST['borderwidth'] ?>px;
							border-color:#FDDD9B; 
						}
						#pad
						{
							background-color:  #8BB5C0; 
							margin-left:  <?= $_POST['padding4']-5 ?>px;
							margin-top:<?= $_POST['padding1']-1 ?>px;
							margin-bottom:<?= $_POST['padding3'] ?>px;
							width:<?= $_POST['boxwidth'] ?>px;
							height:<?= $_POST['boxheight'] ?>px;
							line-height:<?= $_POST['boxheight'] ?>px;
							text-align: center;	

						}
						<?php
						if($_POST['boxheight']+$_POST['margin1']+$_POST['borderwidth']*2+$_POST['margin3']+$_POST['padding1']+$_POST['padding3']>220) ?>
						#ex2post
						{
		
  							overflow: hidden;
 							display: block;
							padding-top:<?= 250-($_POST['boxheight']+$_POST['margin1']+$_POST['borderwidth']*2+$_POST['margin3']+$_POST['padding1']+$_POST['padding3']-220) ?>px
						}
						
				</style>

    			
			</li>
			<li class="first" id="ex2post">
			<form id="form1" action="csspage.php#p2" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p id="p2">＃button1{<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;background-color:			
						<input class="form-control" type="text" autocomplete="off" placeholder="#FFFFFF" name="backcolor" > ;<br>				
    	  		 		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;font-size:
    	  			 	<input class="form-control" type="text" autocomplete="off" placeholder="12" name="textsize"> px;  &nbsp;&nbsp;&nbsp;&nbsp;<=30px<br>
    	  			 	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;height:
   						<input class="form-control" type="text" autocomplete="off" placeholder="25" name="height" > px;  &nbsp;&nbsp;&nbsp;&nbsp;<=80px<br>
   						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;width:
   						<input class="form-control" type="text" autocomplete="off" placeholder="50" name="width" > px; &nbsp;&nbsp;&nbsp;&nbsp;<=200px<br>
   						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;color:
    					<input class="form-control" type="text" autocomplete="off" placeholder="#000000" name="textcolor" > ;<br>
    					}<br>
    				</p>
    				<input type="submit" class="button1" value="結果呈現" name="button2">
					<?php

 if(isset($_SESSION['user'])&& isset($_POST['button2']))
{
$update2 = 'UPDATE css SET css_2="1" WHERE account = "'.$_SESSION['account'].'";';
$up2 = mysql_query($update2);

$query_RecProduct2 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product2 = mysql_query($query_RecProduct2);
$row2 = mysql_fetch_array($Product2);

$sum2=$row2[1]+$row2[2]+$row2[3]+$row2[4]+$row2[5]+$row2[6];

$result2=round($sum2/6*100);
$query2 = 'UPDATE css SET progress="'.$result2.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct2 = mysql_query($query2);
}
?>
    		</form>			
    		<?php		
    			if(!isset($_POST['backcolor']))$_POST['backcolor'] = '#FFFFFF';
    			if(!isset($_POST['textsize']))$_POST['textsize'] = '12';			
    			if(!isset($_POST['height']))$_POST['height'] = '25';
    			if(!isset($_POST['width']))$_POST['width'] = '50';    			
    			if(!isset($_POST['textcolor']))$_POST['textcolor'] = '#000000';

    			if(empty($_POST['backcolor']))$_POST['backcolor'] = '#FFFFFF';
    			if(empty($_POST['textsize']))$_POST['textsize'] = '12';			
    			if(empty($_POST['height']))$_POST['height'] = '25';
    			if(empty($_POST['width']))$_POST['width'] = '50';    			
    			if(empty($_POST['textcolor']))$_POST['textcolor'] = '#000000';

    			if(($_POST['textsize'])>=30)$_POST['textsize'] = '30';
    			if(($_POST['height'])>=80)$_POST['height'] = '80';
    			if(($_POST['width'])>=200)$_POST['width'] = '200';
    		?>
			<br>font-size:<?php echo$_POST['textsize']?>&nbsp;&nbsp;&nbsp;&nbsp;height:<?php echo$_POST['height']?>&nbsp;&nbsp;&nbsp;&nbsp;width:<?php echo$_POST['width']?>
				<style>
					.ex1{
						background-color:  <?= $_POST['backcolor'] ?>;
						font-size:<?= $_POST['textsize'] ?>px;
						height:<?= $_POST['height'] ?>px;
						width:<?= $_POST['width'] ?>px;
						color: <?= $_POST['textcolor'] ?>;
					}
					<?php if($_POST['height']>25) ?>
					#ex3post
						{
		
  							overflow: hidden;
 							display: block;
							padding-top:<?= 70-$_POST['height']+25?>px
						}
				</style>



    			<h3>結果範例：</h3><p><button type="button" class='ex1'> 範例</button></p><br>
			</li>
			<li class="first" id="ex3post">
			<form id="form1" action="csspage.php#p9" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p >＃id:link<br>
						{<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;color:blue;<br>								
    	  		 		}<br>
    	  		 		＃id:								
						<input class="form-control" type="text" autocomplete="off" placeholder="visited" name="hover" ><br>	
						{<br>			
    	  		 		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;text-color:#B08769(咖啡色);&nbsp;&nbsp;&nbsp;&nbsp;<br>
    	  		 		}<br>
    				</p>
    				<input type="submit" class="button1" value="結果呈現" id="p9" name="button3">
					<?php

 if(isset($_SESSION['user'])&& isset($_POST['button3']))
{
$update3 = 'UPDATE css SET css_3="1" WHERE account = "'.$_SESSION['account'].'";';
$up3 = mysql_query($update3);

$query_RecProduct3 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product3 = mysql_query($query_RecProduct3);
$row3 = mysql_fetch_array($Product3);

$sum3=$row3[1]+$row3[2]+$row3[3]+$row3[4]+$row3[5]+$row3[6];

$result3=round($sum3/6*100);
$query3 = 'UPDATE css SET progress="'.$result3.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query3);
}
?>
    		</form>			<br>
			
    		<?php		
    			if(!isset($_POST['hover']))$_POST['hover'] = 'visited';

    			if(empty($_POST['hover']))$_POST['hover'] = 'visited';
    	
    		?>
			<br>目前狀態:<?php echo$_POST['hover']?>&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
			<a href="www.yahoo.com.tw" id="html">大家好！！！！</a>
				<style>
						#html:<?= $_POST['hover']?>
						{
							color:#B08769;
						}
						
				</style>


			</li>
			<li class="first" id="ex4post">
			<form id="form1" action="csspage.php#p4" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p id="p4">＃pikachu{<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;z-index:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="1" name="zindex1" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;}<br>					
						＃mouse{	<br>	
						&nbsp;&nbsp;&nbsp;&nbsp;z-index:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="2" name="zindex2" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;}<br>	
						＃turtle{<br>					
						&nbsp;&nbsp;&nbsp;&nbsp;z-index:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="3" name="zindex3" vlaue=""> ;&nbsp;&nbsp;&nbsp;&nbsp; }<br>	
    				</p>

    				<input type="submit" class="button1" id="zbutton" value="結果呈現" name="button4"><br><br>
    				<img id="ball" src="images/ball.png" width="200px";>
    				<img id="pika" src="images/pika.png" width="180px";>
    				<img id="turtle" src="images/turtle.png" width="200px";>	
<?php

 if(isset($_SESSION['user'])&& isset($_POST['button4']))
{
$update4 = 'UPDATE css SET css_4="1" WHERE account = "'.$_SESSION['account'].'";';
$up4 = mysql_query($update4);

$query_RecProduct4 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product4 = mysql_query($query_RecProduct4);
$row4 = mysql_fetch_array($Product4);

$sum4=$row4[1]+$row4[2]+$row4[3]+$row4[4]+$row4[5]+$row4[6];

$result4=round($sum4/6*100);
$query4 = 'UPDATE css SET progress="'.$result4.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct4 = mysql_query($query4);
}
?>					
    		</form>			
    		<?php		
    			if(!isset($_POST['zindex1']))$_POST['zindex1'] = '1';
    			if(!isset($_POST['zindex2']))$_POST['zindex2'] = '2';			
    			if(!isset($_POST['zindex3']))$_POST['zindex3'] = '3';
    			if(empty($_POST['zindex1']))$_POST['zindex1'] = '1';
    			if(empty($_POST['zindex2']))$_POST['zindex2'] = '2';			
    			if(empty($_POST['zindex3']))$_POST['zindex3'] = '3';
    		?>

    		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;傑尼龜:<?php echo$_POST['zindex3']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    		皮卡丘:<?php echo$_POST['zindex1']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    		火球鼠:<?php echo$_POST['zindex2']?>
				<style>
					#ball{
						z-index:  <?= $_POST['zindex2'] ?>;
					}
					#turtle
					{
						z-index:  <?= $_POST['zindex3'] ?>;
					}
					#pika
					{
						z-index:  <?= $_POST['zindex1'] ?>;
					}
				</style>

					<div id="space"></div>

    			
			</li>
			<li class="first" id="ex5post">
			<form id="form1" action="csspage.php#p5" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p id="p5">p{<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;border-color:			
						<input class="form-control " type="text" autocomplete="off" placeholder="#ad8667" name="bordercolor"> ;&nbsp;&nbsp;&nbsp;&nbsp;<br>					
						&nbsp;&nbsp;&nbsp;&nbsp;border-style:			
						<input class="form-control " type="text" autocomplete="off" placeholder="solid" name="borderstyle" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;<br>
						}<br>	
    				</p>

    				<input type="submit" class="button1" id="zbutton" value="結果呈現" name="button5"><br><br>
    		<?php

 if(isset($_SESSION['user'])&& isset($_POST['button5']))
{
$update5 = 'UPDATE css SET css_5="1" WHERE account = "'.$_SESSION['account'].'";';
$up5 = mysql_query($update5);

$query_RecProduct5 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product5 = mysql_query($query_RecProduct5);
$row5 = mysql_fetch_array($Product5);

$sum5=$row5[1]+$row5[2]+$row5[3]+$row5[4]+$row5[5]+$row5[6];

$result5=round($sum5/6*100);
$query5 = 'UPDATE css SET progress="'.$result5.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct5 = mysql_query($query5);
}
?>
    		</form>			
    		<?php		
    			if(!isset($_POST['bordercolor']))$_POST['bordercolor'] = '#ad8667';
    			if(!isset($_POST['borderstyle']))$_POST['borderstyle'] = 'solid';
    			if(empty($_POST['bordercolor']))$_POST['bordercolor'] = '#ad8667';
    			if(empty($_POST['borderstyle']))$_POST['borderstyle'] = 'solid';			
    		?>

    		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-color:<?php echo$_POST['bordercolor']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    		borderstyle:<?php echo$_POST['borderstyle']?>
    		<p id ="borderp">邊框範例</p>
				<style>
					#borderp{
						border-width:5px;
						width:90px;
						height:30px;
						vertical-align: middle;
						text-align: center;
						margin-top: 10px;
						margin-left:140px;
						border-color: <?= $_POST['bordercolor'] ?>;
						border-style: <?= $_POST['borderstyle'] ?>;
					}
				</style>

					

    			
			</li>
			<li class="first" id="ex6post">
			<form id="form1" action="csspage.php#p6" method="POST" novalidate="novalidate">
				<h3>測試自己的程式碼～</h3>
					<p id="p4">#div<br>{<br>			

   						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-radius:
   						<input class="form-control style1 " type="text" autocomplete="off" placeholder="0px" name="radius1"> <input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radius2"> <input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radius3"> <input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radius4"> ;<br><br>			
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-top-left-radius:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiustl1" value=""> &nbsp;&nbsp;&nbsp;&nbsp;<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiustl2" vlaue=""> ;<br>					
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-top-right-radius:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiustr1" value=""> &nbsp;&nbsp;&nbsp;&nbsp;<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiustr2" vlaue=""> ;<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-bottom-right-radius:			
						<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiusbr1" vlaue="">&nbsp;&nbsp;&nbsp;&nbsp;<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiusbr2" vlaue=""> ;<br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;border-bottom-left-radius:		
						<input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiusbl1" vlaue="">&nbsp;&nbsp;&nbsp;&nbsp;
						 <input class="form-control style1" type="text" autocomplete="off" placeholder="0px" name="radiusbl2" vlaue=""> ;<br>}<br>	
    				</p>

    				<input type="submit" id="p6" class="button1" id="zbutton" value="結果呈現" name="button6"><br><br>
    						<?php

 if(isset($_SESSION['user'])&& isset($_POST['button6']))
{
$update6 = 'UPDATE css SET css_6="1" WHERE account = "'.$_SESSION['account'].'";';
$up6 = mysql_query($update6);

$query_RecProduct6 = 'SELECT * FROM css WHERE account = "'.$_SESSION['account'].'";';
$Product6 = mysql_query($query_RecProduct6);
$row6 = mysql_fetch_array($Product6);

$sum6=$row6[1]+$row6[2]+$row6[3]+$row6[4]+$row6[5]+$row6[6];

$result6=round($sum6/6*100);
$query6 = 'UPDATE css SET progress="'.$result6.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct6 = mysql_query($query6);
}
?>
    		</form>			
    		<?php		
    			if(!isset($_POST['radius1']))$_POST['radius1'] = "0px";
    			if(!isset($_POST['radius2']))$_POST['radius2'] = "0px";			
    			if(!isset($_POST['radius3']))$_POST['radius3'] = "0px";
    			if(!isset($_POST['radius4']))$_POST['radius4'] = "0px";

    			if(!isset($_POST['radiustl1']))$_POST['radiustl1'] = "0px";
    			if(!isset($_POST['radiustl2']))$_POST['radiustl2'] = "0px";	
    			if(!isset($_POST['radiustr1']))$_POST['radiustr1'] = "0px";	
				if(!isset($_POST['radiustr2']))$_POST['radiustr2'] = "0px";	
				if(!isset($_POST['radiusbr1']))$_POST['radiusbr1'] = "0px";	
				if(!isset($_POST['radiusbr2']))$_POST['radiusbr2'] = "0px";	
				if(!isset($_POST['radiusbl1']))$_POST['radiusbl1'] = "0px";	
				if(!isset($_POST['radiusbl2']))$_POST['radiusbl2'] = "0px";	
    			
    		?>
			<div id="rad"></div>
				<style>
				#rad
				{
					border: 2px solid #B08769;
					width:200px;
					height:50px;
					margin-left: 140px;
					border-top-left-radius: <?= $_POST['radius1'] ?>;
					border-top-right-radius: <?= $_POST['radius2'] ?>;
					border-bottom-right-radius: <?= $_POST['radius3'] ?>;
					border-bottom-left-radius: <?= $_POST['radius4'] ?>;
					border-top-left-radius:  <?= $_POST['radiustl1'] . " " . $_POST['radiustl2'] . " " ?>;
					border-top-right-radius: <?= $_POST['radiustr1'] ?> <?= $_POST['radiustr2'] ?>;
					border-bottom-right-radius: <?= $_POST['radiusbr1'] ?> <?= $_POST['radiusbr2'] ?>;
					border-bottom-left-radius: <?= $_POST['radiusbr1'] ?> <?= $_POST['radiusbr2'] ?>;
				}
				</style>
				


    			
			</li>
		</ul>	
	</div>
</div>

<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<?php
 if (isset($_SESSION['user'])) {
 ?>
	<a id="login" href="logout.php" >登出</a>
 <?php

 } else {
   ?>
	<a id="login" href="login.php" >登入</a>
   <?php
 }?>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>

