<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="phppage.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

	<style type="text/css">
#content{width:800px;height:600px;border:1px #333333 solid;overflow:hidden;}
#A{width:120px;height:600px;float:left;background:#996633;}
#B{width:560px;height:600px;float:left;background:#0099FF;}
#river{width:560px;height:450px;}
#operator{width:560px;height:150px;background:#99CCFF;overflow:hidden;}
#C{width:120px;height:600px;float:right;background:#996633;}
#people{width:100px;height:20px;border:2px #000000 solid;margin:10px auto;text-align:center;cursor:pointer;padding:10px 0px;}
#ship{width:200px;height:20px;border:1px #CC3300 solid;background:#663300;position:relative;top:150px;left:0px;text-align:center;padding:10px 0px;cursor:pointer;}
#btns{width:560px;height:40px;margin-top:10px;}
#btn{width:60px;height:20px;border:1px #000000 solid;background:#FFFFCC;text-align:center;padding:10px 0px;cursor:pointer;float:left;margin-left:210px;display:inline;}
#new{width:60px;height:20px;border:1px #000000 solid;background:#FFFFCC;text-align:center;padding:10px 0px;cursor:pointer;float:left;margin-left:10px;display:inline;}
#rule{width:560px;height:100px;margin-top:10px;font-family:宋体;font-size:12px;color:#666666;line-height:16px;text-align:center;}
</style>

<script type="text/javascript">
var direction;//A to C:true ; C to A:false
var people=new Array(9);
var s2Able;//判斷船2是否有人
var s1Able;//判斷船1是否有人
var pInShip1;//誰在船1上
var pInShip2;//誰在船2上
function init(){
    var peopleA=document.getElementById("A").getElementsByTagName("div");
	var ships=document.getElementsByName("ship");
    var peopleC=document.getElementById("C").getElementsByTagName("div");
	var moveBtn=document.getElementById("btn");
	var newBtn=document.getElementById("new");
	for(var i=0,len=peopleC.length;i<len;i++){
	    peopleC[i].style.visibility="hidden";
	}
    s1Able=true;
	s2Able=true;
	direction=true;
	for (var i=0;i<9;i++)
	{
		people[i]=true;
	}
	//事件
	var len=peopleA.length;
	for(var j=0;j<len;j++){
	    (function(m){
		    peopleA[m].onclick = function(){
			    if(direction)
			       selectPeople(this,m+1);
			};
			peopleC[m].onclick = function(){
			    if(!direction)
			       selectPeople(this,m+10+1);
			};
		})(j);
	}
	ships[0].onclick=function(){
	    quitShip(this,pInShip1);
	    s1Able=true;
	    pInShip1=0;
	};
	ships[1].onclick=function(){
	    quitShip(this,pInShip2);
	    s2Able=true;
	    pInShip2=0;
	};
	moveBtn.onclick=function(){
	    move();
	};
	newBtn.onclick=function(){
	    window.location = window.location;
	};
}
function selectPeople(obj,move_num){
    var ships=document.getElementsByName("ship");
	if(s1Able){
	    ships[0].innerHTML=obj.innerHTML;
		obj.style.visibility="hidden";
		s1Able=false;
		pInShip1=move_num;
		if(move_num>10)
			people[move_num-10]=!people[move_num-10];
		else
			people[move_num]=!people[move_num];
	}
	else if(s2Able){
	    ships[1].innerHTML=obj.innerHTML;
		obj.style.visibility="hidden";
		s2Able=false;
		pInShip2=move_num;
		if(move_num>10)
			people[move_num-10]=!people[move_num-10];
		else
			people[move_num]=!people[move_num];
	}
	else{
	    alert("船上最多兩樣東西，滿了!");
	}
}
function quitShip(obj,quitId){
    if(obj.innerHTML != ""){
	    var peopleA=document.getElementById("A").getElementsByTagName("div");
        var peopleC=document.getElementById("C").getElementsByTagName("div");
	    if(quitId > 10){
		    peopleC[quitId-10-1].style.visibility="visible";
			people[quitId-10]=!people[quitId-10];
		}
		else{
		    peopleA[quitId-1].style.visibility="visible";
			people[quitId]=!people[quitId];
		}
		obj.innerHTML="";
	}
}
function motherCheck(){
	if(people[1]==people[5])
	{
		if(people[4]!=people[1])
		{
			alert("$b與$b發生問題");
			return false;
		}
	}
	if(people[1]==people[6])
	{
		if(people[4]!=people[1])
		{
			alert("HTML與$a 發生問題");
			return false;
		}
	}
	return true;
}
function fatherCheck(){
    if(people[4]==people[2])
	{
		if(people[1]!=people[4])
		{
			alert("PHP與<h>發生問題");
			return false;
		}
	}
	if(people[4]==people[3])
	{
		if(people[1]!=people[4])
		{
			alert("PHP與<div>發生問題");
			return false;
		}
	}
	return true;
}
function policeCheck(){
    if(people[7]!=people[8])
	{
		for(var i=1;i<8;i++)
		{
			if(people[8]==people[i])
			{
				alert("echo 沒有帶著 引號 造成問題");
				return false;
			}
		}
	}
	return true;
}
function atoc(peopleId){
    var peopleC=document.getElementById("C").getElementsByTagName("div");
	var ships=document.getElementsByName("ship");
	var tempId;
	if(peopleId > 10){
	    tempId = peopleId - 10 -1;
	}
	else
	    tempId = peopleId - 1;
	if(tempId >= 0)
	   peopleC[tempId].style.visibility="visible";
	for(var i=0,len=ships.length;i<len;i++){
	    ships[i].style.left = "360px";
		ships[i].innerHTML = "";
	}
}
function ctoa(peopleId){
    var peopleA=document.getElementById("A").getElementsByTagName("div");
	var ships=document.getElementsByName("ship");
	var tempId;
	if(peopleId > 10){
	    tempId = peopleId - 10 -1;
	}
	else
	    tempId = peopleId - 1;
	if(tempId >= 0)
	    peopleA[tempId].style.visibility="visible";
	for(var i=0,len=ships.length;i<len;i++){
	    ships[i].style.left = "0px";
		ships[i].innerHTML = "";
	}
}
function move(){
    if(pInShip1==1 || pInShip1==4 || pInShip1==7 ||
	   pInShip1==11 || pInShip1==14 || pInShip1==17 ||
	   pInShip2==1 || pInShip2==4 || pInShip2==7 ||
	   pInShip2==11 || pInShip2==14 || pInShip2==17
	  )		//開船的人只能是PHP HTML或者是echo
	 {
		if (motherCheck()&& fatherCheck() && policeCheck())
		{
			if(direction)
			{
				atoc(pInShip1);
				atoc(pInShip2);
				direction=false;
			}
			else
			{
				ctoa(pInShip1);
				ctoa(pInShip2);
				direction=true;
			}
			s1Able=s2Able=true;
			pInShip1=pInShip2=0;
			var peopleC=document.getElementById("C").getElementsByTagName("div");
			var result = true;
			for(var i=0,len=peopleC.length;i<len;i++){
			   if(peopleC[i].style.visibility=="hidden"){
			       result = false;
				   break;
			   }
			}
			if(result){
			    alert("水喔！");
				window.location = window.location;
			}
		}
	}
	else
		alert("只有HTML、PHP和echo能移動船！");
}
window.onload = function(){
    init();
};
</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li class="current_page_item"><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>小遊戲</h1>
       </div>
    <div id="A">
        <div id="people" name="people">HTML</div>
        <div id="people" name="people">&lt;h&gt </div>
        <div id="people" name="people">&lt;div&gt </div>
        <div id="people" name="people">PHP</div>
        <div id="people" name="people">$a</div>
        <div id="people" name="people">$b</div>
        <div id="people" name="people">echo</div>
        <div id="people" name="people">" "</div>
    </div>
    <div id="B">
        <div id="river">
            <div id="ship" name="ship"></div>
            <div id="ship" name="ship"></div>
        </div>
        <div id="operator">
            <div id="btns">
                <div id="btn">移動</div>
                <div id="new">重玩</div>
            </div>
            <div id="rule">
            遊戲規則：<br />
            1.無論放甚麼，每趟最多只能裝兩個東西。2.只有PHP、HTML、echo可以讓船移動。<br />
            3.PHP離開$a,$b,HTML還在會有問題。4.HTML離開&lt;h&gt,&lt;div&gt ,PHP還在會有問題。<br />
            5.""離開echo會造成其他六樣東西出問題。6.先選擇好運送的東西，然後再按"移動"按鈕。<br />
            7.移動過程中若出現提示，說明違反上述規則。
            </div>
        </div>
    </div>
    <div id="C">
        <div id="people" name="people">HTML</div>
        <div id="people" name="people">&lt;h&gt </div>
        <div id="people" name="people">&lt;div&gt </div>
        <div id="people" name="people">PHP</div>
        <div id="people" name="people">$a</div>
        <div id="people" name="people">$b</div>
        <div id="people" name="people">echo</div>
        <div id="people" name="people">" "</div>
    </div>

	
</div>

<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<a id="login" href="" >登入</a>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>
