<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>HoPe for CodingP</title>
<meta name="keywords" content="" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="homepage.css" rel="stylesheet" type="text/css" media="all" />
	<!--[if IE 6]>
	<link href="default_ie6.css" rel="stylesheet" type="text/css" />
	<![endif]-->

<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>
	
</head>
<body>
<div id="main">
	<header><span class="homepagelogo"></span>
		<h1><strong>Hope</strong> for coding</h1>
		<div><br></div>
		<div>
			<img src="images/logo.png" width="120px" ;>
		</div>
	</header>		
	<section class="banner">
		<h2> <a id= "floattext" href="index.php" style="text-decoration:none";>  HTMLxCSSxPHP<br>Learning by playing</a></h2>
	</section>
	<section class="gridblock">	
			<div class="icontable"><img src="images/html5.png" width="150px" ;></div><div class="icontable"><img src="images/php7.png" width="110px";></div><div class="icontable"><img src="images/css.png" width="110px";></div><div class="icontable"><h2>Fun x Test</h2><img src="images/test.png" width="130px";></div>
	</section>
	
	<section class="block">
			<div class="content style1 " >
				<div class="intext ">
					<h2>HTML教學</h2>
					<p><br>HTML是一種基礎技術，常與CSS、PHP一起被用於設計令人賞心悅目的網頁、網頁應用程式以及行動應用程式的使用者介面。HTML可以說就像是一棟房子的框架，一個好的HTML，就好比一棟房子好的地基好架構，可以在日後建置網站時更加得心應手！</p>
					<ul class="actions"><li><a href="htmlpage.php" id="button1" class="button">了解更多</a></li></ul>
				</div>
			</div>		
			<div class="image" ><img src="images/img3.jpg" ></div>
	</section>
	<section class="block1">
			<div class="image" ><img src="images/img1.jpg" width="80%"></div>
			<div class="content style2">
				<div class="intext ">
					<h2>PHP教學</h2>
					<p><br>PHP是一種伺服端描述語言，用來製作動態網頁，且擁有跨平台與嵌入式的特色。PHP有很多的開放資源可供使用，從一般網頁的互動效果、授權認證、存取檔案到與資料庫搭配...等等。其泛用性與隱蔽性讓它在開發網頁的發展上扮演了重要的角色</p>
					<ul class="actions"><li><a href="phppage.php" id="button1" class="button">了解更多</a></li></ul>
				</div>
			</div>
		
	</section>
	<section class="block">
			<div class="content style3">
				<div class="intext ">
					<h2>CSS教學</h2>
					<p><br>CSS是一種基礎技術，常與HTML、PHP一起被用於設計令人賞心悅目的網頁、網頁應用程式以及行動應用程式的使用者介面。CSS可以說就像是一棟房子的裝潢，如何讓你的房子變得更漂亮，更引人注目，就是考驗你撰寫CSS能力的時候</p>
					<ul class="actions"><li><a href="csspage.php" id="button1" class="button">了解更多</a></li></ul>
				</div>
			</div>
			<div class="image" ><img src="images/img2.jpg"></div>
	</section>
	<section class="block1">
			<div class="image" ><img src="images/img4.jpg" width="80%"></div>
			<div class="content style4">
				<div class="intext ">
					<h2>遊戲＆測驗</h2>
					<p><br>我們測驗會根據使用著的答題狀況來給予適當難度的題目先做撰寫，遊戲的部分也讓初學者可以藉由玩來逐漸地記起這些語法，讓自己可以更瞭解語法在頁面呈現的狀況！</p>
					<ul class="actions"><li><a href="testpage.php" id="button1" class="button">了解更多</a></li></ul>
				</div>
			</div>
		
	</section>
	<section class="gridblock">	
			<h1>&nbsp&nbsp&nbsp&nbsp開發人員</h1>
			<h3><br>大家好！我們是中正大學資管四年級的學生，這是我們多媒體的專案，我們希望可以從開發這個學習網站中，也同時可以學習到一些東西</h3>
			<div class="icontable2"><img src="images/alex.jpg" id="cssstaff" width="150px" ;></div><div class="icontable2"><img src="images/jenny.jpg"  id="htmlstaff" width="150px";></div><div class="icontable2"><img src="images/shawn.jpeg" id="phpstaff" width="150px";></div>>
			<h3><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspCSS:Alex&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspHTML:Jenny&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspPHP:Shawn</h3>
	</section>
</div>
<div>
			<p class="copyright">©101 MIS Multimedia project 2016. Power by templated.co & pixelarity.com</p>
</div>
	<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>