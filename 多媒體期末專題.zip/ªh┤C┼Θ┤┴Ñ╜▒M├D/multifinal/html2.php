<!DOCTYPE html>
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(!isset($_SESSION['user'])){
	
}
else if(isset($_SESSION['user']))
{require_once("connMysql.php");
if(!empty ($_POST['result21']) && !empty ($_POST['result22']) && !empty ($_POST['result23']) && !empty ($_POST['result24']) && !empty ($_POST['result25'])
	&& !empty ($_POST['result26']) && !empty ($_POST['result28']) && !empty ($_POST['result29'])){
$query = 'UPDATE html SET html_2="1" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query);
}
$query_RecProduct = 'SELECT * FROM html WHERE account = "'.$_SESSION['account'].'";';
$RecProduct = mysql_query($query_RecProduct);
$row=array();
$row = mysql_fetch_array($RecProduct);

$sum=$row[1]+$row[2]+$row[3]+$row[4]+$row[5];

$result=round($sum/5*100);
$query1 = 'UPDATE html SET progress="'.$result.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);
}
?>
<html>
<body>
<h1>
<?php
		if(empty ($_POST['result21'])){
			echo "大標題文字";
		}
		else
			echo $_POST['result21'];
		?>
</h1>
   <p>
      
<?php
		if(empty ($_POST['result22'])){
			echo "請輸入文字";
		}
		else
			echo $_POST['result22'];
		?>
<br>
      
<?php
		if(empty ($_POST['result23'])){
			echo "用&lt;br&gt;跳到這一行";
		}
		else
			echo $_POST['result23'];
		?>

   </p>
       <hr width="
<?php
		if(empty ($_POST['result24'])){
			echo "430";
		}
		else
			echo $_POST['result24'];
		?>
		" color="
<?php
		if(empty ($_POST['result25'])){
			echo "#FF60AF";
		}
		else
			echo $_POST['result25'];
		?>
" size="
<?php
		if(empty ($_POST['result26'])){
			echo "5";
		}
		else
			echo $_POST['result26'];
		?>
">

   <p>
<?php
		if(empty ($_POST['result28'])){
			echo "請輸入文字";
		}
		else
			echo $_POST['result28'];
		?>
<br>
      
<?php
		if(empty ($_POST['result29'])){
			echo "用&lt;br&gt;跳到這一行";
		}
		else
			echo $_POST['result29'];
		?>

   </p>
</body>
</html>