<!DOCTYPE html>
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(!isset($_SESSION['user'])){
	
}
else if(isset($_SESSION['user']))
{require_once("connMysql.php");
if(!empty ($_POST['result32']) && !empty ($_POST['result33']) && !empty ($_POST['result35'])
	&& !empty ($_POST['result36']) && !empty ($_POST['result37']) && !empty ($_POST['result38']) && !empty ($_POST['result39']) && !empty ($_POST['result311'])){
$query = 'UPDATE html SET html_3="1" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query);
}
$query_RecProduct = 'SELECT * FROM html WHERE account = "'.$_SESSION['account'].'";';
$RecProduct = mysql_query($query_RecProduct);
$row=array();
$row = mysql_fetch_array($RecProduct);

$sum=$row[1]+$row[2]+$row[3]+$row[4]+$row[5];

$result=round($sum/5*100);
$query1 = 'UPDATE html SET progress="'.$result.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);
}
?>
<html>
<body>
<ul type=
<?php
		if(empty ($_POST['result31'])){
			echo "square";
		}
		else
			echo $_POST['result31'];
		?>
>
<li>
<?php
		if(empty ($_POST['result32'])){
			echo "清單物件1";
		}
		else
			echo $_POST['result32'];
		?>

<li>
<?php
		if(empty ($_POST['result33'])){
			echo "清單物件2";
		}
		else
			echo $_POST['result33'];
		?>

</ul>
<hr>
<ol type=
<?php
		if(empty ($_POST['result34'])){
			echo "1";
		}
		else
			echo $_POST['result34'];
		?>
>
<li>
<?php
		if(empty ($_POST['result35'])){
			echo "清單物件1";
		}
		else
			echo $_POST['result35'];
		?>

<li>
<?php
		if(empty ($_POST['result36'])){
			echo "清單物件2";
		}
		else
			echo $_POST['result36'];
		?>

</ol>
<hr>
<dl>
<dt>
<?php
		if(empty ($_POST['result37'])){
			echo "名詞1";
		}
		else
			echo $_POST['result37'];
		?>

<dd>
<?php
		if(empty ($_POST['result38'])){
			echo "解釋1";
		}
		else
			echo $_POST['result38'];
		?>

<dt>
<?php
		if(empty ($_POST['result39'])){
			echo "名詞2";
		}
		else
			echo $_POST['result39'];
		?>

<dd>
<?php
		if(empty ($_POST['result311'])){
			echo "解釋2";
		}
		else
			echo $_POST['result311'];
		?>

</dl>
</body>
</html>