<!DOCTYPE html>
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(!isset($_SESSION['user'])){
	
}
else if(isset($_SESSION['user']))
{require_once("connMysql.php");
if(!empty ($_POST['result41']) && !empty ($_POST['result42']) && !empty ($_POST['result43']) && !empty ($_POST['result44']) && !empty ($_POST['result45'])){
$query = 'UPDATE html SET html_4="1" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query);
}
$query_RecProduct = 'SELECT * FROM html WHERE account = "'.$_SESSION['account'].'";';
$RecProduct = mysql_query($query_RecProduct);
$row=array();
$row = mysql_fetch_array($RecProduct);

$sum=$row[1]+$row[2]+$row[3]+$row[4]+$row[5];

$result=round($sum/5*100);
$query1 = 'UPDATE html SET progress="'.$result.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);
}
?>
<html>
<body>
<body bgcolor="
<?php
		if(empty ($_POST['result41'])){
			echo "#FFECF5";
		}
		else
			echo $_POST['result41'];
		?>
">
<img src='images/img/
<?php
		if(empty ($_POST['result42'])){
			echo "3.png";
		}
		else
			echo $_POST['result42'];
		?>
		' width=50 height=50>
		<br>
<a href="
<?php
		if(empty ($_POST['result43'])){
			echo "http://www.ccu.edu.tw";
		}
		else
			echo $_POST['result43'];
		?>
">
<?php
		if(empty ($_POST['result44'])){
			echo "要連結的文字";
		}
		else
			echo $_POST['result44'];
		?>
</a>
<br>
<a href='
<?php
		if(empty ($_POST['result45'])){
			echo "http://www.ccu.edu.tw'><img src='images/click.png'></a>";
		}
		else
			echo $_POST['result45']."'><img src='images/click.png'></a>";
		?>
</body>
</body>
</html>