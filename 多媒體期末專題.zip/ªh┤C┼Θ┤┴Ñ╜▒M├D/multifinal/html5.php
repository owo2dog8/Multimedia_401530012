<!DOCTYPE html>
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(!isset($_SESSION['user'])){
	
}
else if(isset($_SESSION['user']))
{require_once("connMysql.php");
if(!empty ($_POST['result51']) && !empty ($_POST['result52']) && !empty ($_POST['result53']) && !empty ($_POST['result54']) && !empty ($_POST['result55'])
	&& !empty ($_POST['result56']) && !empty ($_POST['result57']) && !empty ($_POST['result58']) && !empty ($_POST['result59']) && !empty ($_POST['60'])
    && !empty ($_POST['result61']) && !empty ($_POST['result62']) && !empty ($_POST['result63']) && !empty ($_POST['result64'])){
$query = 'UPDATE html SET html_5="1" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query);
}

$query_RecProduct = 'SELECT * FROM html WHERE account = "'.$_SESSION['account'].'";';
$RecProduct = mysql_query($query_RecProduct);
$row=array();
$row = mysql_fetch_array($RecProduct);

$sum=$row[1]+$row[2]+$row[3]+$row[4]+$row[5];

$result=round($sum/5*100);
$query1 = 'UPDATE html SET progress="'.$result.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);

}
?>
<!--上方為進度SESSION-->
<html>
<body>
<form action="" method="POST">
請輸入文字<input type=text name=textField value="
<?php
		if(empty ($_POST['result51'])){
			echo "預設文字";
		}
		else
			echo $_POST['result51'];
		?>
">
<br>
在下面的格子輸入文字<br>
<textarea cols=58 rows=6 name=area>
<?php
		if(empty ($_POST['result52'])){
			echo "預設文字";
		}
		else
			echo $_POST['result52'];
		?>

</textarea>
<br>
請下拉並選擇
<select>
<option>
<?php
		if(empty ($_POST['result53'])){
			echo "選項1";
		}
		else
			echo $_POST['result53'];
		?>

<option>
<?php
		if(empty ($_POST['result54'])){
			echo "選項2";
		}
		else
			echo $_POST['result54'];
		?>

<option>
<?php
		if(empty ($_POST['result55'])){
			echo "選項3";
		}
		else
			echo $_POST['result55'];
		?>

<option>
<?php
		if(empty ($_POST['result56'])){
			echo "選項4";
		}
		else
			echo $_POST['result56'];
		?>

</select>
<br>
請多選
<input type=checkbox name=check>
<?php
		if(empty ($_POST['result57'])){
			echo "選項1";
		}
		else
			echo $_POST['result57'];
		?>

<input type=checkbox name=check>
<?php
		if(empty ($_POST['result58'])){
			echo "選項2";
		}
		else
			echo $_POST['result58'];
		?>

<input type=checkbox name=check>
<?php
		if(empty ($_POST['result59'])){
			echo "選項3";
		}
		else
			echo $_POST['result59'];
		?>

<input type=checkbox name=check>
<?php
		if(empty ($_POST['result60'])){
			echo "選項4";
		}
		else
			echo $_POST['result60'];
		?>

<br>
請單選
<input type=radio name=radio>
<?php
		if(empty ($_POST['result61'])){
			echo "選項1";
		}
		else
			echo $_POST['result61'];
		?>

<input type=radio name=radio>
<?php
		if(empty ($_POST['result62'])){
			echo "選項2";
		}
		else
			echo $_POST['result62'];
		?>

<input type=radio name=radio>
<?php
		if(empty ($_POST['result63'])){
			echo "選項3";
		}
		else
			echo $_POST['result63'];
		?>

<input type=radio name=radio>
<?php
		if(empty ($_POST['result64'])){
			echo "選項4";
		}
		else
			echo $_POST['result64'];
		?>

<br>
<input type=submit value="送出">
<input type=reset value="清除">
</form>
</body>
</html>