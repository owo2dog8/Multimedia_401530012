<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(isset($_SESSION['user'])){
		require_once("connMysql.php");
		$tick = 'SELECT * FROM html WHERE account = "'.$_SESSION['account'].'";';
		$ticktick = mysql_query($tick);
		$row = mysql_fetch_array($ticktick);
}
else{}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="htmlpage.css" rel="stylesheet" type="text/css" media="all" />
<link href="ProgressBarWars.css" rel="stylesheet" />

<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="js/ProgressBarWars.js"></script>
<style type="text/css">
	.progress{
		margin-top: 30px;
	}
</style>


<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>
<script type="text/javascript">
function resettext(id){
           //恢復文字
           if(id.value == "")
           {
			id.value = id.defaultValue;
			id.className ="t1";   
           }
                     }
function cleartext (id){ 
          //清除文字
			id.value ="";
			d.className ="";   
          }
</script>

</head>
<body>

<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li class="current_page_item"><a href="htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>HTML教學區</h1>
			<div class="progress" id="vaderTime"></div>
			<?php
			if(isset($_SESSION['user'])){
			?>
			<style>
			ul.style1
			{
				margin: 0;
				padding: 7.5em 0em 0em 0em;
				overflow: hidden;
				list-style: none;
				color: #6c6c6c;
			}
			pre
			{

	
				line-height: 140%;
	
			}
			
			</style>
			 <script>
			 var num = <?php echo $row[6] ?>;
			$("#vaderTime").ProgressBarWars({porcentaje:num,estilo:"vader",tiempo:1000});
					
		  </script>
		  <input type="button" class="button2" value="更新個人進度" onClick="window.location.reload()">
			<?php }?>
	    </div>

	    <div id="onecolumnfirst">
			<div class="title ">
				<h2>基本構造</h2>
			</div>
			<p>
<pre>
HTML的文件要以&lt;!DOCTYPE html&gt;作為開頭
文件前端要有&lt;html&gt;，尾端以&lt;/html&gt;作為結尾將整個文件包覆在內
且文件主要內容應以放在&lt;body&gt;和&lt;/body&gt;之間


利用<strong>&lt;!DOCTYPE html&gt;</strong>定義網頁中HTML語法的版本
利用<strong>&lt;html&gt;</strong>供瀏覽器識別此為HTML文件
利用<strong>&lt;body&gt;</strong>顯示網頁的內容
在body標籤內盡情設計網頁想呈現的樣子
利用<strong>&lt;/body&gt;</strong>把內容包起來
再用<strong>&lt;/html&gt;</strong>把html標籤包起來

<strong>
&lt;!DOCTYPE html&gt;
   &lt;html&gt;
     &lt;body&gt;
     你的內容
     &lt;/body&gt;
   &lt;/html&gt;
</strong>
</pre>
			</p>
		</div>
<!--第一個教學-->		
		
		<div id="onecolumn">
			<div class="title ">
				<h2>標題與內文</h2>
			</div>
			<p>
<pre>
標題:
文字標題的字體大小主要可分為最大字體h1到最小字體h6
利用標籤&lt;h1&gt;...&lt;/h1&gt;將文字包覆
內文:
在文句之間可用&lt;br&gt;將句子跳下一行
標籤&lt;p&gt;...&lt;/p&gt;則是代表段落
若使用&lt;p&gt;標籤則不需&lt;br&gt;便可自行跳下一段落
若想使用分隔線，可使用&lt;hr&gt;標籤分隔區塊
並且自行設定分隔線的外觀

利用<strong>&lt;h1&gt;...&lt;/h1&gt;</strong>設定標題所需的字體大小
利用<strong>&lt;br&gt;</strong>跳下一行開始另一句子
利用<strong>&lt;p&gt;...&lt;/p&gt;</strong>顯示一個段落
利用<strong>&lt;hr&gt;</strong>設定分隔線外觀將區塊逐一分隔
<strong>&lt;hr&gt;</strong>可以改變<strong>size</strong>、<strong>width</strong>、<strong>color</strong>以及<strong>align</strong>
<strong>size</strong>為數字、<strong>width</strong>可為數字或比例
<strong>color</strong>為#代碼或基本顏色(red, black...)
<strong>align</strong>可為(center、left、right)

<strong>
&lt;h1&gt;這是大標題&lt;/h1&gt;
   &lt;p&gt;
      這是我的第一個段落&lt;br&gt;
      我用br標籤跳到下一句
   &lt;/p&gt;
       &lt;hr width="1200" color="#FF60AF" size="5"
        align="left"&gt;
   &lt;p&gt;
      這是我的第二個段落&lt;br&gt;
      段落中間我用寬1200、顏色代碼#FF60AF&lt;br&gt;
      大小5以及位置在左邊的分隔線分隔
   &lt;/p&gt;
</strong>
</pre>
			</p>
		</div>
<!--第二個教學-->
		<div id="onecolumn">
			<div class="title ">
				<h2>各式清單</h2>
			</div>
			<p>
<pre>
圓頭清單:
只要加入&lt;ul&gt;標籤，便可做出小圓頭清單
也可利用type=disc、circle、square讓圓點有所變化
<strong>&lt;ul type=square&gt;</strong>
<strong>&lt;li&gt;</strong>物件1
<strong>&lt;li&gt;</strong>物件2
<strong>&lt;/ul&gt;</strong>
結果:
<strong>￭</strong> 物件1
<strong>￭</strong> 物件2

數字清單:
只要加入&lt;ol&gt;標籤，便可做出數字清單
可利用type=A、a、I、i來做數字的變化
<strong>&lt;ol type=I&gt;</strong>
<strong>&lt;li&gt;</strong>事件1
<strong>&lt;li&gt;</strong>事件2
<strong>&lt;/ol&gt;</strong>
結果:
<strong>i.</strong> 事件1
<strong>ii.</strong>事件2

定義清單:
只要加入以下的標籤可做一個定義清單
<strong>&lt;dl&gt;</strong>
<strong>&lt;dt&gt;</strong>智佳
   <strong>&lt;dd&gt;</strong>是多媒體的學生
<strong>&lt;dt&gt;</strong>第1組
   <strong>&lt;dd&gt;</strong>是智佳在多媒體的組別
<strong>&lt;/dl&gt;</strong>
結果:
<dt><strong>智佳</strong><dd>是多媒體的學生<dt><strong>第1組</strong><dd>是智佳在多媒體的組別

</pre>
			</p>
		</div>
<!--第三個教學-->
		<div id="onecolumn">
			<div class="title ">
				<h2>背景、圖片與連結</h2>
			</div>
			<p>
<pre>
背景:
可以利用&lt;bgcolor&gt;設定背景顏色
或是background插入圖片位址
圖片:
若是想在網頁中插入圖片
只需插入&lt;img&gt;
連結:
連結所需使用到的程式碼為&lt;a href&gt;

利用<strong>&lt;bgcolor&gt;</strong>色碼設定body背景的顏色
利用<strong>&lt;background&gt;</strong>設定背景圖片的位址(需加附檔名)
利用<strong>&lt;img&gt;</strong>設定插入圖片的位址
利用<strong>&lt;a href&gt;</strong>設定想連結的網址(文字或圖片皆可連結)

注意:
若想插入資料夾內的圖片
必須確定圖片在資料夾內
並正確寫出檔案在哪個資料夾的位置

<strong>&lt;body bgcolor=&quot;#FFECF5&quot;&gt;</strong>
(或<strong>&lt;body background=&quot;http://goo.gl/DeF2bX&quot;&gt;</strong>)
<strong>&lt;img src=&quot;images/sky.jpg&quot; width=&quot;100&quot; height=&quot;50&quot;&gt;</strong>
<strong>&lt;a href=&quot;http://www.ccu.edu.tw/&quot;&gt;CCU&lt;/a&gt;</strong>
<strong>&lt;a href=&quot;http://www.ccu.edu.tw/&quot;&gt;&lt;img src=&quot;c.gif&quot;&gt;&lt;/a&gt;</strong>
<strong>&lt;/body&gt;</strong>


</pre>
			</p>
		</div>
<!--第四個教學-->
		<div id="onecolumn">
			<div class="title ">
				<h2>表單製作</h2>
			</div>
			<p>
<pre>
表單標籤&lt;form&gt;&lt;/form&gt;
將下列表單內容包在標籤內
文字欄位: &lt;input type=text&gt;
文字輸入方塊: &lt;textarea&gt;&lt;/teatarea&gt;
下拉式選項:
&lt;select&gt;
　 &lt;option&gt;
&lt;/select&gt;
多選核取方塊: &lt;input type=checkbox&gt;
單選核取方塊: &lt;input type=radio&gt;
按鈕:
&lt;input type=submit&gt;
&lt;input type=reset&gt;
&lt;input type=button&gt;

<strong>&lt;form&gt;</strong>
可讓使用者輸入的欄位<strong>&lt;input type=text&gt;</strong>
使用者輸入的方塊<strong>&lt;textarea&gt;&lt;/teatarea&gt;</strong>
下拉式選單供使用者選擇
<strong>&lt;select&gt;
　 &lt;option&gt;
&lt;/select&gt;</strong>
可供使用者選多個選項<strong>&lt;input type=checkbox&gt;</strong>
僅供使用者選一個選項<strong>&lt;input type=radio&gt;</strong>
執行由action所指定的程式<strong>&lt;input type=submit&gt;</strong>
清除表單<strong>&lt;input type=reset&gt;</strong>
設計者自行設計的按鈕<strong>&lt;input type=button&gt;</strong>
<strong>&lt;/form&gt;</strong>

<strong>&lt;form action=&quot;#&quot; method=&quot;POST&quot;&gt;
請輸入文字&lt;input type=text name=textField value="預設字"&gt;
在下面的格子輸入文字&lt;br&gt;
&lt;textarea cols=60 rows=6 name=area&gt;
預設文字
&lt;/textarea&gt;
請下拉並選擇
&lt;select&gt;
   &lt;option&gt;蘋果
   &lt;option&gt;香蕉
   &lt;option&gt;草莓
   &lt;option&gt;芒果
&lt;/select&gt;
請多選
   &lt;input type=checkbox name=fruit&gt;蘋果
   &lt;input type=checkbox name=fruit&gt;香蕉
   &lt;input type=checkbox name=fruit&gt;草莓
   &lt;input type=checkbox name=fruit&gt;芒果
請單選
   &lt;input type=radio name=fruit&gt;蘋果
   &lt;input type=radio name=fruit&gt;香蕉
   &lt;input type=radio name=fruit&gt;草莓
   &lt;input type=radio name=fruit&gt;芒果
&lt;input type=submit&gt;送出
&lt;input type=reset&gt;清除
&lt;/form&gt;</strong><br><br>




</pre>
			</p>
		</div>
<!--第五個教學-->
	</div>
	
	
	<div id="sidebar">
	<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST" action="html1.php" method="POST" accept-charset="UTF-8" target="frame1">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
<input type="text" name="result1" id="result1" size="30" placeholder="請在這行打上想顯示的文字"/>
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1" >結果呈現</button>
</pre>
</form>
    			</p>
    			<h3>結果範例：</h3>
<iframe name="frame1" src="html1.php" width="450" height="130"></iframe>
				
			</li>
		</ul>
		<!--第一個測試-->
		<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST" action="html2.php" method="POST" accept-charset="UTF-8" target="frame2">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;h1&gt;<input type="text" name="result21" id="result21" size="30" placeholder="大標題文字"/>&lt;/h1&gt;
   &lt;p&gt;
      <input type="text" name="result22" id="result22" size="30" placeholder="請輸入文字"/>&lt;br&gt;
      <input type="text" name="result23" id="result23" size="30" placeholder="用<br>跳到這一行"/>
   &lt;/p&gt;
       &lt;hr width="<input type="text" name="result24" id="result24" size="4" placeholder="430"/>" color="<input type="text" name="result25" id="result25" size="5" placeholder="#FF60AF"/>" size="<input type="text" name="result26" id="result26" size="2" placeholder="5"/>"&gt;
   &lt;p&gt;
      <input type="text" name="result28" id="result28" size="30" placeholder="請輸入文字"/>&lt;br&gt;
      <input type="text" name="result29" id="result29" size="30" placeholder="用<br>跳到這一行"/>
   &lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1" >結果呈現</button>

</pre>
</form>
    			</p>
    			<h3>結果範例：</h3>
<iframe name="frame2" src="html2.php" width="450" height="245"></iframe>

			</li>
		</ul>
		<!--第二個測試-->
		<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST" action="html3.php" method="POST" accept-charset="UTF-8" target="frame3">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;ul type=<input type="text" name="result31" id="result31" size="20" placeholder="square, circle, disc或無"/>&gt;
&lt;li&gt;<input type="text" name="result32" id="result32" size="30" placeholder="清單物件1"/>
&lt;li&gt;<input type="text" name="result33" id="result33" size="30" placeholder="清單物件2"/>
&lt;/ul&gt;
&lt;hr&gt;
&lt;ol type=<input type="text" name="result34" id="result34" size="20" placeholder="A, a, I, i, 1或無"/>&gt;
&lt;li&gt;<input type="text" name="result35" id="result35" size="30" placeholder="清單物件1"/>
&lt;li&gt;<input type="text" name="result36" id="result36" size="30" placeholder="清單物件2"/>
&lt;/ol&gt;
&lt;hr&gt;
&lt;dl&gt;
&lt;dt&gt;<input type="text" name="result37" id="result37" size="15" placeholder="名詞1"/>
&lt;dd&gt;<input type="text" name="result38" id="result38" size="30" placeholder="解釋1"/>
&lt;dt&gt;<input type="text" name="result39" id="result39" size="15" placeholder="名詞2"/>
&lt;dd&gt;<input type="text" name="result311" id="result311" size="30" placeholder="解釋2"/>
&lt;/dl&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1"></button>
</pre>
</form>
<script language="JavaScript">
 function myrefresh()
 {
      window.location.reload();
 }
</script>
    			</p>
    			<h3>結果範例：</h3>
<iframe name="frame3" src="html3.php" width="450" height="220"></iframe>

			</li>
		</ul>
<!--第三個測試-->
<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST" action="html4.php" method="POST" accept-charset="UTF-8" target="frame4">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;body bgcolor=&quot;<input type="text" name="result41" id="result41" size="10" placeholder="#FFECF5"/>&quot;&gt;
&lt;img src=&quot;images/img/<input type="text" name="result42" id="result42" size="36" placeholder="3.png(資料夾內已有數字1~8的png檔可用來測試)"/>&quot;&gt;
&lt;br&gt;
&lt;a href=&quot;<input type="text" name="result43" id="result43" size="25" placeholder="輸入網址(http://www.ccu.edu.tw)"/>&quot;&gt;<input type="text" name="result44" id="result44" size="10" placeholder="要連結的文字"/>&lt;/a&gt;&lt;br&gt;
&lt;a href=&quot;<input type="text" name="result45" id="result45" size="18" placeholder="輸入網址"/>&quot;&gt;&lt;img src=&quot;images/click.png&quot;&gt;&lt;/a&gt;&lt;br&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1" >結果呈現</button>
</pre>
</form>
    			</p>
    			<h3>結果範例：</h3>
<iframe name="frame4" src="html4.php" width="450" height="210"></iframe>

			</li>
		</ul>
<!--第四個測試-->
<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				
<form method="POST" action="html5.php" method="POST" accept-charset="UTF-8" target="frame5">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;form action=&quot;try.php&quot; method=&quot;POST&quot;&gt;
請輸入文字&lt;input type=text name=field value="<input type="text" name="result51" id="result51" size="5" placeholder="預設文字"/>"&gt;
&lt;br&gt;
在下面的格子輸入文字&lt;br&gt;
&lt;textarea cols=58 rows=6 name=area&gt;
<textarea cols=58 rows=6 name="result52" placeholder="預設文字"></textarea>
&lt;/textarea&gt;
&lt;br&gt;
請下拉並選擇
&lt;select&gt;
&lt;option&gt;<input type="text" name="result53" id="result53" size="5" placeholder="選項1"/>
&lt;option&gt;<input type="text" name="result54" id="result54" size="5" placeholder="選項2"/>
&lt;option&gt;<input type="text" name="result55" id="result55" size="5" placeholder="選項3"/>
&lt;option&gt;<input type="text" name="result56" id="result56" size="5" placeholder="選項4"/>
&lt;/select&gt;
&lt;br&gt;
請多選
&lt;input type=checkbox name=check&gt;<input type="text" name="result57" id="result57" size="5" placeholder="選項1"/>
&lt;input type=checkbox name=check&gt;<input type="text" name="result58" id="result58" size="5" placeholder="選項2"/>
&lt;input type=checkbox name=check&gt;<input type="text" name="result59" id="result59" size="5" placeholder="選項3"/>
&lt;input type=checkbox name=check&gt;<input type="text" name="result60" id="result60" size="5" placeholder="選項4"/>
&lt;br&gt;
請單選
&lt;input type=radio name=radio&gt;<input type="text" name="result61" id="result61" size="5" placeholder="選項1"/>
&lt;input type=radio name=radio&gt;<input type="text" name="result62" id="result62" size="5" placeholder="選項2"/>
&lt;input type=radio name=radio&gt;<input type="text" name="result63" id="result63" size="5" placeholder="選項3"/>
&lt;input type=radio name=radio&gt;<input type="text" name="result64" id="result64" size="5" placeholder="選項4"/>
&lt;br&gt;
&lt;input type=submit value=&quot;送出&quot;&gt;
&lt;input type=reset value=&quot;清除&quot;&gt;
&lt;/form&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1" >結果呈現</button>
</pre>
</form>
    			<h3>結果範例：</h3>
<iframe name="frame5" src="html5.php" width="450" height="250"></iframe>

			</li>
		</ul>
<!--第五個測試-->
	</div>
	
</div>
<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<?php
 if (isset($_SESSION['user'])) {
 ?>
	<a id="login" href="logout.php" >登出</a>
 <?php

 } else {
   ?>
	<a id="login" href="login.php" >登入</a>
   <?php
 }?>

<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>

</body>
</html>
