<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="htmlpage.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>
<script type="text/javascript">
function resettext(id){
           //恢復文字
           if(id.value == "")
           {
			id.value = id.defaultValue;
			id.className ="t1";   
           }
                     }
function cleartext (id){ 
          //清除文字
			id.value ="";
			d.className ="";   
          }
</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li><a href="http://localhost:8081/multifinal/index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="http://localhost:8081/multifinal/htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="http://localhost:8081/multifinal/phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="http://localhost:8081/multifinal/csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li><a href="http://localhost:8081/multifinal/htmltest.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>HTML測驗區</h1>
	    </div>
<!--題目開始-->
	    <div id="onecolumnfirst">
			<div class="title ">
<pre>
<h2>HTML題目</h2><br>
<h3>標題與段落                  難度2</h3>
</pre>
			</div>
			<p>
<pre>
下面有幾個句子，請依照需求給予適當的標籤:
<strong>National Chung Cheng University</strong>是最重要的內容，
<strong>Management Information System</strong>是第二重要的內容，
<strong>About</strong>只比MIS少一點重要
<strong>MIS is a very intersting course!!</strong>這句話，
只是一個段落而已。

<strong>結果範例:</strong>
</pre>
<!DOCTYPE html>
<html>
<body bgcolor=white>
<h1>National Chung Cheng University </h1>
<h2>Management Information System </h2>
<h3>About </h3>
<p>MIS is a very interesting course!! </p></body></html>
			</p>
		</div>
<!--第一個題目-->
	    <div id="onecolumn">
			<div class="title ">
<pre>
<h2>HTML題目</h2><br>
<h3>表單                   難度4</h3>
</pre>
			</div>
			<p>
<pre>
請製作出一個含有下拉式選單、多選題和單選題的表單，
<strong>下拉式選單</strong>有3個選項，分別為&quot;台北&quot;、&quot;嘉義&quot;、&quot;高雄&quot;，
<strong>多選題</strong>有5個選項，分別為&quot;水果&quot;、&quot;蔬菜&quot;、&quot;麵包&quot;、&quot;肉類&quot;、&quot;餅乾&quot;，
<strong>單選題</strong>有4個選項，分別為&quot;大一&quot;、&quot;大二&quot;、&quot;大三&quot;、&quot;大四&quot;，
並且有<strong>送出</strong>跟<strong>清除</strong>按鈕。

<strong>結果範例:</strong>
</pre>
<!DOCTYPE html>
<html>
<body bgcolor=white>
你從哪裡來
<select>
 <option>台北
 <option>嘉義
 <option>高雄
</select>
<br>
你喜歡吃什麼
<input type=checkbox >水果
<input type=checkbox >蔬菜
<input type=checkbox >麵包
<input type=checkbox >肉類
<input type=checkbox >餅乾
<br>
你現在幾年級
<input type=radio >大一
<input type=radio >大二
<input type=radio >大三
<input type=radio >大四
<br>
<input type=submit value="送出">
<input type=reset value="清除">
</body>
</html>
<pre>




















</pre>
			</p>
		</div>	
<!--第二個題目-->	
	    <div id="onecolumn">
			<div class="title ">
<pre>
<h2>HTML題目</h2><br>
<h3>圖片與連結                   難度8</h3>
</pre>
			</div>
			<p>
<pre>
在我放置網頁的資料夾中，
有一個名為images的資料夾，
我有一個檔名為<strong>longpikachu</strong>的<strong>jpg</strong>檔案存放在
<strong>images</strong>資料夾中的<strong>img</strong>資料夾內的<strong>cartoon</strong>資料夾裡面，
但是那張圖片的比例太長了，
我希望你可以把圖片調整成<strong>正方形</strong>，
並且讓圖片能連結到<strong>中正大學首頁</strong>。

<strong>結果範例:</strong>
</pre>
<!DOCTYPE html>
<html>
<body>
<a href="http://www.ccu.edu.tw"><img src="images/pikachu.jpg"></a>
</body>
</html>
			</p>
		</div>	
<!--第三個題目-->	
	</div>

<!--測驗開始-->
	<div id="sidebar">
		<ul class="style1">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
<input type="text" name="result1" id="result1" size="5"/> National Chung Cheng University <input type="text" name="result2" id="result2" size="5"/>

<input type="text" name="result3" id="result3" size="5"/> Management Information System <input type="text" name="result4" id="result4" size="5"/>

<input type="text" name="result5" id="result5" size="5"/> About <input type="text" name="result6" id="result6" size="5"/>

<input type="text" name="result7" id="result7" size="5"/> MIS is a very interesting course!! <input type="text" name="result8" id="result8" size="5"/>
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>
<?php
if(!isset ($_POST['result1']) && !isset ($_POST['result2']) && !isset ($_POST['result3']) &&  !isset ($_POST['result4']) &&
!isset ($_POST['result5']) &&   !isset ($_POST['result6']) &&  !isset ($_POST['result7']) &&  !isset ($_POST['result8'])){

}

else if(preg_replace('/\s/','', $_POST['result1'])=='<h1>' && preg_replace('/\s/','', $_POST['result2'])=='</h1>' && preg_replace('/\s/','', $_POST['result3'])=='<h2>' && preg_replace('/\s/','', $_POST['result4'])=='</h2>' 
&& preg_replace('/\s/','', $_POST['result5'])=='<h3>' && preg_replace('/\s/','', $_POST['result5'])=='</h3>' && preg_replace('/\s/','', $_POST['result7'])=='<p>' && preg_replace('/\s/','', $_POST['result8'])=='</p>'){
					$correct2 = 'UPDATE test SET htmltest_2="1" WHERE account = "'.$_SESSION['account'].'";';
					$right2 = mysql_query($correct2);
?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "按按鈕繼續!", "success") 

				});
				</script><?php
}
else 
	?>
    			</p>
				
			</li>
		</ul>
		<!--第一個測驗-->
<ul class="style2">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;form&gt;
你從哪裡來
&lt;select&gt;
 &lt;<input type="text" name="result9" id="result9" size="5"/>&gt; <input type="text" name="result10" id="result10" size="5"/>
 
 &lt;<input type="text" name="result11" id="result11" size="5"/>&gt; <input type="text" name="result12" id="result12" size="5"/>
 
 &lt;<input type="text" name="result13" id="result13" size="5"/>&gt; <input type="text" name="result14" id="result14" size="5"/>
&lt;/select&gt;&lt;br&gt;
你喜歡吃什麼
&lt;input type=<input type="text" name="result15" id="result15" size="5"/>&gt; <input type="text" name="result16" id="result16" size="5"/>

&lt;input type=<input type="text" name="result17" id="result17" size="5"/>&gt; <input type="text" name="result18" id="result18" size="5"/>

&lt;input type=<input type="text" name="result19" id="result19" size="5"/>&gt; <input type="text" name="result20" id="result20" size="5"/>

&lt;input type=<input type="text" name="result21" id="result21" size="5"/>&gt; <input type="text" name="result22" id="result22" size="5"/>

&lt;input type=<input type="text" name="result23" id="result23" size="5"/>&gt; <input type="text" name="result24" id="result24" size="5"/>&lt;br&gt;
你現在幾年級
&lt;input type=<input type="text" name="result25" id="result25" size="5"/>&gt; <input type="text" name="result26" id="result26" size="5"/>

&lt;input type=<input type="text" name="result27" id="result27" size="5"/>&gt; <input type="text" name="result28" id="result28" size="5"/>

&lt;input type=<input type="text" name="result29" id="result29" size="5"/>&gt; <input type="text" name="result30" id="result30" size="5"/>

&lt;input type=<input type="text" name="result31" id="result31" size="5"/>&gt; <input type="text" name="result32" id="result32" size="5"/>&lt;br&gt;

&lt;input type=<input type="text" name="result33" id="result35" size="5"/> value="送出"&gt;

&lt;input type=<input type="text" name="result34" id="result36" size="5"/> value="清除"&gt;
&lt;/form&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>
<?php
if(!isset ($_POST['result9']) && !isset ($_POST['result10']) && !isset ($_POST['result11']) &&  !isset ($_POST['result12']) &&
!isset ($_POST['result13']) &&   !isset ($_POST['result14']) &&  !isset ($_POST['result15']) &&  !isset ($_POST['result16']) &&
!isset ($_POST['result17']) &&   !isset ($_POST['result18']) &&  !isset ($_POST['result19']) &&  !isset ($_POST['result20']) &&
!isset ($_POST['result21']) &&   !isset ($_POST['result22']) &&  !isset ($_POST['result23']) &&  !isset ($_POST['result24']) &&
!isset ($_POST['result25']) &&   !isset ($_POST['result26']) &&  !isset ($_POST['result27']) &&  !isset ($_POST['result28']) &&
!isset ($_POST['result29']) &&   !isset ($_POST['result30']) &&  !isset ($_POST['result31']) &&  !isset ($_POST['result32']) &&
!isset ($_POST['result33']) &&   !isset ($_POST['result34'])){
}


else if(empty ($_POST['result9']) || empty ($_POST['result10']) || empty ($_POST['result11']) ||  empty ($_POST['result12']) ||
empty ($_POST['result13']) ||   empty ($_POST['result14']) ||  empty ($_POST['result15']) ||  empty ($_POST['result16']) ||
empty ($_POST['result17']) ||   empty ($_POST['result18']) ||  empty ($_POST['result19']) ||  empty ($_POST['result20']) ||
empty ($_POST['result21']) ||   empty ($_POST['result22']) ||  empty ($_POST['result23']) ||  empty ($_POST['result24']) ||
empty ($_POST['result25']) ||   empty ($_POST['result26']) ||  empty ($_POST['result27']) ||  empty ($_POST['result28']) ||
empty ($_POST['result29']) ||   empty ($_POST['result30']) ||  empty ($_POST['result31']) ||  empty ($_POST['result32']) ||
empty ($_POST['result33']) ||   empty ($_POST['result34'])){
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "按按鈕繼續!", "error")
									});
									</script><?php
}
else if(preg_replace('/\s/','', $_POST['result9'])=='option' && preg_replace('/\s/','', $_POST['result10'])=='台北' && preg_replace('/\s/','', $_POST['result11'])=='option' && preg_replace('/\s/','', $_POST['result12'])=='嘉義' 
&& preg_replace('/\s/','', $_POST['result13'])=='option' && preg_replace('/\s/','', $_POST['result14'])=='高雄' && preg_replace('/\s/','', $_POST['result15'])=='checkbox' && preg_replace('/\s/','', $_POST['result16'])=='水果'
&& preg_replace('/\s/','', $_POST['result17'])=='checkbox' && preg_replace('/\s/','', $_POST['result18'])=='蔬菜' && preg_replace('/\s/','', $_POST['result19'])=='checkbox' && preg_replace('/\s/','', $_POST['result20'])=='麵包'
&& preg_replace('/\s/','', $_POST['result21'])=='checkbox' && preg_replace('/\s/','', $_POST['result22'])=='肉類' && preg_replace('/\s/','', $_POST['result23'])=='checkbox' && preg_replace('/\s/','', $_POST['result24'])=='餅乾'
&& preg_replace('/\s/','', $_POST['result25'])=='radio' && preg_replace('/\s/','', $_POST['result26'])=='大一' && preg_replace('/\s/','', $_POST['result27'])=='radio' && preg_replace('/\s/','', $_POST['result28'])=='大二'
&& preg_replace('/\s/','', $_POST['result29'])=='radio' && preg_replace('/\s/','', $_POST['result30'])=='大三' && preg_replace('/\s/','', $_POST['result31'])=='radio' && preg_replace('/\s/','', $_POST['result32'])=='大四'
&& preg_replace('/\s/','', $_POST['result33'])=='submit' && preg_replace('/\s/','', $_POST['result34'])=='reset'){
?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "按按鈕繼續!", "success") 

				});
				</script><?php
}
else if(preg_replace('/\s/','', $_POST['result9'])!='option' && preg_replace('/\s/','', $_POST['result10'])!='台北' && preg_replace('/\s/','', $_POST['result11'])!='option' && preg_replace('/\s/','', $_POST['result12'])!='嘉義' 
&& preg_replace('/\s/','', $_POST['result13'])!='option' && preg_replace('/\s/','', $_POST['result14'])!='高雄' && preg_replace('/\s/','', $_POST['result15'])!='checkbox' && preg_replace('/\s/','', $_POST['result16'])!='水果'
&& preg_replace('/\s/','', $_POST['result17'])!='checkbox' && preg_replace('/\s/','', $_POST['result18'])!='蔬菜' && preg_replace('/\s/','', $_POST['result19'])!='checkbox' && preg_replace('/\s/','', $_POST['result20'])!='麵包'
&& preg_replace('/\s/','', $_POST['result21'])!='checkbox' && preg_replace('/\s/','', $_POST['result22'])!='肉類' && preg_replace('/\s/','', $_POST['result23'])!='checkbox' && preg_replace('/\s/','', $_POST['result24'])!='餅乾'
&& preg_replace('/\s/','', $_POST['result25'])!='radio' && preg_replace('/\s/','', $_POST['result26'])!='大一' && preg_replace('/\s/','', $_POST['result27'])!='radio' && preg_replace('/\s/','', $_POST['result28'])!='大二'
&& preg_replace('/\s/','', $_POST['result29'])!='radio' && preg_replace('/\s/','', $_POST['result30'])!='大三' && preg_replace('/\s/','', $_POST['result31'])!='radio' && preg_replace('/\s/','', $_POST['result32'])!='大四'
&& preg_replace('/\s/','', $_POST['result33'])!='submit' && preg_replace('/\s/','', $_POST['result34'])!='reset'){
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "按按鈕繼續!", "error")
									});
				</script><?php
}
else
	?>

    			</p>
				
			</li>
		</ul>
		<!--第二個測驗-->
		<ul class="style3">
			<li class="first">
				<h3>測試自己的程式碼～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;a <input type="text" name="result35" id="result35" size="5"/> = &quot;<input type="text" name="result36" id="result36" size="30"/>&quot;&gt;

&lt;img src=&quot; <input type="text" name="result37" id="result37" size="30"/> &quot;

<input type="text" name="result38" id="result38" size="10"/> = <input type="text" name="result39" id="result39" size="5"/>  <input type="text" name="result40" id="result40" size="10"/> = <input type="text" name="result41" id="result41" size="5"/> &gt;
&lt;/a&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>
<?php
if(!isset ($_POST['result35']) && !isset ($_POST['result36']) && !isset ($_POST['result37']) &&  !isset ($_POST['result38']) &&
!isset ($_POST['result39']) &&   !isset ($_POST['result40']) &&  !isset ($_POST['result41'])){
}


else if(empty ($_POST['result35']) || empty ($_POST['result36']) || empty ($_POST['result37']) ||  empty ($_POST['result38']) ||
empty ($_POST['result39']) ||   empty ($_POST['result40']) ||  empty ($_POST['result41'])){
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "按按鈕繼續!", "error")
									});
									</script><?php
}
else if(preg_replace('/\s/','', $_POST['result35'])=='href' && preg_replace('/\s/','', $_POST['result36'])=='http://www.ccu.edu.tw' && preg_replace('/\s/','', $_POST['result37'])=='images/img/cartoon/longpikachu.jpg'
 && ((preg_replace('/\s/','', $_POST['result38'])=='width' && preg_replace('/\s/','', $_POST['result40'])=='height') || (preg_replace('/\s/','', $_POST['result38'])=='height' && preg_replace('/\s/','', $_POST['result40'])=='width'))){
	 if($_POST['result39']=$_POST['result41']){
		 ?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "按按鈕繼續!", "success") 

				});
				</script><?php
		 
	 }
	 else
?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "按按鈕繼續!", "success") 

				});
				</script><?php
}
else if(preg_replace('/\s/','', $_POST['result35'])!='href' && preg_replace('/\s/','', $_POST['result36'])!='http://www.ccu.edu.tw' && preg_replace('/\s/','', $_POST['result37'])!='images/img/cartoon/longpikachu.jpg'
&& (preg_replace('/\s/','', $_POST['result38'])!='width' || preg_replace('/\s/','', $_POST['result38'])!='height') && (preg_replace('/\s/','', $_POST['result40'])!='width' || preg_replace('/\s/','', $_POST['result40'])!='height')){
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "按按鈕繼續!", "error")
									});
				</script><?php
}
else
	?>

    			</p>
				
			</li>
		</ul>
		<!--第三個測驗-->
		

	</div>
	
</div>
<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<?php
 if (isset($_SESSION['user'])) {
 ?>
	<a id="login" href="logout.php" >登出</a>
 <?php

 } else {
   ?>
	<a id="login" href="login.php" >登入</a>
   <?php
 }?>

<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>

</body>
</html>


