<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="index.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    		if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}
	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>動機與方法</h1>
		</div>
		<div id="onecolumnfirst">
			<div class="title">
				<h2>動機</h2>
			</div>
			<p>
			<h3>程式 x 開始 x 最難</h3>
			   <p>因為我們自己對於開發網頁程式也是初學階段，所以我們能深刻體會<strong>從零開始要建置一個網頁是十分具有難度的</strong>，而且在寫網頁程式時會發現，
			  <strong> 不是學會一種工具就能夠寫出網頁來</strong>，
			   今天你必須要了解HTML標籤代表的意思、該放在哪裡，
			   資料如何利用PHP做傳遞與控制，
			   版面的樣式如何在CSS設定才能符合自己心目中的樣子，
			   這其實是一件沒那麼容易的事情，
			   所以我們希望能做一個這樣子的教學網站，能夠讓初學者參考，
			   同時讓我們也在做中學</p>
			<br>
			<h3>互動性與實作性</h3>
			   <p>教學如果是單純的將資料Show出來，我們認為效果是不太好的，要是在提供資料與範例時讓使用者能稍微<strong>動動腦思考一下</strong>，印象會更深刻。
				我們學程式時自己也感覺到，聽人家講程式怎麼寫，剛聽完好像都聽懂了，也了解意思，可是自己要打程式碼時，總覺得甚麼都打不出來，
				那要是我們這個網站能夠解決這樣子的問題，至少可以<strong>降低初學者剛開始寫程式的恐懼</strong>，同時也讓他們對程式的基本概念有認識。</p>
			    
			<br>
			<h3>你我共同邊學邊玩</h3>
			    <p>除了教學以外，要是能搭配有趣的教學測驗及小遊戲，來幫助初學者<strong>在學習中獲得成就感與激發興趣</strong>，
				在學習初期若能達到這樣的效果那可以給初學者的幫助可能會超出我們的預期，而構思如何將概念與遊戲結合並呈現，
				對我們來說思考的過程也十分有益。</p>
				<pre>
				
				
				
				
				
				</pre>	
			</p>
		</div>
		
		
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="indexright">
				<h2>方法</h2>
				
				<p><br>
				網頁整體是圍繞在HTML、CSS與PHP的架構上，當然除了這三個語法外還搭配了JavaScript來完成一些不太容易實現的部分，
				值得一提的是這個網頁是有登入機制的，主要的目的是幫助使用者紀錄自己學習進程到了哪一個部分，並且使用測驗與遊戲的功能，
				沒有登入的話就單純是能觀看學習頁面進行練習，沒有進度與測驗的部分。
				</p>
				<p>在教學網頁中我們使用兩欄式的頁面，左手邊讓使用者閱讀大略概念 右手邊給使用者實作，目的是能夠讓使用者在觀看完左手邊的教學後能馬上在右手邊練習，
				在實作的部分為了能夠讓初學者也能夠先了解架構，我們設計先寫好部分程式碼，並且在關鍵的幾個地方挖空格讓使用者試著自己手動填入指令，
				如此可以使使用者有循序漸進填入程式碼的感覺，同時我們利用上述的登入部分可以控管學習進度，用進度條的方式然告知使用者目前學習到的階段為何，
				下一次進到頁面時可以從上一次的進度繼續閱讀與練習。
				</p>
				<p>
				在測驗的部分我們依樣是用兩欄式的方式呈現，左手邊是題目部分，右手邊是作答區，必須要登入才能使用，目的是為了要記錄使用者答對了哪些題目。
				針對題目部分我們有難易之分，答對難易度較低的題目頁面會隨機導到難易度較高的題目，而答錯則會跳到簡單的題目位置，同時我們會紀錄曾經答對過哪些題目並在頁面上
				以小圖示標記，已經答對過的題目不會因為之後亂答或不小心輸入錯而改變標記。
				遊戲的部分則是我們應用這三種語法相關的概念來製作，遊戲簡單但能讓使用者在玩的過程中，同時思考一些程式的概念，達到邊玩邊學的目標。
				<p>
			</li>
			
		</ul>
		
	</div>
</div>
<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>
