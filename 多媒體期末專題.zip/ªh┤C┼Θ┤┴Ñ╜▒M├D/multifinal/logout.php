<?php
	session_start();
	session_destroy();
	echo '<script language="javascript"> alert("已成功登出");</script>';
	header("refresh:0; url=homepage.php");
?>