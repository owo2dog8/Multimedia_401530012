<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->
<?php
echo'<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>';
session_start();
if(isset($_SESSION['user'])){
		require_once("connMysql.php");
		$tick = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
		$ticktick = mysql_query($tick);
		$row = mysql_fetch_array($ticktick);
}
else{}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>HoPe for Coding</title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="phppage.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="default.css">
<link href="ProgressBarWars.css" rel="stylesheet" />

<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="js/ProgressBarWars.js"></script>
<style type="text/css">
	.progress{
		margin-top: 30px;
	}
</style>

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li class="current_page_item"><a href="phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li><a href="testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>PHP教學區</h1>
			<div class="progress" id="vaderTime"></div>
			<?php
			if(isset($_SESSION['user'])){
			?>
			<style>
				#onecolumnfirst 
				{
					padding-top: 0px
				}
				ul.style1 
				{
   					
  					padding: 8em 0em 0em 0em;
				}
			</style>
			 <script>
			 var num = <?php echo $row[7] ?>;
			$("#vaderTime").ProgressBarWars({porcentaje:num,estilo:"vader",tiempo:1000});
					
		  </script>
		  <input type="button" class="button2" value="更新個人進度" onClick="window.location.reload()">
			<?php }?>
	    </div>

	    <div id="onecolumnfirst">
			<div class="title ">
				<h2>輸出與變數</h2>
			</div>
			<p >
				PHP的第一步，在網頁上印出你想顯示的字串<br>	
			</p>
			<?php
				echo "我的第一個PHP程式</br>";
			?>
			<P>
			    <br>
				<strong>&lt;?php<br></strong>
			    <strong>echo "我的第一個PHP程式&lt;/br&gt"</strong><br>
				<strong>?&gt<br></strong>
				這一段程式碼中，利用&lt;?php  與 ?&gt 包覆php語法，再利用echo 指令來讓網頁印出在" " 之中的字串，
				並且利用&lt;/br&gt 來做換行，如此就能產生上述結果<br>
			</p>
			<p>
			在PHP中 變數是用$來做開頭，有賦值的意思，所以我們能把上面的程式寫成這個樣子，也會有一樣的結果<br>
			<strong>&lt;?php<br></strong>
			<strong>$textmessage = "我的第一個PHP程式";</strong><br>
			<strong>echo $textmessage;<br></strong>
			<strong>?&gt<br></strong>
			而當你在PHP中為一個變數賦值，會依據你給的變數內容來決定該變數的型態，比如說:<br>
			<strong>$example = 1</strong><br>
			<strong>$example = 1.0</strong><br>
			<strong>$example = True</strong><br>
			<strong>$example = Null</strong><br>
			你給整數值那它就是整數型態，浮點數它就會是浮點數型態，依此類推<br>
			而這一行指令是輸出變數$a的資料型態與內容<br>
			<strong>var_dump($a); </strong>
			</p>
		</div>

		<div id="onecolumn">
			<div class="title">
				<h2>運算子</h2>
			</div>
			<p >
			PHP中有常用的運算子有以下幾種:<br> 算數運算子、字串運算子、比較運算子和邏輯運算子<br><br>
			首先是算數運算子，這種運算子是比較直觀的數學運算。<br>
			只要變數的型態是數字，就能使用算數運算子來處理。<br>
			<strong>&lt;?php <br>
			$a = 10; <br>
			echo $a+1;  //執行的結果會輸出「11」 <br>
			echo $a-1;  //執行的結果會輸出「9」 <br>
			echo $a*2;  //執行的結果會輸出「20」 <br>
			echo $a/2;  //執行的結果會輸出「5」  <br>
			echo $a%3;  //%代表mod 執行的結果會輸出「1」，10除以3餘1 <br>
			?&gt </strong><br>
			
			字串運算子 "." 能將兩個字串直接串連起來<br>
			<strong>&lt;?php <br>
			$a = "寫程式真是"; <br>
			$b = "太棒了！"; <br>
			$a = $a.$b;  //$a與$b的內容被串接後存入了變數$a中 <br>
			echo $a;  //執行的結果會輸出「寫程式真是太棒了!」 <br>
             ?&gt </strong><br>

			 比較運算子包括：等於（==）、不等於（!=）、大於（>）、小於（<）、大於等於（>=）、小於等於（<=）<br>
			 主要用來判斷條件是否成立，若成立會回傳True，反之則回傳False。<br>
			 
			 <strong>&lt;?php <br>
				$a = 1>2;  //將1>2的比較結果指定給變數$a <br>
				var_dump($a);  //輸出變數$a的資料型態與內容<br> 
				$b = 1<2;  //將1<2的比較結果指定給變數$b <br>
				var_dump($b);  //輸出變數$b的資料型態與內容 <br>
			 ?&gt </strong><br>
			 
			 邏輯運算子包括:!(非)、&&(and)、||(or)、xor(兩者僅有一個為真)<br> 
			 
			 <strong>&lt;?php <br>
			$a = (1>2 || 3<4);<br>
			//or兩端只要其中一個條件成立就會返回true。反之，返回false。<br>
			$b = (1>2 && 3<4);<br>
			//and兩端條件皆成立才會返回true。反之，返回false。<br> 
			$c = !(1>2);<br> 
			//!表示「非」，1>2不成立會返回false，非false的結果，變成true。<br> 
			$d= (1>2 xor 3<4);<br>
			//xor要兩端條件只有一個成立才會回傳true<br>
			?&gt </strong>
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>條件判斷</h2>
			</div>
			<p >
			在條件判斷這個部分，可以用條件來控制程式在不同狀況下做不同動作，<br>
			有if else 與 switch 等用法<br><br>
            if 的部分寫法如下:<br>
			<strong>&lt;?php <br>
			if(2>1)<br>
				&nbsp;&nbsp;echo "HAHA";<br>
			else<br>
				&nbsp;&nbsp;echo"YOHO";<br>
			?&gt </strong><br>
			如果括弧內的條件成立就會執行底下的程式碼，<br>
			反之就會執行else下的程式碼，所以上面這個程式會印出HAHA<br>
			當然，日後寫程式時也可能有很多個if else 或if裡還有if 來做條件判斷的控制<br><br>
			switch 的部分寫法如下<br>
			
			<strong>&lt;?php <br>
			switch($i){<br>
　			case 1:　//$i值等於1的情況，特別注意：1的後面是冒號「:」<br>
　　		&nbsp;&nbsp;子句一;//如果i值為1會執行<br>
　　		&nbsp;&nbsp;break;　//每一個case的結束，一定要加上break;<br>
　			case 2:　//$i值等於2的情況<br>
　　		&nbsp;&nbsp;子句二;//如果i值為2會執行<br>
　　		&nbsp;&nbsp;break;<br>
　			case 3:　//$i值等於3的情況<br>
　　		&nbsp;&nbsp;子句三;//如果i值為3會執行<br>
　　		&nbsp;&nbsp;break;<br>
　			default:　//$i值為其他的情況<br>
　　		&nbsp;&nbsp;子句四;//如果i值為其他情況會執行<br>
　　		&nbsp;&nbsp;break;<br>
			}<br>
			?&gt </strong><br>
            
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>迴圈</h2>
			</div>
			<p >
			迴圈（loop）是一種用來反覆執行某工作的工具<br>
			PHP程式可使用簡單的迴圈有 while 與 for
		    
			while迴圈就是只要條件成立就會不斷執行子句的指令，寫法如下:<br>
			
			<strong>&lt;?php <br>
			while(條件){<br>
			&nbsp;&nbsp;子句;<br>
			}<br>
			?&gt </strong><br><br>
			
			<strong>&lt;?php <br>
			$a=10;<br>
			while($a>0){<br>
			&nbsp;&nbsp;&nbsp;&nbsp;echo "$a";<br>
			&nbsp;&nbsp;&nbsp;&nbsp;$a--;//a=a-1<br>
			}<br>
			?&gt </strong><br>
			像上述就會從10開始印到1為止，因為每印一次a之後a都會-1，直到a不符合a>0這個條件為止<br><br>
			
			另一種常見的迴圈是for迴圈，這一種迴圈的寫法如下:<br>
			<strong>&lt;?php <br>
			for(開始變數;執行條件;變動條件){<br>
　			&nbsp;&nbsp;echo $c."<br>";
			}<br>
			?&gt </strong><br>
			開始變數只要符合執行條件就會執行for裡面的程式碼，並且每執行一次就會去執行一次變動條件
			我們用一個範例來說明比較容易理解<br><br>
			
			<strong>&lt;?php <br>
			for($i=10;&nbsp;&nbsp;$i>0;&nbsp;&nbsp;$i--){<br>
			&nbsp;&nbsp;&nbsp;&nbsp;echo "$i";<br>
			}<br>
			?&gt </strong><br>
			
			像這樣的執行結果會是從10印到1，開始條件i=10，符合i>0這個執行條件，進到迴圈中印出i，
			執行變動條件i-1後再檢查是否仍符合執行條件若符合就繼續執行回圈內指令，直到不符合為止<br><br>
			
			當然今天若你想要中斷迴圈進行，可以使用break這個指令，在迴圈執行的過程中，如果遇到break會跳出迴圈。，如下面這個例子<br><br>
			
			<strong>&lt;?php <br>
			$a=1; <br>
			while($a>0){ <br>
			echo $a."<br>"; <br>
			$a++;  //$a=$a+1;的縮寫，while每執行一圈$a就加１<br> 
			if($a>5) break;  //當a>5就跳出迴圈 <br>
			} <br>
			?&gt </strong><br>
			
			</p>
		</div>
		<div id="onecolumn">
			<div class="title">
				<h2>陣列</h2>
			</div>
			<p >
		    當我們建置網頁要存好多筆性質相近或有關聯的資料時，會選擇用陣列座儲存的動作，首先是一般宣告陣列的方法<br>
			<strong>&lt;?php <br> 
			$student[1]="魯夫"; <br>
			$student[2]="索隆"; <br>
			$student[3]="娜美"; <br>
			$student[4]="騙人布"; <br>
			$student[5]="香吉士"; <br>
			?&gt </strong><br>
			還有另一種宣告的方式<br>
			<strong>&lt;?php <br> 
			$student=array(  //陣列的名稱叫$student <br>
			1=>"林小美", //依次指定陣列的元素 <br>
			2=>"王小明", <br>
			3=>"謝小琪", <br>
			4=>"陳小傑", <br>
			5=>"張小祥"; <br>
			?&gt </strong><br>
			
			當然在PHP中陣列的鍵不一定要使用數字，也可以像這樣：<br>

            <strong>&lt;?php <br>
			$fruit=array( <br>
			"apple"=>"蘋果", <br>
			"strawberry"=>"草莓", <br>
			"orange"=>"柳橙"); <br>
			?&gt </strong><br>
			
			
			當今天我們需要用到陣列裡所有的元素，但不知道共有多少元素時，就能使用陣列專用迴圈foreach來寫，寫法如下:<br>
			
			foreach(陣列名稱 as 鍵=>陣列成員內容){<br>
　			子句;<br>
			}<br>
			以一個實際的例子，今天我們要把學生名冊列出來，就能使用這個方法<br>
			
			<strong>&lt;?php <br>
			$student = array( <br>
			314=>"王小翔",114=>"簡小嘉",212=>"呂小毅",214=>"陳小佑",215=>"林小宏",<br>
			311=>"溫小豪",115=>"馬小九",313=>"蔡小文",111=>"金小萱",211=>"蘇小凱",<br>
			112=>"李小旭",315=>"許小寧",213=>"方小霞",312=>"許小平",113=>"洪小喜"); <br><br>

			foreach($student as $key=>$value){ <br>
			echo '$student['.$key."]：".$value."; <br>
			} <br>
			?&gt </strong><br>
			
			
			</p>
		</div>
		
		
		<div id="onecolumn">
			<div class="title">
				<h2>函數</h2>
			</div>
			<p >
			在我們了解到PHP程式的這麼多指令，基本的程式寫法之後，我們能利用自訂函數來創造一個我們自訂的功能，寫法如下<br>
			
			function 自訂函數的名稱(傳入的參數){<br>
　			子句;<br>
			}<br>
			我們舉幾個簡單的例子<br>
			範例一:<br>
			<strong>&lt;?php <br>
			function myname(){  //自訂函數名稱為 myname <br>
			echo "帥哥"; <br>
			} <br>
			myname();  //執行 myname函數 <br>
			?&gt </strong><br> 
			執行myname()函數會印出帥哥的字串<br>
			
			範例二:<br>
			<strong>&lt;?php <br>
			function friend($name){  //自訂函數名稱為friend <br>
			if($name==""){  //如果沒有參數 <br>
			echo "so sad"; <br>
			}else{  //如果有參數 <br>
			echo $name; <br>
			} <br>
			} <br>
			friend($name);  //執行自訂函數friend，引數為$name <br>
			?&gt </strong><br>  
			傳入name參數到friend這個函數裡，判斷後決定輸出，當然傳入的參數也可以是預設的或是陣列<br>
			
			範例三:<br>
			<strong>&lt;?php <br> 
			function dress($who){  //換裝的函數 <br>
			$who = "換裝、化妝完畢的".$who; <br>
			return $who; <br>
			} <br>
			$actor = "女主角"; <br>
			$actor = dress($actor);  //換裝，把回傳值存入變數$actor。<br> 
			echo $actor; <br>
			?&gt </strong><br>
			在函數處理完之後能夠有回傳值並且存到變數之中，範例中是把who變數傳到dress()這個函數之中，再回傳換裝、化妝完畢的$who，再存到$actor變數中取代女主角<br>
			
			</p>
		</div>
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right1">
				<h3>測試自己的程式碼～</h3>
				<p>
				在$test 函數後面輸入想印的字串<br>
				並且讓echo 輸出$test 的變數內容<br>
				<form name="form1" method="post" action="phppage.php#right1">
				 <p>$test="<input type="text" name="T1" size="20">";</p>
				 <p>echo&nbsp <input type="text" name="T2" size="20">;</p>
				 <button  input type="submit" class=button type="button" id="button1" name="button1">結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user']) && isset($_POST['button1']))
{
$update1 = 'UPDATE php SET php_1="1" WHERE account = "'.$_SESSION['account'].'";';
$up1 = mysql_query($update1);

$query_RecProduct1 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product1 = mysql_query($query_RecProduct1);
$row1 = mysql_fetch_array($Product1);

$sum1=$row1[1]+$row1[2]+$row1[3]+$row1[4]+$row1[5]+$row1[6];

$result1=round($sum1/6*100);
$query1 = 'UPDATE php SET progress="'.$result1.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct1 = mysql_query($query1);
}
?>
				</form>
		
    			</p>
    			<h3>結果：</h3>
				<p>
				
				<?php
				if( !isset($_POST['T1']) && !isset($_POST['T2']) ){
					$_POST['T1']="";
					$_POST['T2']="";
				}
					$get_value1=$_POST['T1'];
					$get_value2=$_POST['T2'];
				
				if($get_value2=="$"."test")
				   echo $get_value1;
			    else
				   echo "請輸入正確變數名稱才能顯示喔";
			    
                ?>
				
				 
				</p><br>
			</li>
			
		</ul>
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right2">
				<h3>運算子～</h3>
				<p>
				1.宣告$a 的變數內容<br>
				2.在echo 後面輸入想進行的運算<br>
				3.利用字串運算子串接兩個字串<br>
				4.輸入比較運算子觀看結果<br>
				
				<form name="form2" method="post" action="phppage.php#right2">
				 <p>$a= <input type="text" name="number1" size="20">;</p>
				 <p>echo&nbsp $a<input type="text" name="number2" size="20">;</p>
				 <p>echo "我真的"<input type="text" name="number3" size="1">"有點會"</p>
				 <p>$b = 1<input type="text" name="number4" size="2">2;</p>
				 <p> var_dump($b)</p>
				
				 <button  input type="submit" class=button type="button" id="button1" name="button2"  >結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user'])&& isset($_POST['button2']))
{
$update2 = 'UPDATE php SET php_2="1" WHERE account = "'.$_SESSION['account'].'";';
$up2 = mysql_query($update2);

$query_RecProduct2 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product2 = mysql_query($query_RecProduct2);
$row2 = mysql_fetch_array($Product2);

$sum2=$row2[1]+$row2[2]+$row2[3]+$row2[4]+$row2[5]+$row2[6];

$result2=round($sum2/6*100);
$query2 = 'UPDATE php SET progress="'.$result2.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct2 = mysql_query($query2);
}
?>
				</form>

    			</p>
    			<h3>結果：</h3><p>
				<?php
				if(!isset($_POST['number1']) && !isset($_POST['number2']) && !isset($_POST['number3']) && !isset($_POST['number4'])){
				$_POST['number1']="";
				$_POST['number2']="";
				$_POST['number3']="";
				$_POST['number4']="";
				}
				$get_value3=$_POST['number1'];
				$get_value4=$_POST['number2'];
				$get_value5=$_POST['number3'];
				$get_value6=$_POST['number4'];
				
				
				//echo $get_value3+1;
				//echo $get_value4;
				if($get_value4!=""){
				$mark =substr($get_value4,0,1);
				//echo $mark;
				switch($mark)
				{
                  case "+" :
				  echo $get_value3+(int)(substr($get_value4,1,strlen( $get_value4 )));
				  echo '<br>';
					break;
				  case "-" :
				  echo $get_value3-(int)(substr($get_value4,1,strlen( $get_value4 )));
				  echo '<br>';
					break;
				  case "*" :
				  echo $get_value3*(int)(substr($get_value4,1,strlen( $get_value4 )));
				  echo '<br>';
					break;
				  case "/" :
				  echo $get_value3/(int)(substr($get_value4,1,strlen( $get_value4 )));
				  echo '<br>';
					break;
                  case "%" :	
				  echo $get_value3%(int)(substr($get_value4,1,strlen( $get_value4 )));
				  echo '<br>';
					break;
				}
				}
				else{
					echo "試著給正確的指令<br>";
					//echo $get_value3;
					
				}
				
				if($get_value5=="."){
					echo "我真的有點會";
					echo "<br>";
				}
				
				
				switch($get_value6)
				{
				case "==":
					$b= 1==2;
					var_dump($b);
					break;
				case "!=":
					$b= 1!=2;
					var_dump($b);
					break;
				case ">":
					$b= 1>2;
					var_dump($b);
					break;
				case "<":
					$b= 1<2;
					var_dump($b);
					break;
				case ">=":
					$b= 1>=2;
					var_dump($b);
					break;
				case "<=":
					$b= 1<=2;
					var_dump($b);
					break;	
				}
				echo '<br>';
                ?>
				
				</p><br>
			</li>	
		</ul>
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right3">
				<h3>條件判斷～</h3>
				<p>
			    1.if 輸入條件<br>
				2.switch  輸入變數i 的值並看看結果<br>
				<form name="form1" method="post" action="phppage.php#right3">
				 <p>if( &nbsp <input type="text" name="judge1" size="20"> )&nbsp<br>
				    &nbsp&nbsp&nbsp echo&nbsp "對";<br>
				    else<br>
				    &nbsp&nbsp&nbsp echo&nbsp "錯";</p>
					
					
					<p>
						$i=<input type="text" name="judge2" size="20">;<br>
						switch($i){ <br>
						case 1:    <br>
						&nbsp&nbspecho "第一個"; <br>
						&nbsp&nbspbreak;     <br>
						case 2:    <br>
						&nbsp&nbspecho "第二個"; <br>
						&nbsp&nbspbreak;     <br>
						default:   <br>
						&nbsp&nbspecho "都不是"; <br>
						&nbsp&nbspbreak;     <br>
					  }            <br>
					</p>
				 <button  input type="submit" class=button type="button" id="button1" name="button3" >結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user'])&& isset($_POST['button3']))
{
$update3 = 'UPDATE php SET php_3="1" WHERE account = "'.$_SESSION['account'].'";';
$up3 = mysql_query($update3);

$query_RecProduct3 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product3 = mysql_query($query_RecProduct3);
$row3 = mysql_fetch_array($Product3);

$sum3=$row3[1]+$row3[2]+$row3[3]+$row3[4]+$row3[5]+$row3[6];

$result3=round($sum3/6*100);
$query3 = 'UPDATE php SET progress="'.$result3.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct3 = mysql_query($query3);
}
?>
				</form>
				
    			</p>
    			<h3>結果：</h3>
				<p>
				
				<?php
				if(!isset($_POST['judge1'])&&!isset($_POST['judge2'])){
					$_POST['judge1']="";
					$_POST['judge2']="";
				}
				$get_value7=$_POST['judge1'];
				$get_value8=$_POST['judge2'];
				
			
                ?>
				
				 
				</p><br>
			</li>
			
		</ul>
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right4">
				<h3>迴圈～</h3>
				<p>
				1.利用 WHILE 迴圈來完成程式碼<br>
				2.利用 FOR 迴圈 來完成印出<br>
				<form name="form1" method="post" action="phppage.php#right4">
				 <p>$i=10;<br>
				 <input type="text" name="while" size="1">($i>0){;<br>
				 $i--;<br>
				 echo $i;<br>
				 echo"&lt;br&gt";<br>
				 }<br>
				 </p>
				 <p><input type="while" name="for" size="1">($i=0;$i<5;$i++){<br>
				 echo $i;<br>
				 echo "&lt;br&gt"<br>
				 }<br>
				 
				 </p>
				 <button  input type="submit" class=button type="button" id="button1" name="button4" >結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user'])&& isset($_POST['button4']))
{
$update4 = 'UPDATE php SET php_4="1" WHERE account = "'.$_SESSION['account'].'";';
$up4 = mysql_query($update4);

$query_RecProduct4 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product4 = mysql_query($query_RecProduct4);
$row4 = mysql_fetch_array($Product4);

$sum4=$row4[1]+$row4[2]+$row4[3]+$row4[4]+$row4[5]+$row4[6];

$result4=round($sum4/6*100);
$query4 = 'UPDATE php SET progress="'.$result4.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct4 = mysql_query($query4);
}
?>
				</form>
				
    			</p>
    			<h3>結果：</h3>
				<p>
				
				<?php
				if(!isset($_POST['while'])&&!isset($_POST['for'])){
					$_POST['while']="";
					$_POST['for']="";
				}
					$get_value9=$_POST['while'];
					$get_value10=$_POST['for'];
				
				//echo $get_value9;
				//echo $get_value10;
				if($get_value9=="while")
				{
					$whiletest=10;
					while($whiletest>0)
					{
					$whiletest--;
					echo $whiletest;
					echo "<br>";
					}
				}
			    else
				   echo "請輸入正確指令<br>";
			   
			   if($get_value10=="for"){
				   for($i=10;  $i>0;  $i--){
				    echo "$i";
					echo "<br>";
				   }
			   }
				else
					echo "請輸入正確指令<br>";
			   
			    
                ?>
				
				 
				</p><br>
			</li>
			
		</ul>
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right5">
				<h3>陣列～</h3>
				<p>
				在陣列後面輸入想加入的陣列元素<br>
				並且讓foreach輸出陣列的所有元素<br>
				<form name="form1" method="post" action="phppage.php#right5">
				 <p>$student[1]="<input type="text" name="s1" size="10">";</p>
				 <p>$student[2]="<input type="text" name="s2" size="10">";</p>
				 <p>$student[3]="<input type="text" name="s3" size="10">";</p>
				 <p>foreach($student as $key=>$value){<br>
				 echo '$student['.$key."]：".$value<br>
				 }<br>				
			     </p>
				 <button  input type="submit" class=button type="button" id="button1" name="button5" >結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user'])&& isset($_POST['button5']))
{
$update5 = 'UPDATE php SET php_5="1" WHERE account = "'.$_SESSION['account'].'";';
$up5 = mysql_query($update5);

$query_RecProduct5 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product5 = mysql_query($query_RecProduct5);
$row5 = mysql_fetch_array($Product5);

$sum5=$row5[1]+$row5[2]+$row5[3]+$row5[4]+$row5[5]+$row5[6];

$result5=round($sum5/6*100);
$query5 = 'UPDATE php SET progress="'.$result5.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct5 = mysql_query($query5);
}
?>
				</form>
				
    			</p>
    			<h3>結果：</h3>
				<p>
				
				<?php
				if(!isset($_POST['s1']) && !isset($_POST['s2']) && !isset($_POST['s3']) ){
				$_POST['s1']="";
				$_POST['s2']="";
				$_POST['s3']="";
				}
				$get_value11=$_POST['s1'];
				$get_value12=$_POST['s2'];
				$get_value13=$_POST['s3'];
				
				if($get_value11!="" && $get_value12!="" && $get_value13!="")
				{
					$student[1]=$get_value11;
					$student[2]=$get_value12;
					$student[3]=$get_value13;
					
					foreach($student as $key=>$value){ 
					echo '$student['.$key."]：".$value; 
					} 
					
				}
			    else
				   echo "請輸入全部陣列元素才能顯示喔";
			    
                ?>
				
				 
				</p><br>
			</li>
			
		</ul>
		
	</div>
	<div id="sidebar">
		<ul class="style1">
			<li class="first" id="right6">
				<h3>函數～</h3>
				<p>
				1.輸入function讓showmyname()變成可使用的函數<br>
				2.輸入傳入的參數，讓函數輸出不一樣的結果<br>
				<form name="form1" method="post" action="phppage.php#right6">
				 <p><input type="text" name="function1" size="20">&nbsp&nbsp showmyname(){<br>
				 echo "PHP嫩芽";<br> 
				 }<br>
				 showmyname();<br>
				 </p>

				 
				 <button  input type="submit" class=button type="button" id="button1"name="button6" >結果呈現</button><br>
				 <?php

 if(isset($_SESSION['user'])&& isset($_POST['button6']))
{
$update6 = 'UPDATE php SET php_6="1" WHERE account = "'.$_SESSION['account'].'";';
$up6 = mysql_query($update6);

$query_RecProduct6 = 'SELECT * FROM php WHERE account = "'.$_SESSION['account'].'";';
$Product6 = mysql_query($query_RecProduct6);
$row6 = mysql_fetch_array($Product6);

$sum6=$row6[1]+$row6[2]+$row6[3]+$row6[4]+$row6[5]+$row6[6];

$result6=round($sum6/6*100);
$query6 = 'UPDATE php SET progress="'.$result6.'" WHERE account = "'.$_SESSION['account'].'";';
$RecProduct6 = mysql_query($query6);
}
?>
				</form>
				
    			</p>
    			<h3>結果：</h3>
				<p>
				
				<?php
				if(!isset($_POST['function1'])){
				$_POST['function1']="";
				}
				$get_value14=$_POST['function1'];
				
				if($get_value14=="function")
				   echo "PHP嫩芽";
			    else
				   echo "請輸入正確宣告方式喔";
			    
                ?>
				
				 
				</p><br>
			</li>
			
		</ul>
		
	</div>
	</div>

<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<?php
 if (isset($_SESSION['user'])) {
 ?>
	<a id="login" href="logout.php" >登出</a>
 <?php

 } else {
   ?>
	<a id="login" href="login.php" >登入</a>
   <?php
 }?>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>
