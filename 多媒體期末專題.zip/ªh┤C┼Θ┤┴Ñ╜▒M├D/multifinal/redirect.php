
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />


<?php
				if( !isset($_POST['T1']) && !isset($_POST['T2']) && !isset($_POST['T3']) ){
					$_POST['T1']="123456789";
					$_POST['T2']="123456789";
					$_POST['T3']="123456789";
				}
					$get_value1=$_POST['T1'];
					$get_value2=$_POST['T2'];
					$get_value3=$_POST['T3'];
		
				
				if(($get_value1=="123456789") && ($get_value2=="123456789") && ($get_value3=="123456789"))
				{
				}
				else if(($get_value1=="$"."a") && ($get_value2==">") && ($get_value3=="$"."i") )
				{
				?>
				<script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "�����s�~��!", "success")  
				});
				</script>
				<?php	
				//echo'<head><meta http-equiv="refresh" content="0 ; url=http://localhost:8081/multifinal/phppage.php#right2"></head>';
				}
				else
				{
				?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "�����s�~��!", "error")
				
				});
				</script>
			    <?php
				echo'<head><meta http-equiv="refresh" content="5 ; url=http://localhost:8081/multifinal/testpage.php#test1post"></head>';
				}
                ?>