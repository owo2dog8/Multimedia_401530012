
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>
<?php
session_start();
require_once("connMysql.php");
?>

<?php

				if( !isset($_POST['T1']) && !isset($_POST['T2']) && !isset($_POST['T3']) ){
					$_POST['T1']="123456789";
					$_POST['T2']="123456789";
					$_POST['T3']="123456789";
				}
					$get_value1=$_POST['T1'];
					$get_value2=$_POST['T2'];
					$get_value3=$_POST['T3'];
		
				
				if(($get_value1=="123456789") && ($get_value2=="123456789") && ($get_value3=="123456789"))
				{
				}
				else if(($get_value1=="$"."a") && ($get_value2==">") && ($get_value3=="$"."i") )
				{
				$correct1 = 'UPDATE test SET phptest_1="1" WHERE account = "'.$_SESSION['account'].'";';
				$right1 = mysql_query($correct1);
				?>
				<script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1�������", "success" )  
				});
				</script>
				<?php
               $rnum=rand(2,9);
               $position="testpage.php#test".$rnum."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
				else
				{
				?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1�������", "error")
				
				});
				</script>
			    <?php
				$rnum=9;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
                ?>
</html>