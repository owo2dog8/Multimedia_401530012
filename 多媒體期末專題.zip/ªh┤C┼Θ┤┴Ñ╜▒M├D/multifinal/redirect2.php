
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>
<?php
session_start();
require_once("connMysql.php");
?>

<?php

	
if(!isset ($_POST['result1']) && !isset ($_POST['result2']) && !isset ($_POST['result3']) &&  !isset ($_POST['result4']) &&
!isset ($_POST['result5']) &&   !isset ($_POST['result6']) &&  !isset ($_POST['result7']) &&  !isset ($_POST['result8'])){
	$_POST['result1']="haha";$_POST['result2']="haha";$_POST['result3']="haha";$_POST['result4']="haha";
	$_POST['result5']="haha";$_POST['result6']="haha";$_POST['result7']="haha";$_POST['result8']="haha";
}
$getvalue1=$_POST['result1'];$getvalue2=$_POST['result2'];$getvalue3=$_POST['result3'];$getvalue4=$_POST['result4'];
$getvalue5=$_POST['result5'];$getvalue6=$_POST['result6'];$getvalue7=$_POST['result7'];$getvalue8=$_POST['result8'];

if($getvalue1=="haha" && $getvalue2=="haha"&&$getvalue3=="haha"&&$getvalue4=="haha"&&
$getvalue5=="haha"&&$getvalue6=="haha"&&$getvalue7=="haha"&&$getvalue8=="haha"){
	
}
else if($getvalue1=="<h1>" && $getvalue2=="haha"&&$getvalue3=="haha"&&$getvalue4=="haha"&&
$getvalue5=="haha"&&$getvalue6=="haha"&&$getvalue7=="haha"&&$getvalue8=="haha"){
	
}

else if(preg_replace('/\s/','', $getvalue1)=='<h1>' && preg_replace('/\s/','', $getvalue2)=='</h1>' && preg_replace('/\s/','', $getvalue3)=='<h2>' && preg_replace('/\s/','', $getvalue4)=='</h2>' 
&& preg_replace('/\s/','', $getvalue5)=='<h3>' && preg_replace('/\s/','', $getvalue6)=='</h3>' && preg_replace('/\s/','', $getvalue7)=='<p>' && preg_replace('/\s/','', $getvalue8)=='</p>'){
				
				$correct2 = 'UPDATE test SET htmltest_2="1" WHERE account = "'.$_SESSION['account'].'";';
				$right2 = mysql_query($correct2);
				?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1秒後跳轉", "success" )  
				});
				</script><?php
				$rnum=rand(3,9);
               $position="testpage.php#test".$rnum."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
}

else{
	?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1秒後跳轉", "error")
				});
				</script>
			    <?php
				$rnum=1;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
                ?>
</html>