
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>

<?php
session_start();
require_once("connMysql.php");
?>

<?php		

				
    			if(!isset($_POST['zpvalue1']))$_POST['zpvalue1'] = "cantenterthis";
    			if(!isset($_POST['zvalue1']))$_POST['zvalue1'] = "cantenterthis";		
    			if(!isset($_POST['zpvalue2']))$_POST['zpvalue2'] = "cantenterthis";
    			if(!isset($_POST['zvalue2']))$_POST['zvalue2'] = "cantenterthis";		
    			if(!isset($_POST['zpvalue3']))$_POST['zpvalue3'] = "cantenterthis";
    			if(!isset($_POST['zvalue3']))$_POST['zvalue3'] = "cantenterthis";		
    			if(!isset($_POST['index1']))$_POST['index1'] = "cantenterthis";
    			if(!isset($_POST['index2']))$_POST['index2'] = "cantenterthis";		
    			if(!isset($_POST['index3']))$_POST['index3'] = "cantenterthis";
    				
    			if($_POST['index1']>$_POST['index3']&&$_POST['index3']>$_POST['index2'])
    			{
    				if($_POST['zpvalue1']=="margin-top" && $_POST['zvalue1']=="60px"  && $_POST['zpvalue2']=="margin-left" && $_POST['zvalue2']=="120px" && $_POST['zpvalue3']=="margin-left" && $_POST['zvalue3']=="40px"   ) 
    					{
							$correct3 = 'UPDATE test SET csstest_3="1" WHERE account = "'.$_SESSION['account'].'";';
							$right3 = mysql_query($correct3);?>
							<script type="text/javascript">
							$(function() {
				   
							swal("Good job!", "1秒後跳轉", "success") 

							});
							</script>
							<?php
               $rnum=rand(4,9);
               $position="testpage.php#test".$rnum."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}else
    					{?>
							<script type="text/javascript">
							$(function() {
							swal("Wrong answer!", "1秒後跳轉", "error")
							});
							</script>
							<?php
				$rnum=2;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}


    			}
    			else if ($_POST['index1']=="cantenterthis" || $_POST['index2']=="cantenterthis"  || $_POST['index3']=="cantenterthis" )
    			{

    			}
    			else
    					{?>
							<script type="text/javascript">
							$(function() {
							swal("Wrong answer!", "1秒後跳轉", "error")
							});
							</script>
							<?php
				$rnum=2;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}
    		?>