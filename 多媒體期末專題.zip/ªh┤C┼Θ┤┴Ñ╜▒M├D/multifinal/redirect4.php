
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>

<?php
session_start();
require_once("connMysql.php");
?>

<?php		
				
if(!isset ($_POST['result9']) && !isset ($_POST['result10']) && !isset ($_POST['result11']) &&  !isset ($_POST['result12']) &&
!isset ($_POST['result13']) &&   !isset ($_POST['result14']) &&  !isset ($_POST['result15']) &&  !isset ($_POST['result16']) &&
!isset ($_POST['result17']) &&   !isset ($_POST['result18']) &&  !isset ($_POST['result19']) &&  !isset ($_POST['result20']) &&
!isset ($_POST['result21']) &&   !isset ($_POST['result22']) &&  !isset ($_POST['result23']) &&  !isset ($_POST['result24']) &&
!isset ($_POST['result25']) &&   !isset ($_POST['result26']) &&  !isset ($_POST['result27']) &&  !isset ($_POST['result28']) &&
!isset ($_POST['result29']) &&   !isset ($_POST['result30']) &&  !isset ($_POST['result31']) &&  !isset ($_POST['result32']) &&
!isset ($_POST['result33']) &&   !isset ($_POST['result34'])){
	$_POST['result9']="haha";$_POST['result10']="haha";$_POST['result11']="haha";$_POST['result12']="haha";
	$_POST['result13']="haha";$_POST['result14']="haha";$_POST['result15']="haha";$_POST['result16']="haha";
	$_POST['result17']="haha";$_POST['result18']="haha";$_POST['result19']="haha";$_POST['result20']="haha";
	$_POST['result21']="haha";$_POST['result22']="haha";$_POST['result23']="haha";$_POST['result24']="haha";
	$_POST['result25']="haha";$_POST['result26']="haha";$_POST['result27']="haha";$_POST['result28']="haha";
	$_POST['result29']="haha";$_POST['result30']="haha";$_POST['result31']="haha";$_POST['result32']="haha";
	$_POST['result33']="haha";$_POST['result34']="haha";
}
$getvalue9=$_POST['result9']; $getvalue10=$_POST['result10']; $getvalue11=$_POST['result11']; $getvalue12=$_POST['result12']; 
$getvalue13=$_POST['result13']; $getvalue14=$_POST['result14']; $getvalue15=$_POST['result15']; $getvalue16=$_POST['result16']; 
$getvalue17=$_POST['result17']; $getvalue18=$_POST['result18']; $getvalue19=$_POST['result19']; $getvalue20=$_POST['result20']; 
$getvalue21=$_POST['result21']; $getvalue22=$_POST['result22']; $getvalue23=$_POST['result23']; $getvalue24=$_POST['result24']; 
$getvalue25=$_POST['result25']; $getvalue26=$_POST['result26']; $getvalue27=$_POST['result27']; $getvalue28=$_POST['result28']; 
$getvalue29=$_POST['result29']; $getvalue30=$_POST['result30']; $getvalue31=$_POST['result31']; $getvalue32=$_POST['result32']; 
$getvalue33=$_POST['result33']; $getvalue34=$_POST['result34']; 

if($getvalue9=="haha"&& $getvalue10=="haha"&& $getvalue11=="haha"&& $getvalue12=="haha"&& 
$getvalue13=="haha"&& $getvalue14=="haha"&& $getvalue15=="haha"&& $getvalue16=="haha"&& 
$getvalue17=="haha"&& $getvalue18=="haha"&& $getvalue19=="haha"&& $getvalue20=="haha"&& 
$getvalue21=="haha"&& $getvalue22=="haha"&& $getvalue23=="haha"&& $getvalue24=="haha"&& 
$getvalue25=="haha"&& $getvalue26=="haha"&& $getvalue27=="haha"&& $getvalue28=="haha"&& 
$getvalue29=="haha"&& $getvalue30=="haha"&& $getvalue31=="haha"&& $getvalue32=="haha"&& 
$getvalue33=="haha"&& $getvalue34=="haha" ){
	
}

else if(preg_replace('/\s/','', $getvalue9)=='option' && preg_replace('/\s/','', $getvalue10)=='台北' && preg_replace('/\s/','', $getvalue11)=='option' && preg_replace('/\s/','', $getvalue12)=='嘉義' 
&& preg_replace('/\s/','', $$getvalue13)=='option' && preg_replace('/\s/','', $getvalue14)=='高雄' && preg_replace('/\s/','', $getvalue15)=='checkbox' && preg_replace('/\s/','', $getvalue16)=='水果'
&& preg_replace('/\s/','', $getvalue17)=='checkbox' && preg_replace('/\s/','', $getvalue18)=='蔬菜' && preg_replace('/\s/','', $getvalue19)=='checkbox' && preg_replace('/\s/','', $getvalue20)=='麵包'
&& preg_replace('/\s/','', $getvalue21)=='checkbox' && preg_replace('/\s/','', $getvalue22)=='肉類' && preg_replace('/\s/','', $getvalue23)=='checkbox' && preg_replace('/\s/','', $getvalue24)=='餅乾'
&& preg_replace('/\s/','', $getvalue25)=='radio' && preg_replace('/\s/','', $getvalue26)=='大一' && preg_replace('/\s/','', $getvalue27)=='radio' && preg_replace('/\s/','', $getvalue28)=='大二'
&& preg_replace('/\s/','', $getvalue29)=='radio' && preg_replace('/\s/','', $getvalue30)=='大三' && preg_replace('/\s/','', $getvalue31)=='radio' && preg_replace('/\s/','', $getvalue32)=='大四'
&& preg_replace('/\s/','', $getvalue33)=='submit' && preg_replace('/\s/','', $getvalue34)=='reset'){
$correct4 = 'UPDATE test SET htmltest_4="1" WHERE account = "'.$_SESSION['account'].'";';
$right4 = mysql_query($correct4);
?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1秒後跳轉", "success") 

				});
				</script><?php
				$rnum=rand(5,9);
               $position="testpage.php#test".$rnum."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
}
else {
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
				</script><?php
				$rnum=3;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
}
	?>