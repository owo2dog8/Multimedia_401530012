
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>

<?php
session_start();
require_once("connMysql.php");
?>

<?php		
				
    			if(!isset($_POST['hovername']))$_POST['hovername'] = "cantenterthis";
				if(!isset($_POST['panswer6']))$_POST['panswer6'] =  "cantenterthis";
				if(!isset($_POST['vanswer6']))$_POST['vanswer6'] =  "cantenterthis";
    			if(!isset($_POST['panswer7']))$_POST['panswer7'] =  "cantenterthis";
    			if(!isset($_POST['vanswer7']))$_POST['vanswer7'] =  "cantenterthis";
    			if(!isset($_POST['panswer8']))$_POST['panswer8'] = "cantenterthis";
    			if(!isset($_POST['vanswer8']))$_POST['vanswer8'] =  "cantenterthis";
    			if(!isset($_POST['panswer9']))$_POST['panswer9'] =  "cantenterthis";
    			if(!isset($_POST['vanswer9']))$_POST['vanswer9'] = "cantenterthis";
    			if($_POST['hovername']=="hover" )
    			{
    				if(($_POST['panswer6']=="border-style" && $_POST['vanswer6']=="solid" && $_POST['panswer7']=="color" && $_POST['vanswer7']=="#000000")||($_POST['panswer7']=="border-style" && $_POST['vanswer7']=="solid" && $_POST['panswer6']=="color" && $_POST['vanswer6']=="#000000") ) 
    				{
    					if(($_POST['panswer8']=="border-style" && $_POST['vanswer8']=="dotted" && $_POST['panswer9']=="color" && $_POST['vanswer9']=="#B08769")||($_POST['panswer9']=="border-style" && $_POST['vanswer9']=="dotted" && $_POST['panswer8']=="color" && $_POST['vanswer8']=="#B08769") ) 
    					{
							$correct5 = 'UPDATE test SET csstest_5="1" WHERE account = "'.$_SESSION['account'].'";';
							$right5 = mysql_query($correct5);
							?>
							<script type="text/javascript">
							$(function() {
				   
							swal("Good job!", "1秒後跳轉", "success") 

							});
							</script>
							<?php
				$rnum=rand(6,9);
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}else
    					{?>
							<script type="text/javascript">
							$(function() {
							swal("Wrong answer!", "1秒後跳轉", "error")
							});
							</script>
							<?php
				rnum=4;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}

    				}else
    					{?>
							<script type="text/javascript">
							$(function() {
							swal("Wrong answer!", "1秒後跳轉", "error")
							});
							</script>
							<?php
					$rnum=4;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}

    			}else if ($_POST['hovername']=="cantenterthis" )
    			{

    			}
    			else
    					{?>
							<script type="text/javascript">
							$(function() {
							swal("Wrong answer!", "1秒後跳轉", "error")
							});
							</script>
							<?php
					$rnum=4;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    					}

    	
    		?>