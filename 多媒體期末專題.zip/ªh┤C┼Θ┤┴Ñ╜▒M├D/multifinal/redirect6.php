<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>

<?php
session_start();
require_once("connMysql.php");
?>

<?php
				
				if( !isset($_POST['T7']) && !isset($_POST['T8']) && !isset($_POST['T9']) ){
					$_POST['T7']="123456789";
					$_POST['T8']="123456789";
					$_POST['T9']="123456789";
				}
					$get_value1=$_POST['T7'];
					$get_value2=$_POST['T8'];
					$get_value3=$_POST['T9'];
				
                if(($get_value1=="123456789") && ($get_value2=="123456789") && ($get_value3=="123456789"))
				{
				}
				else if(($get_value1=="$"."student") && ($get_value2=="$"."key") && ($get_value3=="$"."value") )
				{
				$correct6 = 'UPDATE test SET phptest_6="1" WHERE account = "'.$_SESSION['account'].'";';
				$right6 = mysql_query($correct6);
				?>
				<script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1秒後跳轉", "success") 

				});
				</script>
				<?php
					$rnum=rand(7,9);
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
				else
				{
				?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1秒後跳轉", "error")
				});
				</script>
			    <?php
				$rnum=5;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
                ?>