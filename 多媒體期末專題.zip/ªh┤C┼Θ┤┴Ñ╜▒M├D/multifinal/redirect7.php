<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>

<?php
session_start();
require_once("connMysql.php");
?>

<?php		
				
    			if(!isset($_POST['idname']))$_POST['idname'] = "cantenterthis";
    			if(!isset($_POST['panswer1']))$_POST['panswer1'] = "cantenterthis";	
    			if(!isset($_POST['vanswer1']))$_POST['vanswer1'] = "cantenterthis";
    			if(!isset($_POST['panswer2']))$_POST['panswer2'] = "cantenterthis";	
    			if(!isset($_POST['vanswer2']))$_POST['vanswer2'] = "cantenterthis";
    			if(!isset($_POST['panswer3']))$_POST['panswer3'] = "cantenterthis";	
    			if(!isset($_POST['vanswer3']))$_POST['vanswer3'] = "cantenterthis";
    			if(!isset($_POST['panswer4']))$_POST['panswer4'] = "cantenterthis";	
    			if(!isset($_POST['vanswer4']))$_POST['vanswer4'] = "cantenterthis";
    			if(!isset($_POST['panswer5']))$_POST['panswer5'] = "cantenterthis";	
    			if(!isset($_POST['vanswer5']))$_POST['vanswer5'] = "cantenterthis";
    			$Pans[1]=$_POST['panswer1'];
    			$Pans[2]=$_POST['panswer2'];
    			$Pans[3]=$_POST['panswer3'];
    			$Pans[4]=$_POST['panswer4'];
    			$Pans[5]=$_POST['panswer5'];

    			$Vans[1]=$_POST['vanswer1'];
    			$Vans[2]=$_POST['vanswer2'];
    			$Vans[3]=$_POST['vanswer3'];
    			$Vans[4]=$_POST['vanswer4'];
    			$Vans[5]=$_POST['vanswer5'];

    	
    			if($_POST['idname']=="#mybutton")
    			{
    				for($i=1;$i<=5;$i++)
    				{
    				
    				if($Pans[$i]=="width" && $Vans[$i]=="80px")
    				{
    					for($i=1;$i<=5;$i++)

    					if($Pans[$i]=="height" && $Vans[$i]=="45px" )
    					{
							for($i=1;$i<=5;$i++)

    						if($Pans[$i]=="border-radius" && $Vans[$i]=="10px" )
    						{
								for($i=1;$i<=5;$i++)

    							if($Pans[$i]=="color" && $Vans[$i]=="#FFFFFF" )
    							{
							        for($i=1;$i<=5;$i++)

    								if($Pans[$i]=="background-color" && $Vans[$i]=="#B08769" )
    								{
									$correct7 = 'UPDATE test SET csstest_7="1" WHERE account = "'.$_SESSION['account'].'";';
									$right7 = mysql_query($correct7);
    									
    									?>


				<script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1秒後跳轉", "success") 

				});
				</script>

				<?php
				break;
				$rnum=rand(8,9);
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
				}
									else {
    									?>	

									<script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
									</script>
									<?php	
									$rnum=6;
									$position="testpage.php#test".$rnum."post";
									echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
									}
							
									}else {
    									?>	

									<script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
									</script>
									<?php	
									$rnum=6;
									$position="testpage.php#test".$rnum."post";
									echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
									}
								}else {
    									?>	

									<script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
									</script>
									<?php	
									$rnum=6;
									$position="testpage.php#test".$rnum."post";
									echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
									}
							}else {
    									?>	

									<script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
									</script>
									<?php	
									$rnum=6;
									$position="testpage.php#test".$rnum."post";
									echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
									}

						}else {
    									?>	

									<script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
									</script>
									<?php	
									$rnum=6;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
									}

						
					}

    				
    			}else if( $_POST['idname']=="cantenterthis" )
    			{
    			
    			}
					
    			else if( $_POST['idname']==' ' || $_POST['panswer1']==' ' || $_POST['panswer2']==' ' || $_POST['panswer3']==' '  || $_POST['panswer4']==' '  && $_POST['panswer5']==' '  || $_POST['vanswer1']==' '  || $_POST['vanswer2']==' '  || $_POST['vanswer3']==' '  || $_POST['vanswer4']==' '  || $_POST['vanswer5']==' ')
    			{
    			?>	

				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1秒後跳轉", "error")
				});
				</script>
				<?php
				$rnum=6;
               $position="htestpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';				
    			}
    			else{
			   ?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1秒後跳轉", "error")
				});
				</script><?php	
				$rnum=6;
               $position="testpage.php#test".$rnum."post";
			   echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
    			}?>