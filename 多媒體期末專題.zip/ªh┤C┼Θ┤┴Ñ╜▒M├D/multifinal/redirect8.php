<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />
</head>
<?php
session_start();
require_once("connMysql.php");
?>

<?php
if(!isset ($_POST['result35']) && !isset ($_POST['result36']) && !isset ($_POST['result37']) &&  !isset ($_POST['result38']) &&
!isset ($_POST['result39']) &&   !isset ($_POST['result40']) &&  !isset ($_POST['result41'])){
	$_POST['result35']="haha" ; $_POST['result36']="haha" ; $_POST['result37']="haha" ; $_POST['result38']="haha" ; 
	$_POST['result39']="haha" ; $_POST['result40']="haha" ; $_POST['result41']="haha" ; 
}
$getvalue35=$_POST['result35'] ; $getvalue36=$_POST['result36'] ; $getvalue37=$_POST['result37'] ; $getvalue38=$_POST['result38'] ; 
$getvalue39=$_POST['result39'] ; $getvalue40=$_POST['result40'] ; $getvalue41=$_POST['result41'] ; 

if($getvalue35=="haha" && $getvalue36=="haha" && $getvalue37=="haha" && $getvalue38=="haha" && 
$getvalue39=="haha" && $getvalue40=="haha" && $getvalue41=="haha"){
	
}

else if(preg_replace('/\s/','', $getvalue35)=='href' && preg_replace('/\s/','', $getvalue36)=='http://www.ccu.edu.tw' && preg_replace('/\s/','', $getvalue37)=='images/img/cartoon/longpikachu.jpg'
 && ((preg_replace('/\s/','', $getvalue38)=='width' && preg_replace('/\s/','', $getvalue40)=='height') || (preg_replace('/\s/','', $getvalue38)=='height' && preg_replace('/\s/','', $getvalue40)=='width'))){
	 if($getvalue39==$getvalue41){
		 $correct8 = 'UPDATE test SET htmltest_8="1" WHERE account = "'.$_SESSION['account'].'";';
		$right8 = mysql_query($correct8);
		 ?><script type="text/javascript">
				$(function() {
				   
				swal("Good job!", "1秒後跳轉", "success") 

				});
				</script><?php
				$rnum=9;
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
	 }
	 else if($getvalue39!=$getvalue41){
		 ?>
				<script type="text/javascript">
				$(function() {
				swal("Wrong answer!", "1秒後跳轉", "error")
				
				});
				</script>
			    <?php
				$rnum=7;
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
	 }
}
else if(preg_replace('/\s/','', $_POST['result35'])!='href' && preg_replace('/\s/','', $_POST['result36'])!='http://www.ccu.edu.tw' && preg_replace('/\s/','', $_POST['result37'])!='images/img/cartoon/longpikachu.jpg'
&& (preg_replace('/\s/','', $_POST['result38'])!='width' || preg_replace('/\s/','', $_POST['result38'])!='height') && (preg_replace('/\s/','', $_POST['result40'])!='width' || preg_replace('/\s/','', $_POST['result40'])!='height')){
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
				</script><?php
				$rnum=7;
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
}
else{
	?><script type="text/javascript">
									$(function() {
									swal("Wrong answer!", "1秒後跳轉", "error")
									});
				</script><?php
				$rnum=7;
               $position="testpage.php#test"."$rnum"."post";			   
				echo'<head><meta http-equiv="refresh" content="1 ; url='.$position.'"></head>';
}?>