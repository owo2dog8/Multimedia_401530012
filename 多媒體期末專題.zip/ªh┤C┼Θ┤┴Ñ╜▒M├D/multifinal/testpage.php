<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Mongoose 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130920

-->

<?php
session_start();

if(isset($_SESSION['account'])){
       }		
else{
		echo'<head><meta http-equiv="refresh" content="0 ; url=http://localhost:8081/multifinal/login.php"></head>';
	}
		
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script src="sweetalert-master/dist/sweetalert.min.js" language="javascript"></script>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="csspage.css" rel="stylesheet" type="text/css" media="all" />
<link href="sweetalert-master/dist/sweetalert.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->
<script type="text/javascript">
	$(function(){
		
	    $("#gotop").click(function(){
	        jQuery("html,body").animate({
	            scrollTop: 0
	        }, 1000);
	    });
	
	    $(window).scroll(function() {
	    	if ( $(this).scrollTop() > 170){
	             $('#login').stop().fadeOut("fast");
	        } else {
	        	$('#login').fadeIn("fast");
	      	}

	        if ( $(this).scrollTop() > 300){
	            $('#gotop').fadeIn("fast");
	        } else {
	            $('#gotop').stop().fadeOut("fast");
	        }
	    });
	});
	</script>

</head>
<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><a href="http://localhost:8081/multifinal/homepage.php"> <strong>H</strong>o<strong>p</strong>e for <strong>C</strong>oding</a></h1>
		<h2><a href="http://localhost:8081/multifinal/homepage.php">HTML PHP  CSS</a></h2>
	</div>
	<div id="menu">
		<ul>
			<li ><a href="http://localhost:8081/multifinal/index.php" accesskey="1" title="">網站介紹</a></li>
			<li><a href="http://localhost:8081/multifinal/htmlpage.php" accesskey="2" title="">HTML教學 </a></li>
			<li><a href="http://localhost:8081/multifinal/phppage.php" accesskey="4" title="">PHP教學</a></li>
			<li><a href="http://localhost:8081/multifinal/csspage.php" accesskey="3" title="">CSS教學</a></li>			
			<li class="current_page_item"><a href="http://localhost:8081/multifinal/testpage.php" accesskey="5" title="">遊戲＆測驗</a></li>
			<link href="testpage.css" rel="stylesheet" type="text/css" media="all" />
		</ul>
	</div>
</div></div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h1>測驗區</h1>
	    </div>
		<?php
		require_once("connMysql.php");
		$tick = 'SELECT * FROM test WHERE account = "'.$_SESSION['account'].'";';
		$ticktick = mysql_query($tick);
		$row = mysql_fetch_array($ticktick);
		//echo $row[0];
		?>
<!--題目開始-->
	    <div id="onecolumnfirst">
			<div class="title ">
				<h2><font color="#9766ac">PHP</font>
				<?php
				if($row[1]=='0'){
				}
				else if ($row[1]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：變數與迴圈                難度：1</pre><h3>
				
			</div>
			<p>
			請在右方空格內填入正確的程式碼，讓PHP程式能夠呈現正確的輸出    	
			</p><br>
			<p>
			<strong>這一題主要是利用變數、判斷式與簡單的for迴圈做結合<br></strong>
			</p><br>
			<p>
			範例輸出:<br>
			<?PHP
			$a=1;
			if($a>0)
			{
			echo "好想答對這一題";
			}
		    else
			 echo "不會好像也沒差";
		    
			echo "<br>";
		    
			for($i=0;$i<3;$i++){
				echo "加油!"."<br>";
			}
			echo "很重要所以說三遍";
			?>
			<pre>
			
			
			
			
			
			
		
			</pre>
			</p>
		</div>
		<!--第一個題目-->
		
		
		<div id="onecolumn">
			<div class="title ">
				<h2><font color="#db4644">HTML</font>
								<?php
				if($row[2]=='0'){
				}
				else if ($row[2]=='1'){
				echo "<img src='images/tick.gif' width= 25px></h2>";}

				?>
				<h3><pre>題目:標題與段落                難度2</pre></h3>
			</div>
			<p>
			下面有幾個句子，請依照需求給予適當的標籤:<br>
			<strong>National Chung Cheng University</strong>是最重要的內容，<br>
			<strong>Management Information System</strong>是第二重要的內容，<br>
			<strong>About</strong>只比MIS少一點重要<br>
			<strong>MIS is a very intersting course!!</strong>這句話，<br>
			只是一個段落而已。<br>
			
			<strong>結果範例:</strong>
			
			<!DOCTYPE html>
			<html>
			<body bgcolor=white>
			<h1>National Chung Cheng University </h1>
			<h2>Management Information System </h2>
			<h3>About </h3>
			<p>MIS is a very interesting course!! </p></body></html>
			</p>
		</div>
		
		
		<!--第二個題目-->
		
		
		<div id="onecolumn">
			<div class="title">
				<h2><font color="#33a1d4">CSS</font> 
								<?php
				if($row[3]=='0'){
				}
				else if ($row[3]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：排好位置                難度：3</pre><h3>
			</div>
			<p >
				運用css元素時，常常會遇到疊在一起或邊距的種種問題！<br>	
				這裡請你嘗試利用我們所教過的語法來將下列左邊圖形排成像右邊那樣<br>
				<strong>請依造下列要求排好所有圖形</strong><br>
    			1.請將每隻pokemon放到指定的位置上<br>
    			2.皮卡丘在<strong>最前面</strong>，.皮卡丘距離頂部<strong>60px</strong><br>
    			3.傑尼龜<strong>在中間</strong>，傑尼龜距離左邊<strong>40px</strong><br>
    			4.火球鼠<strong>最後面</strong>火球鼠距離左邊<strong>120px</strong><br><br>
  
    			<img id="ball" src="images/ball.png" width="150px";>
    			<img id="pika" src="images/pika.png" width="130px";>
    			<img id="turtle" src="images/turtle.png" width="150px";>	
    			<img id="ball2" src="images/ball.png" width="150px";>
    			<img id="pika2" src="images/pika.png" width="130px";>
    			<img id="turtle2" src="images/turtle.png" width="150px";>				
    			<br><br><br><br><br><br>
			</p>
		</div>
		<!--第三個題目-->
		
			    <div id="onecolumn">
			<div class="title ">

			<h2><font color="#db4644">HTML</font> 
							<?php
				if($row[4]=='0'){
				}
				else if ($row[4]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
			<h3><pre>題目：表單                   難度4</pre></h3>

			</div>
			<p>
<pre>
請製作出一個含有下拉式選單、多選題和單選題的表單，
<strong>下拉式選單</strong>有3個選項，分別為&quot;台北&quot;、&quot;嘉義&quot;、&quot;高雄&quot;，
<strong>多選題</strong>有5個選項，分別為&quot;水果&quot;、&quot;蔬菜&quot;、&quot;麵包&quot;、&quot;肉類&quot;、&quot;餅乾&quot;，
<strong>單選題</strong>有4個選項，分別為&quot;大一&quot;、&quot;大二&quot;、&quot;大三&quot;、&quot;大四&quot;，
並且有<strong>送出</strong>跟<strong>清除</strong>按鈕。
<br>
<br>
<br>
<strong>結果範例:</strong>
</pre>
<!DOCTYPE html>
<html>
<body bgcolor=white>
你從哪裡來
<select>
 <option>台北
 <option>嘉義
 <option>高雄
</select>
<br>
你喜歡吃什麼
<input type=checkbox >水果
<input type=checkbox >蔬菜
<input type=checkbox >麵包
<input type=checkbox >肉類
<input type=checkbox >餅乾
<br>
你現在幾年級
<input type=radio >大一
<input type=radio >大二
<input type=radio >大三
<input type=radio >大四
<br>
<input type=submit value="送出">
<input type=reset value="清除">
</body>
</html>
<pre>




















</pre>
			</p>
		</div>	
		<!--第四個題目-->
		<div id="onecolumn">
			<div class="title">
				<h2><font color="#33a1d4">CSS</font> 
				<?php
				if($row[5]=='0'){
				}
				else if ($row[5]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：動態按鈕                 難度：5</pre><h3>
			</div>
			<p >
				網頁的動態按鈕變化一直是現在網頁不可或缺的元素！！<br>
				假設你今天要在頁面製作一個動態變化樣式的按鈕！<br>	
				他希望每次當他<strong>滑鼠滑過按鈕後都能給予按鈕變化</strong><br><br>
				<strong>提示：以下是小明希望得到的兩種變化</strong><br>
    			1.滑過會改變<strong>button字的顏色</strong><br>
    			<strong>色碼從#000000變成#B08769</strong><br>
    			2.滑過會讓<strong>實線變成虛線</strong><br><br><br><br>
    			
    	
			</p>
		</div>
		<!--第五個題目-->
		<div id="onecolumn">
			<div class="title">
				<h2><font color="#9766ac">PHP</font> 
				<?php
				if($row[6]=='0'){
				}
				else if ($row[6]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：陣列與迴圈               難度：6</pre><h3>
			</div>
			<p >
			請在右方空格內填入正確的程式碼，讓PHP程式能夠呈現正確的輸出
			</p><br>
			<p>
			<strong>利用陣列儲存元素，在利用迴圈的方法陣列元素印出來<br></strong>
			</p><br>
			範例輸出:<br>
			<?php 
			$student[1]="魯夫"; 
			$student[2]="索隆"; 
			$student[3]="娜美"; 
			$student[4]="騙人布"; 
			$student[5]="香吉士"; 
			
			foreach($student as $key=>$value){ 
			echo '$student['.$key."]：".$value."<br>"; 
			} 
			?> 
			
			<pre>
			
			</pre>
		</div>
		<!--第六個題目-->
			    <div id="onecolumn">
			<div class="title ">
				<h2 ><font color="#33a1d4">CSS</font> 
				<?php
				if($row[7]=='0'){
				}
				else if ($row[7]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：仿作按鈕                 難度：7</pre><h3>
			</div>
			<p >
    			請<strong>仿作</strong>跟下面一樣的button<br>
    			假設今天已經有一個80寬*45高的button在html宣告<br><br>
    			<strong>提示：</strong><br>
    			1.id叫做<strong>mybutton</strong><br>
    			2.button的<strong>底色為#B08769</strong>;字的顏色為<strong>#FFFFFF</strong>;<br>
    			3.四個角的弧度<strong>10px;</strong><br>

    			<strong>請用之前學過的語法來變化button的樣式</strong><br><br>
    			<button type="button" id="exbutton">按鈕範例</button><br><br>
			</p>
		</div>
		<!--第七個題目-->
		<div id="onecolumn">
			<div class="title ">
			<h2><font color="#db4644">HTML</font> 
			<?php
				if($row[8]=='0'){
				}
				else if ($row[8]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
			<h3><pre>題目：圖片與連結                   難度8</pre></h3>
			</div>
			<p>
<pre>
在我放置網頁的資料夾中，
有一個名為images的資料夾，
我有一個檔名為<strong>longpikachu</strong>的<strong>jpg</strong>檔案存放在
<strong>images</strong>資料夾中的<strong>img</strong>資料夾內的<strong>cartoon</strong>資料夾裡面，
但是那張圖片的比例太長了，
我希望你可以把圖片調整成<strong>正方形</strong>，
並且讓圖片能連結到<strong>中正大學首頁</strong>。

<strong>結果範例:</strong>
</pre>
<!DOCTYPE html>
<html>
<body>
<a href="http://www.ccu.edu.tw"><img src="images/pikachu.jpg"></a>
</body>
</html>
			</p>
		</div>	
		<!--第八個題目-->
		
		<div id="onecolumn">
			<div class="title">
				<h2><font color="#9766ac">PHP</font> 
				<?php
				if($row[9]=='0'){
				}
				else if ($row[9]=='1')
				echo "<img src='images/tick.gif' width= 25px></h2>";
				?>
				<h3><pre>題目：判斷搭配函數             難度：9</pre><h3>
			</div>
			<p >
			請在右方空格內填入正確的程式碼，讓PHP程式能夠呈現正確的輸出
			</p><br>
			<p>
			<strong>利用switch的方式決定正確輸出，再傳送到函數中取得最終正確的輸出<br></strong>
			</p><br>
			
			<p>
			範例輸出:<br>
			<?PHP
			$i=3;
			switch ($i){
			case 1:
			  $a="好像不是";
			  break;
			case 2:
			  $a="你確定";
			  break;
			case 3:
			  $a= "找出這個答案";
			  break;
			default:
			  $a= "小心這有問題";
			  break;
			}
			
			echo $a;
			echo "<br>";
			function show($a){
				if($a=="找出這個答案")
				echo "<br>";
				echo "真的是好棒棒";
			}
			show($a);
			?>
			
			</p>
			<pre>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			</pre>
		</div>
      <!--第九個題目-->	

		遊戲連結
	  <div>
	  <a href="http://localhost:8081/multifinal/cssgame.php" title="遊戲連結"><img src="images/icon_game.png" alt="遊戲連結" border="0" width="150px"></a>	  
	  <a href="http://localhost:8081/multifinal/game2.php" title="遊戲連結"><img src="images/icon_game2.png" alt="遊戲連結" border="0" width="150px"></a>
	  </div>	  
	</div>
	
	
	<div id="sidebar">
		<ul class="style1">
		
			<li class="first" id="test1post">
				<h3>答案實作區～</h3>
				<p>
				<form name="form1" method="post" action="redirect1.php">
			<p>
			&lt;?php <br>
			<input type="text" name="T1" size="2">=1; <br>
			if($a <input type="text" name="T2" size="1"> 0)
			{<br>
			echo "好想答對這一題";<br>
			}<br>
		    else<br>
			 echo "不會好像也沒差";<br>
		     echo "&lt;br?&gt";<br>
		    
			for($i=0;$i<3; <input type="text" name="T3" size="2"> ++){<br>
				echo "加油!"."&lt;br&gt";<br>
			}<br>
			echo "很重要所以說三遍";<br>
			?&gt <br>
			</p>
				
				<button type="submit" class="button1">測驗繳交</button><br>
				</form>
				
				
    			
    			</p>
    		</li>
			
			<li class="first" id="test2post">
				<h3>答案實作區～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8" action="redirect2.php">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
<input type="text" name="result1" id="result1" size="5"/> National Chung Cheng University <input type="text" name="result2" id="result2" size="5"/>

<input type="text" name="result3" id="result3" size="5"/> Management Information System <input type="text" name="result4" id="result4" size="5"/>

<input type="text" name="result5" id="result5" size="5"/> About <input type="text" name="result6" id="result6" size="5"/>

<input type="text" name="result7" id="result7" size="5"/> MIS is a very interesting course!! <input type="text" name="result8" id="result8" size="5"/>
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>

    			</p>
				
			</li>
			
			<li class="first" id="test3post">
			<form id="form1" action="redirect3.php" method="POST" novalidate="novalidate">
				<h3 id="sub3">答案實作區～</h3>
					<p >＃pikachu{<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zpvalue1" value="">：
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zvalue1" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;<br>	
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						z-index:
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="index1" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;}<br>				
						＃mouse{	<br>	
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zpvalue2" value="">：
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zvalue2" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						z-index:
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="index2" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;}<br>
						＃turtle{<br>					
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zpvalue3" value="">：
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="zvalue3" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
						z-index:
						<input class="form-control " type="text" autocomplete="off" placeholder="" name="index3" value=""> ;&nbsp;&nbsp;&nbsp;&nbsp;}<br>
    				</p>

    				<input type="submit" class="button1" id="zbutton" value="測驗繳交"><br><br>		
    		</form>			
    		
			</li>
			
		<li class="first" id="test4post">
			<h3>答案實作區～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8" action="redirect4.php">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;form&gt;
你從哪裡來
&lt;select&gt;
 &lt;<input type="text" name="result9" id="result9" size="5"/>&gt; <input type="text" name="result10" id="result10" size="5"/>
 
 &lt;<input type="text" name="result11" id="result11" size="5"/>&gt; <input type="text" name="result12" id="result12" size="5"/>
 
 &lt;<input type="text" name="result13" id="result13" size="5"/>&gt; <input type="text" name="result14" id="result14" size="5"/>
&lt;/select&gt;&lt;br&gt;
你喜歡吃什麼
&lt;input type=<input type="text" name="result15" id="result15" size="5"/>&gt; <input type="text" name="result16" id="result16" size="5"/>

&lt;input type=<input type="text" name="result17" id="result17" size="5"/>&gt; <input type="text" name="result18" id="result18" size="5"/>

&lt;input type=<input type="text" name="result19" id="result19" size="5"/>&gt; <input type="text" name="result20" id="result20" size="5"/>

&lt;input type=<input type="text" name="result21" id="result21" size="5"/>&gt; <input type="text" name="result22" id="result22" size="5"/>

&lt;input type=<input type="text" name="result23" id="result23" size="5"/>&gt; <input type="text" name="result24" id="result24" size="5"/>&lt;br&gt;
你現在幾年級
&lt;input type=<input type="text" name="result25" id="result25" size="5"/>&gt; <input type="text" name="result26" id="result26" size="5"/>

&lt;input type=<input type="text" name="result27" id="result27" size="5"/>&gt; <input type="text" name="result28" id="result28" size="5"/>

&lt;input type=<input type="text" name="result29" id="result29" size="5"/>&gt; <input type="text" name="result30" id="result30" size="5"/>

&lt;input type=<input type="text" name="result31" id="result31" size="5"/>&gt; <input type="text" name="result32" id="result32" size="5"/>&lt;br&gt;

&lt;input type=<input type="text" name="result33" id="result35" size="5"/> value="送出"&gt;

&lt;input type=<input type="text" name="result34" id="result36" size="5"/> value="清除"&gt;
&lt;/form&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>


    			</p>
				
		</li>
		
		<li class="first" id="test5post">
			<form id="form1" action="redirect5.php" method="POST" novalidate="novalidate">
				<h3 id="sub2">答案實作區～</h3>
					<p  >＃id:link<br>
						{<br>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer6" > :
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer6" >;<br>	
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer7" > :
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer7" >;<br>	
    	  		 		}<br>
    	  		 		＃id:								
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="hovername" ><br>	
						{<br>			
    	  		 			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer8" > :
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer8" >;<br>	
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer9" > :
							<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer9" >;<br>	
    	  		 		}<br>
    				</p>
    				<input type="submit" class="button1" value="測驗繳交">
    		</form>			<br>
			
    		
			
			</li>
			
			<li class="first" id="test6post">
				<h3>答案實作區～</h3>
				<p>
				<form name="form1" method="post" action="redirect6.php">
			<p>
			
			$student[1]="魯夫"; <br>
			$student[2]="索隆"; <br>
			$student[3]="娜美"; <br>
			$student[4]="騙人布"; <br>
			$student[5]="香吉士"; <br>
			
			foreach( <input type="text" name="T7" size="5">  as <input type="text" name="T8" size="5"> =>$value){ <br>
			echo '$student['.$key."]：".<input type="text" name="T9" size="5">."&lt; br &gt";<br> 
			} 
			
			</p>
				
				<button type="submit" class="button1">測驗繳交</button><br>
				</form>
				
    			</p>
    		</li>
			
			<li class="first" id="test7post">
			<form id="form1" action="redirect7.php" method="POST" novalidate="novalidate">
				<h3 id="sub1">答案實作區～</h3>
					<p >		
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="idname" > ;<br>
						{<br>						
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer1" >	
						：			
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer1" > ;<br>		
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer2" >	
						：			
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer2" > ;<br>		
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer3" >	
						：			
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer3" > ;<br>		
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer4" >	
						：			
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer4" > ;<br>		
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="panswer5" >	
						：			
						<input class="form-control" type="text" autocomplete="off" placeholder="" name="vanswer5" > ;<br>		

						
    					}<br>
    				</p>
    				<input type="submit" class="button1" value="測驗繳交" id="sub1">
    		</form>			

		
			</li>
		
		<li class="first" id="test8post">
				<h3>答案實作區～</h3>
				<p>
<form method="POST"  accept-charset="UTF-8" action="redirect8.php">
<pre>
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;body&gt;
&lt;a <input type="text" name="result35" id="result35" size="5"/> = &quot;<input type="text" name="result36" id="result36" size="30"/>&quot;&gt;

&lt;img src=&quot; <input type="text" name="result37" id="result37" size="30"/> &quot;

<input type="text" name="result38" id="result38" size="10"/> = <input type="text" name="result39" id="result39" size="5"/>  <input type="text" name="result40" id="result40" size="10"/> = <input type="text" name="result41" id="result41" size="5"/> &gt;
&lt;/a&gt;
&lt;/body&gt;
&lt;/html&gt;

<button type="submit" class="button1">測驗繳交</button>
</pre>
</form>


    			</p>
				
			</li>
		
		<li class="first" id="test9post">
				<h3>答案實作區～</h3>
				<p>
				<form name="form1" method="post" action="redirect9.php">
			<p>
			&lt;?php<br>
			$i=<input type="text" name="T4" size="2">;<br>
			switch ($i){<br>
			case 1:<br>
			  $a="好像不是";<br>
			  break;<br>
			case 2:<br>
			  $a="你確定";<br>
			  break;<br>
			case 3:<br>
			  $a= "找出這個答案";<br>
			  <input type="text" name="T5" size="2">;<br>
			default:<br>
			  $a= "小心這有問題";<br>
			  break;<br>
			}<br>
			
			echo $a;<br>
			echo "&lt; br &gt";<br>
			function show($a){<br>
				if($a=="找出這個答案")<br>
				echo "&lt; br &gt";<br>
				echo "真的是好棒棒";<br>
			}<br>
			show(<input type="text" name="T6" size="2">);<br>
			?&gt<br>
			</p>
				
				<button type="submit" class="button1">測驗繳交</button><br>
				</form>
				
    			
    			</p>
    		</li>
		</ul>
	</div>
	
</div>
<div id="copyright">
	<p>&copy; Untitled. All rights reserved. | Photos by <a href="http://fotogrph.com/">Fotogrph</a> | Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<?php
 if (isset($_SESSION['user'])) {
 ?>
	<a id="login" href="logout.php" >登出</a>
 <?php

 } else {
   ?>
	<a id="login" href="login.php" >登入</a>
   <?php
 }?>
<button id="gotop" title="Back to Top" class="ScrollTop" >回頁首</button>
</body>
</html>
